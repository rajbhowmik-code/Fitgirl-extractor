// chaos_test - task 5.3: "pull the plug" test for the whole of Guardian.
//
//     chaos_test <guardian-exe> <fake_extractor-exe>
//                [--runs N] [--kills N] [--units N] [--delay-ms N]
//                [--max-kill-seconds S] [--seed N]
//
// One CHAOS RUN:
//   1. Build a fresh workspace: N archive pieces (fg-1.bin ...), a guardian.ini
//      that points at fake_extractor, and an empty game folder.
//   2. Repeat --kills times: start guardian with --crash-after <random time
//      between 0 and --max-kill-seconds>. It dies abruptly at that moment (a
//      simulated power cut, see debug_crash.h), in whatever step it happens to be.
//   3. Run guardian once more, WITHOUT a crash, to completion (must exit 0).
//   4. Run it a third time: it must do nothing (the journal must not grow).
//   5. Check the result: the journal is readable and every unit is Done; the
//      game folder holds exactly the files the fake extractor makes for all
//      units (names, sizes, CRC-32), nothing missing, nothing extra, no .staging.
// The whole test repeats --runs times (default 20); every run must pass.
//
// Exit codes of guardian that count as normal during step 2: 86 (crashed on
// purpose) and 0 (finished before the timer fired). Anything else is a BUG in
// Guardian (or the test) and fails the run at once.
//
// Output: guardian's own progress lines go to stdout (redirect with >NUL or
// >/dev/null for a quiet run); this program reports on stderr.
// On failure the workspace is kept and its path printed, so it can be inspected.
//
// Exit codes: 0 = every run passed, 1 = a run failed, 2 = wrong usage.
#include <algorithm>
#include <charconv>
#include <cstdint>
#include <cstdio>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <string>
#include <system_error>
#include <vector>

#include "command_line.h"
#include "debug_crash.h"
#include "fake_unit_manifest.h"
#include "journal.h"
#include "manifest.h"
#include "process.h"
#include "resume_runner.h"
#include "unit_state.h"
#include "utf8_arguments.h"

namespace {

namespace fs = std::filesystem;

constexpr int kExitOk = 0;
constexpr int kExitFailed = 1;
constexpr int kExitUsage = 2;

struct ChaosSettings {
    std::string guardian_exe;
    std::string fake_extractor_exe;
    int runs = 20;                    // how many complete chaos runs (the plan: 20 in a row)
    int kills = 50;                   // crashes per chaos run (the plan: 50)
    int units = 100;                  // archive pieces per run
    int delay_ms = 20;                // fake_extractor pause per file; 5 files per unit
    double max_kill_seconds = 0.5;    // crash time is random in [0, this]
    std::uint64_t seed = 0;
    bool seed_given = false;
};

// Same tiny generator as the tests use elsewhere: identical numbers on every compiler.
class SplitMix64 {
public:
    explicit SplitMix64(std::uint64_t seed) : state_(seed) {}
    std::uint64_t next() {
        state_ += 0x9E3779B97F4A7C15ull;
        std::uint64_t mixed = state_;
        mixed = (mixed ^ (mixed >> 30)) * 0xBF58476D1CE4E5B9ull;
        mixed = (mixed ^ (mixed >> 27)) * 0x94D049BB133111EBull;
        return mixed ^ (mixed >> 31);
    }
    // Uniform in [0, 1).
    double next_fraction() { return static_cast<double>(next() >> 11) * (1.0 / 9007199254740992.0); }

private:
    std::uint64_t state_;
};

int print_usage() {
    std::cerr << "usage: chaos_test <guardian-exe> <fake_extractor-exe> [--runs N] [--kills N] [--units N]\n"
                 "                  [--delay-ms N] [--max-kill-seconds S] [--seed N]\n";
    return kExitUsage;
}

template <typename Number>
bool parse_number(const std::string& text, Number& value) {
    Number parsed{};
    const char* const end = text.data() + text.size();
    const std::from_chars_result result = std::from_chars(text.data(), end, parsed);
    if (result.ec != std::errc() || result.ptr != end) return false;
    value = parsed;
    return true;
}

bool parse_settings(const std::vector<std::string>& arguments, ChaosSettings& settings) {
    std::vector<std::string> positional;
    for (std::size_t index = 1; index < arguments.size(); ++index) {
        const std::string& argument = arguments[index];
        if (argument.rfind("--", 0) != 0) {
            positional.push_back(argument);
            continue;
        }
        if (index + 1 >= arguments.size()) {
            std::cerr << "chaos_test: option '" << argument << "' needs a value\n";
            return false;
        }
        const std::string& value = arguments[++index];
        bool valid = false;
        if (argument == "--runs") {
            valid = parse_number(value, settings.runs) && settings.runs >= 1 && settings.runs <= 10000;
        } else if (argument == "--kills") {
            valid = parse_number(value, settings.kills) && settings.kills >= 0 && settings.kills <= 100000;
        } else if (argument == "--units") {
            valid = parse_number(value, settings.units) && settings.units >= 1 && settings.units <= 100000;
        } else if (argument == "--delay-ms") {
            valid = parse_number(value, settings.delay_ms) && settings.delay_ms >= 0 && settings.delay_ms <= 60000;
        } else if (argument == "--max-kill-seconds") {
            std::string error;
            valid = parse_crash_after_seconds(value, settings.max_kill_seconds, error);
        } else if (argument == "--seed") {
            valid = parse_number(value, settings.seed);
            settings.seed_given = valid;
        } else {
            std::cerr << "chaos_test: unknown option '" << argument << "'\n";
            return false;
        }
        if (!valid) {
            std::cerr << "chaos_test: invalid value '" << value << "' for " << argument << "\n";
            return false;
        }
    }
    if (positional.size() != 2 || positional[0].empty() || positional[1].empty()) return false;
    settings.guardian_exe = positional[0];
    settings.fake_extractor_exe = positional[1];
    return true;
}

// A throw-away folder with units, config and an empty game folder.
struct Workspace {
    fs::path root;
    std::string units_folder;
    std::string game_folder;
    std::string config_path;
    std::string journal_path;
    std::vector<std::string> unit_names;
};

bool write_text_file(const fs::path& path, const std::string& text) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(text.data(), static_cast<std::streamsize>(text.size()));
    out.flush();
    return static_cast<bool>(out);
}

bool create_workspace(const ChaosSettings& settings, SplitMix64& random, Workspace& workspace, std::string& error) {
    try {
        workspace.root = fs::temp_directory_path() / ("guardian_chaos_" + std::to_string(random.next()));
        const fs::path units_path = workspace.root / "units";
        const fs::path game_path = workspace.root / "game";
        fs::create_directories(units_path);
        fs::create_directories(game_path);

        workspace.units_folder = units_path.u8string();
        workspace.game_folder = game_path.u8string();
        workspace.config_path = (workspace.root / "guardian.ini").u8string();
        workspace.journal_path = (game_path / kJournalFileName).u8string();

        for (int number = 1; number <= settings.units; ++number) {
            const std::string name = "fg-" + std::to_string(number) + ".bin";
            workspace.unit_names.push_back(name);
            if (!write_text_file(units_path / fs::u8path(name), "unit " + std::to_string(number) + "\n")) {
                error = "cannot write unit file " + name;
                return false;
            }
        }

        const std::string ini_text = "extractor_cmd = " + quote_argument(settings.fake_extractor_exe) +
                                     " {unit} {out} --delay-ms " + std::to_string(settings.delay_ms) + "\n";
        if (!write_text_file(fs::u8path(workspace.config_path), ini_text)) {
            error = "cannot write guardian.ini";
            return false;
        }
        return true;
    } catch (const std::exception& problem) {
        error = std::string("cannot create the workspace: ") + problem.what();
        return false;
    }
}

std::string guardian_command(const ChaosSettings& settings, const Workspace& workspace, const std::string& extra) {
    return quote_argument(settings.guardian_exe) + " run " + quote_argument(workspace.game_folder) +
           " --units-folder " + quote_argument(workspace.units_folder) + " --config " +
           quote_argument(workspace.config_path) + extra;
}

// Runs guardian; false (with `error`) if it could not even be started.
bool run_guardian(const ChaosSettings& settings, const Workspace& workspace, const std::string& extra, int& exit_code,
                  std::string& error) {
    return run_process(guardian_command(settings, workspace, extra), exit_code, &error);
}

std::size_t journal_record_count(const Workspace& workspace) {
    const LoadResult loaded = Journal(workspace.journal_path).load();
    return loaded.ok ? loaded.records.size() : 0;
}

// Step 5: journal and output folder must be exactly right.
bool verify_result(const Workspace& workspace, std::size_t& restarted_units, std::string& error) {
    const LoadResult loaded = Journal(workspace.journal_path).load();
    if (!loaded.ok) {
        error = "journal unreadable after the run: " + loaded.error;
        return false;
    }
    State states;
    if (!State::from_journal(loaded.records, states, error)) return false;
    for (const std::string& name : workspace.unit_names) {
        if (states.state_of(name) != UnitState::Done) {
            error = "unit " + name + " is " + to_string(states.state_of(name)) + ", expected Done";
            return false;
        }
    }

    // UNIT_START records beyond one per unit = units that had to be redone.
    std::size_t start_records = 0;
    for (const Record& record : loaded.records) start_records += (record.type == kUnitStartRecordType) ? 1 : 0;
    restarted_units = start_records > workspace.unit_names.size() ? start_records - workspace.unit_names.size() : 0;

    // Expected: the union of every unit's fake output.
    Manifest expected;
    for (const std::string& name : workspace.unit_names) {
        const Manifest unit_manifest = make_fake_unit_manifest(name);
        expected.files.insert(expected.files.end(), unit_manifest.files.begin(), unit_manifest.files.end());
    }
    std::sort(expected.files.begin(), expected.files.end(),
              [](const ManifestEntry& left, const ManifestEntry& right) { return left.relative_path < right.relative_path; });

    // Actual: everything in the game folder except the journal. A leftover
    // ".staging" folder shows up as an extra entry and fails the comparison.
    Manifest actual;
    if (!build_manifest(workspace.game_folder, actual, error)) return false;
    actual.files.erase(std::remove_if(actual.files.begin(), actual.files.end(),
                                      [](const ManifestEntry& file) { return file.relative_path == kJournalFileName; }),
                       actual.files.end());

    std::string differences;
    if (!compare_manifests(expected, actual, differences)) {
        error = "the output folder differs from the expected files:\n" + differences;
        return false;
    }
    return true;
}

struct RunStats {
    int crashed = 0;         // guardian died by the debug crash (exit 86)
    int finished_early = 0;  // guardian completed before its timer fired (exit 0)
    std::size_t restarted_units = 0;
};

// One complete chaos run. true = passed.
bool run_one_chaos_run(const ChaosSettings& settings, SplitMix64& random, int run_number, RunStats& stats,
                       std::string& error, std::string& kept_workspace) {
    Workspace workspace;
    if (!create_workspace(settings, random, workspace, error)) return false;
    kept_workspace = workspace.root.u8string();

    // Step 2: crash again and again.
    for (int kill_number = 1; kill_number <= settings.kills; ++kill_number) {
        char seconds_text[32];
        std::snprintf(seconds_text, sizeof seconds_text, "%.3f", random.next_fraction() * settings.max_kill_seconds);

        int exit_code = 0;
        if (!run_guardian(settings, workspace, std::string(" --crash-after ") + seconds_text, exit_code, error)) {
            error = "cannot start guardian: " + error;
            return false;
        }
        if (exit_code == kDebugCrashExitCode) {
            ++stats.crashed;
        } else if (exit_code == 0) {
            ++stats.finished_early;
        } else {
            error = "kill #" + std::to_string(kill_number) + " (crash after " + seconds_text +
                    " s): guardian exited with unexpected code " + std::to_string(exit_code);
            return false;
        }
    }

    // Step 3: finish for real.
    int exit_code = 0;
    if (!run_guardian(settings, workspace, "", exit_code, error)) {
        error = "cannot start guardian: " + error;
        return false;
    }
    if (exit_code != 0) {
        error = "the final run exited with code " + std::to_string(exit_code) + " instead of 0";
        return false;
    }

    // Step 4: a further run must change nothing.
    const std::size_t records_before = journal_record_count(workspace);
    if (!run_guardian(settings, workspace, "", exit_code, error) || exit_code != 0) {
        error = "the extra run after completion failed (exit code " + std::to_string(exit_code) + ") " + error;
        return false;
    }
    if (journal_record_count(workspace) != records_before) {
        error = "a run after completion wrote journal records: finished units were not skipped";
        return false;
    }

    // Step 5.
    std::size_t restarted = 0;
    if (!verify_result(workspace, restarted, error)) return false;
    stats.restarted_units += restarted;

    std::cerr << "run " << run_number << "/" << settings.runs << ": PASS\n";
    std::error_code ignored;
    fs::remove_all(workspace.root, ignored);
    kept_workspace.clear();
    return true;
}

}  // namespace

int main(int argc, char** argv) {
    try {
        const std::vector<std::string> arguments = utf8_command_line_arguments(argc, argv);
        ChaosSettings settings;
        if (arguments.empty() || !parse_settings(arguments, settings)) return print_usage();
        if (!settings.seed_given) {
            std::random_device entropy;
            settings.seed = (static_cast<std::uint64_t>(entropy()) << 32) ^ entropy();
        }
        std::cerr << "chaos_test: seed " << settings.seed << ", " << settings.runs << " runs x " << settings.kills
                  << " kills, " << settings.units << " units, kill window 0-" << settings.max_kill_seconds << " s\n";

        SplitMix64 random(settings.seed);
        RunStats total;
        for (int run_number = 1; run_number <= settings.runs; ++run_number) {
            std::string error;
            std::string kept_workspace;
            if (!run_one_chaos_run(settings, random, run_number, total, error, kept_workspace)) {
                std::cerr << "run " << run_number << "/" << settings.runs << ": FAIL: " << error << "\n";
                if (!kept_workspace.empty()) std::cerr << "workspace kept for inspection: " << kept_workspace << "\n";
                std::cerr << "repeat with: --seed " << settings.seed << "\n";
                return kExitFailed;
            }
        }
        std::cerr << "chaos_test: ALL " << settings.runs << " RUNS PASSED (" << total.crashed
                  << " crashes landed, " << total.finished_early << " runs finished before their timer, "
                  << total.restarted_units << " interrupted units redone)\n";
        return kExitOk;
    } catch (const std::exception& problem) {
        std::cerr << "chaos_test: " << problem.what() << "\n";
        return kExitFailed;
    }
}
