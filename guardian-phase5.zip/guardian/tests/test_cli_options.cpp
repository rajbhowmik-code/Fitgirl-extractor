// Tasks 5.1 / 5.2: command-line parsing and the --crash-after number format.
#include "test_common.h"

#include <iostream>
#include <string>
#include <vector>

#include "cli_options.h"
#include "debug_crash.h"

namespace {

using Args = std::vector<std::string>;

bool parses(const Args& arguments, CliOptions& options) {
    std::string error;
    return parse_cli_arguments(arguments, options, error);
}

std::string error_of(const Args& arguments) {
    CliOptions options;
    std::string error;
    assert(!parse_cli_arguments(arguments, options, error));
    assert(!error.empty());
    return error;
}

bool crash_seconds(const std::string& text, double& seconds) {
    std::string error;
    return parse_crash_after_seconds(text, seconds, error);
}

void test_run_and_resume_are_equivalent() {
    for (const char* command : {"run", "resume"}) {
        CliOptions options;
        assert(parses({command, "D:\\Games\\X"}, options));
        assert(options.command == CliCommand::Run);
        assert(options.resume.game_folder == "D:\\Games\\X");
        assert(options.resume.units_folder.empty());
        assert(options.resume.config_path.empty());
        assert(!options.crash_after_seconds.has_value());
    }
}

void test_all_options_in_any_order() {
    CliOptions options;
    assert(parses({"run", "--crash-after", "2.5", "game", "--config", "c.ini", "--units-folder", "units"}, options));
    assert(options.resume.game_folder == "game");
    assert(options.resume.units_folder == "units");
    assert(options.resume.config_path == "c.ini");
    assert(options.crash_after_seconds.has_value() && *options.crash_after_seconds == 2.5);
}

void test_paths_with_spaces_and_unicode_are_kept() {
    CliOptions options;
    assert(parses({"run", "C:\\My Games\\\xE0\xA6\xAC\xE0\xA6\xBE\xE0\xA6\x82\xE0\xA6\xB2\xE0\xA6\xBE"}, options));
    assert(options.resume.game_folder == "C:\\My Games\\\xE0\xA6\xAC\xE0\xA6\xBE\xE0\xA6\x82\xE0\xA6\xB2\xE0\xA6\xBE");
}

void test_help() {
    for (const char* word : {"help", "--help", "-h"}) {
        CliOptions options;
        options.command = CliCommand::Run;
        assert(parses({word}, options));
        assert(options.command == CliCommand::ShowHelp);
    }
}

void test_errors() {
    assert(error_of({}).find("no command") != std::string::npos);
    assert(error_of({"extract", "x"}).find("unknown command") != std::string::npos);
    assert(error_of({"run"}).find("missing <game-folder>") != std::string::npos);
    assert(error_of({"run", "a", "b"}).find("extra argument") != std::string::npos);
    assert(error_of({"run", ""}).find("must not be empty") != std::string::npos);
    assert(error_of({"run", "a", "--bogus", "1"}).find("unknown option") != std::string::npos);
    assert(error_of({"run", "a", "--config"}).find("needs a value") != std::string::npos);
    assert(error_of({"run", "a", "--config", ""}).find("non-empty") != std::string::npos);
    // A forgotten value must not swallow the next option.
    assert(error_of({"run", "a", "--config", "--crash-after", "1"}).find("needs a value") != std::string::npos);
    assert(error_of({"run", "a", "--config", "x", "--config", "y"}).find("more than once") != std::string::npos);
    assert(error_of({"run", "a", "--crash-after", "abc"}).find("--crash-after") != std::string::npos);
}

void test_failed_parse_leaves_output_unchanged() {
    CliOptions options;
    options.resume.game_folder = "keep";
    std::string error;
    assert(!parse_cli_arguments({"run", "a", "--bogus", "1"}, options, error));
    assert(options.resume.game_folder == "keep");
}

void test_crash_after_numbers() {
    double seconds = -1.0;
    assert(crash_seconds("0", seconds) && seconds == 0.0);
    assert(crash_seconds("3", seconds) && seconds == 3.0);
    assert(crash_seconds("2.5", seconds) && seconds == 2.5);
    assert(crash_seconds(".25", seconds) && seconds == 0.25);
    assert(crash_seconds("86400", seconds) && seconds == 86400.0);

    seconds = 7.0;  // must stay untouched by every failure below
    for (const char* bad : {"", "-1", "-0", "+1", " 1", "1 ", "abc", "1x", "inf", "nan", "0x10", "86400.5", "1e9", "--1"}) {
        assert(!crash_seconds(bad, seconds));
        assert(seconds == 7.0);
    }
}

}  // namespace

int main() {
    test_run_and_resume_are_equivalent();
    test_all_options_in_any_order();
    test_paths_with_spaces_and_unicode_are_kept();
    test_help();
    test_errors();
    test_failed_parse_leaves_output_unchanged();
    test_crash_after_numbers();
    std::cout << "test_cli_options: all tests passed\n";
    return 0;
}
