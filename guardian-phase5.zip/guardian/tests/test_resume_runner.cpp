// Task 5.1: the main loop (skip Done units, redo interrupted ones, stop on failure).
// Usage: test_resume_runner [path-to-fake_extractor]
#include "test_common.h"

#include <algorithm>
#include <filesystem>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "command_line.h"
#include "fake_unit_manifest.h"
#include "journal.h"
#include "manifest.h"
#include "resume_runner.h"
#include "test_util.h"
#include "unit_extractor.h"
#include "unit_state.h"
#include "utf8_arguments.h"

namespace {

namespace fs = std::filesystem;

std::string g_extractor;  // path of the fake_extractor executable

// A workspace: <tmp>/units/fg-N.bin, <tmp>/game/, <tmp>/guardian.ini
struct Workspace {
    test_util::TempDir dir{"resume"};

    // Creates units/ (with `unit_count` pieces), game/ and, optionally, a working guardian.ini.
    explicit Workspace(int unit_count, bool with_config = true);

    std::string units_folder() const { return dir.file("units"); }
    std::string game_folder() const { return dir.file("game"); }
    std::string journal_path() const { return dir.file("game/" + std::string(kJournalFileName)); }

    ResumeOptions options() const {
        ResumeOptions options;
        options.game_folder = game_folder();
        options.units_folder = units_folder();
        options.config_path = dir.file("guardian.ini");
        return options;
    }
};

void write_config(const Workspace& workspace, const std::string& extra_lines = "") {
    test_util::write_file(workspace.dir.file("guardian.ini"),
                          "extractor_cmd = " + quote_argument(g_extractor) + " {unit} {out} --delay-ms 0\n" + extra_lines);
}

Workspace::Workspace(int unit_count, bool with_config) {
    fs::create_directories(fs::u8path(units_folder()));
    fs::create_directories(fs::u8path(game_folder()));
    for (int number = 1; number <= unit_count; ++number) {
        test_util::write_file(units_folder() + "/fg-" + std::to_string(number) + ".bin", "x");
    }
    if (with_config) write_config(*this);
}

std::string unit_name(int number) { return "fg-" + std::to_string(number) + ".bin"; }

// Path of one file the fake extractor writes for unit `number`.
std::string output_file(const Workspace& workspace, int number, const std::string& relative = "readme.txt") {
    return workspace.game_folder() + "/fg-" + std::to_string(number) + "/" + relative;
}

bool output_exists(const Workspace& workspace, int number) {
    return fs::exists(fs::u8path(output_file(workspace, number)));
}

// Full check that unit `number`'s files are in the game folder and correct.
void assert_unit_output_correct(const Workspace& workspace, int number) {
    const Manifest expected = make_fake_unit_manifest(unit_name(number));
    Manifest actual;
    std::string error;
    assert(build_manifest(workspace.game_folder() + "/fg-" + std::to_string(number), actual, error));
    assert(actual.files.size() == expected.files.size());
    for (std::size_t index = 0; index < expected.files.size(); ++index) {
        // expected paths start with "fg-N/", actual ones are relative to that folder
        const std::string& wanted = expected.files[index].relative_path;
        const std::string stripped = wanted.substr(wanted.find('/') + 1);
        assert(actual.files[index].relative_path == stripped);
        assert(actual.files[index].size == expected.files[index].size);
        assert(actual.files[index].crc32 == expected.files[index].crc32);
    }
}

State load_state(const Workspace& workspace) {
    const LoadResult loaded = Journal(workspace.journal_path()).load();
    assert(loaded.ok);
    State state;
    std::string error;
    assert(State::from_journal(loaded.records, state, error));
    return state;
}

std::size_t journal_records(const Workspace& workspace) {
    const LoadResult loaded = Journal(workspace.journal_path()).load();
    assert(loaded.ok);
    return loaded.records.size();
}

ResumeResult run(const Workspace& workspace, std::string& log_text) {
    std::ostringstream log;
    const ResumeResult result = resume_extraction(workspace.options(), log);
    log_text = log.str();
    return result;
}

bool contains(const std::string& text, const std::string& part) { return text.find(part) != std::string::npos; }

// ---------------------------------------------------------------------------

void test_fresh_run_extracts_everything_then_second_run_does_nothing() {
    Workspace workspace(4);
    std::string log;

    ResumeResult first = run(workspace, log);
    assert(first.ok);
    assert(first.units_total == 4 && first.units_extracted == 4 && first.units_skipped == 0 && first.units_redone == 0);
    assert(contains(log, "all units done"));
    for (int number = 1; number <= 4; ++number) {
        assert_unit_output_correct(workspace, number);
        assert(load_state(workspace).state_of(unit_name(number)) == UnitState::Done);
    }
    // The empty ".staging" folder is cleaned up at the end.
    assert(!fs::exists(fs::u8path(workspace.game_folder() + "/" + kStagingFolderName)));

    // Second run: proof that nothing runs again = deleted output stays deleted and the journal does not grow.
    fs::remove_all(fs::u8path(workspace.game_folder() + "/fg-1"));
    const std::size_t records_before = journal_records(workspace);
    ResumeResult second = run(workspace, log);
    assert(second.ok);
    assert(second.units_extracted == 0 && second.units_skipped == 4);
    assert(contains(log, "all units done"));
    assert(!output_exists(workspace, 1));
    assert(journal_records(workspace) == records_before);
}

void test_interrupted_unit_is_redone_and_finished_units_are_skipped() {
    Workspace workspace(4);
    std::string log;
    assert(run(workspace, log).ok);

    // Fake a crash inside unit 3: journal knows START but not DONE; staging has half-written junk;
    // one of the unit's files in the game folder is damaged; units 1-2 outputs are removed to prove they are skipped.
    // Rebuild the journal: START/DONE for 1 and 2, START for 3 (nothing for 4).
    fs::remove(fs::u8path(workspace.journal_path()));
    Journal journal(workspace.journal_path());
    assert(journal.append(make_unit_start_record(unit_name(1))));
    assert(journal.append(make_unit_done_record(unit_name(1))));
    assert(journal.append(make_unit_start_record(unit_name(2))));
    assert(journal.append(make_unit_done_record(unit_name(2))));
    assert(journal.append(make_unit_start_record(unit_name(3))));

    fs::remove_all(fs::u8path(workspace.game_folder() + "/fg-1"));
    fs::remove_all(fs::u8path(workspace.game_folder() + "/fg-2"));
    fs::remove_all(fs::u8path(workspace.game_folder() + "/fg-4"));
    test_util::write_file(output_file(workspace, 3), "damaged");  // replaced when redone
    fs::create_directories(fs::u8path(workspace.game_folder() + "/.staging/fg-3.bin"));
    test_util::write_file(workspace.game_folder() + "/.staging/fg-3.bin/half.tmp", "partial");

    ResumeResult result = run(workspace, log);
    assert(result.ok);
    assert(result.units_skipped == 2);
    assert(result.units_extracted == 2);  // unit 3 (redone) and unit 4 (new)
    assert(result.units_redone == 1);
    assert(contains(log, "Unit 1/4: fg-1.bin - already done"));
    assert(contains(log, "Unit 3/4: fg-3.bin - interrupted last time"));
    assert(!output_exists(workspace, 1) && !output_exists(workspace, 2));  // skipped, not redone
    assert_unit_output_correct(workspace, 3);
    assert_unit_output_correct(workspace, 4);
    assert(!fs::exists(fs::u8path(workspace.game_folder() + "/.staging")));  // junk gone
}

void test_torn_journal_tail_is_ignored() {
    Workspace workspace(2);
    std::string log;
    assert(run(workspace, log).ok);

    // Power cut in the middle of writing a line: bytes without checksum and newline.
    {
        std::ofstream out(fs::u8path(workspace.journal_path()), std::ios::binary | std::ios::app);
        out << "UNIT_START|fg-2.b";
    }
    const ResumeResult result = run(workspace, log);
    assert(result.ok);
    assert(result.units_extracted == 0 && result.units_skipped == 2);
    assert(contains(log, "incomplete last journal line"));
}

void test_corrupt_journal_in_the_middle_stops_before_any_work() {
    Workspace workspace(2);
    std::string log;
    assert(run(workspace, log).ok);
    fs::remove_all(fs::u8path(workspace.game_folder() + "/fg-1"));

    std::string journal_text = test_util::read_file(workspace.journal_path());
    journal_text[journal_text.find('|') + 1] ^= 0x01;  // flip a bit in the FIRST line
    test_util::write_file(workspace.journal_path(), journal_text);

    const ResumeResult result = run(workspace, log);
    assert(!result.ok);
    assert(contains(result.error, "journal"));
    assert(!output_exists(workspace, 1));  // nothing was started
}

void test_failing_extractor_stops_the_loop() {
    Workspace workspace(3, false);
    // The extractor exits with code 3 for every unit.
#ifdef _WIN32
    test_util::write_file(workspace.dir.file("guardian.ini"), "extractor_cmd = cmd /c exit 3 {unit} {out}\n");
#else
    test_util::write_file(workspace.dir.file("guardian.ini"), "extractor_cmd = /bin/sh -c \"exit 3\" ignored {unit} {out}\n");
#endif
    std::string log;
    const ResumeResult result = run(workspace, log);
    assert(!result.ok);
    assert(result.failed_unit == "fg-1.bin");
    assert(contains(result.error, "RunExtractor") && contains(result.error, "code 3"));
    // Later units were never started; the failed one stays InProgress so the next run redoes it.
    const State state = load_state(workspace);
    assert(state.state_of("fg-1.bin") == UnitState::InProgress);
    assert(state.state_of("fg-2.bin") == UnitState::NotStarted);
    assert(state.state_of("fg-3.bin") == UnitState::NotStarted);
    assert(!contains(log, "all units done"));
}

void test_setup_errors() {
    std::string log;

    // No units at all must NOT look like success.
    Workspace empty(0);
    ResumeResult result = run(empty, log);
    assert(!result.ok && contains(result.error, "no archive pieces"));

    // Missing config file.
    Workspace no_config(1, false);
    result = run(no_config, log);
    assert(!result.ok && contains(result.error, "guardian.ini"));

    // Config without extractor_cmd.
    Workspace no_command(1, false);
    test_util::write_file(no_command.dir.file("guardian.ini"), "unit_pattern = *.bin\n");
    result = run(no_command, log);
    assert(!result.ok && contains(result.error, "extractor_cmd"));

    // Template without {out}.
    Workspace bad_template(1, false);
    test_util::write_file(bad_template.dir.file("guardian.ini"), "extractor_cmd = tool {unit}\n");
    result = run(bad_template, log);
    assert(!result.ok && contains(result.error, "extractor_cmd"));

    // Game folder missing / empty strings.
    Workspace workspace(1);
    ResumeOptions options = workspace.options();
    options.game_folder = workspace.dir.file("does-not-exist");
    std::ostringstream sink;
    result = resume_extraction(options, sink);
    assert(!result.ok && contains(result.error, "game folder"));
    options.game_folder = "";
    result = resume_extraction(options, sink);
    assert(!result.ok && contains(result.error, "must not be empty"));
}

void test_unit_pattern_and_units_inside_game_folder() {
    // Units live IN the game folder (the default) and the pattern is narrowed in guardian.ini.
    Workspace workspace(0, false);
    test_util::write_file(workspace.game_folder() + "/fg-1.part", "x");
    test_util::write_file(workspace.game_folder() + "/fg-2.part", "x");
    test_util::write_file(workspace.game_folder() + "/other.bin", "not a unit");
    write_config(workspace, "unit_pattern = *.part\n");

    ResumeOptions options;
    options.game_folder = workspace.game_folder();
    options.config_path = workspace.dir.file("guardian.ini");
    std::ostringstream log;
    const ResumeResult result = resume_extraction(options, log);
    assert(result.ok);
    assert(result.units_total == 2 && result.units_extracted == 2);
    assert(fs::exists(fs::u8path(workspace.game_folder() + "/fg-1.part/readme.txt")) == false);  // output is "fg-1/..."
    assert(fs::exists(fs::u8path(workspace.game_folder() + "/fg-1/readme.txt")));
    assert(fs::exists(fs::u8path(workspace.game_folder() + "/" + kJournalFileName)));
}

void test_default_config_location_is_the_game_folder() {
    Workspace workspace(1, false);
    test_util::write_file(workspace.game_folder() + "/" + kConfigFileName,
                          "extractor_cmd = " + quote_argument(g_extractor) + " {unit} {out} --delay-ms 0\n");
    ResumeOptions options;
    options.game_folder = workspace.game_folder();
    options.units_folder = workspace.units_folder();
    std::ostringstream log;
    const ResumeResult result = resume_extraction(options, log);
    assert(result.ok && result.units_extracted == 1);
}

void test_natural_order_is_used() {
    Workspace workspace(0);
    for (const char* name : {"fg-10.bin", "fg-2.bin", "fg-1.bin"}) {
        test_util::write_file(workspace.units_folder() + "/" + name, "x");
    }
    write_config(workspace);
    std::string log;
    assert(run(workspace, log).ok);
    assert(log.find("fg-1.bin") < log.find("fg-2.bin"));
    assert(log.find("fg-2.bin") < log.find("fg-10.bin"));
}

void test_leftover_staging_of_removed_unit_is_tidied() {
    Workspace workspace(1);
    fs::create_directories(fs::u8path(workspace.game_folder() + "/.staging/gone.bin"));
    test_util::write_file(workspace.game_folder() + "/.staging/gone.bin/x.tmp", "junk");
    std::string log;
    assert(run(workspace, log).ok);
    assert(!fs::exists(fs::u8path(workspace.game_folder() + "/.staging")));
}

}  // namespace

int main(int argc, char** argv) {
    const std::vector<std::string> arguments = utf8_command_line_arguments(argc, argv);
    if (arguments.size() != 2) {
        std::cerr << "usage: test_resume_runner <path-to-fake_extractor>\n";
        return 2;
    }
    g_extractor = arguments[1];

    test_fresh_run_extracts_everything_then_second_run_does_nothing();
    test_interrupted_unit_is_redone_and_finished_units_are_skipped();
    test_torn_journal_tail_is_ignored();
    test_corrupt_journal_in_the_middle_stops_before_any_work();
    test_failing_extractor_stops_the_loop();
    test_setup_errors();
    test_unit_pattern_and_units_inside_game_folder();
    test_default_config_location_is_the_game_folder();
    test_natural_order_is_used();
    test_leftover_staging_of_removed_unit_is_tidied();
    std::cout << "test_resume_runner: all tests passed\n";
    return 0;
}
