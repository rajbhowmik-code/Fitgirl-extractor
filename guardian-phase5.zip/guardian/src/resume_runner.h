// Task 5.1: the main loop. Runs every archive unit that is not finished yet,
// in order, and skips the ones the journal says are Done.
//
// What one call does:
//   1. Reads guardian.ini (extractor command + optional unit_pattern).
//   2. Lists the units (natural order, units.h).
//   3. Loads the journal and replays it into per-unit states (unit_state.h).
//        Done        -> skipped, never touched again.
//        InProgress  -> the previous run died inside this unit. Its staging
//                       folder is deleted and the unit is redone from scratch
//                       (we never resume INSIDE a unit).
//        NotStarted  -> extracted normally.
//   4. Runs the remaining units one by one with extract_unit() (unit_extractor.h).
//      The FIRST failure stops the run: later units are not started, so the
//      journal never shows units finished "around" a broken one.
//   5. When everything is done, removes the empty ".staging" folder and says so.
//
// Running it again after success changes nothing: every unit is Done, no
// extractor is started, and "all units done" is printed again.
//
// Files used (all inside the game folder unless overridden):
//     guardian.journal   the crash-safe journal
//     guardian.ini       the configuration (override with ResumeOptions::config_path)
//     .staging/<unit>/   temporary output of the unit being extracted
//
// Paths are UTF-8 std::strings on every platform.
#pragma once

#include <cstddef>
#include <iosfwd>
#include <string>

// File names inside the game folder.
inline constexpr char kJournalFileName[] = "guardian.journal";
inline constexpr char kConfigFileName[] = "guardian.ini";

struct ResumeOptions {
    // Where the extracted files go. Also holds the journal and ".staging". Required.
    std::string game_folder;

    // Where the archive pieces (fg-1.bin, ...) are. Empty means "the game folder".
    // If the units live inside the game folder, keep unit_pattern narrow: a game
    // file that matches the pattern would otherwise be mistaken for a unit.
    std::string units_folder;

    // Empty means "<game folder>/guardian.ini".
    std::string config_path;
};

struct ResumeResult {
    bool ok = false;
    std::string error;        // readable reason when !ok
    std::string failed_unit;  // name of the unit that failed; empty for set-up problems

    std::size_t units_total = 0;      // archive pieces found
    std::size_t units_skipped = 0;    // already Done in the journal
    std::size_t units_extracted = 0;  // extracted (and journaled Done) by THIS call
    std::size_t units_redone = 0;     // of those: units an earlier run had started but not finished
};

// Runs the loop and reports progress (one line per unit) to `log`.
// Returns ok == true only if every unit is Done afterwards. Never throws.
// Blocks until finished or failed.
ResumeResult resume_extraction(const ResumeOptions& options, std::ostream& log);
