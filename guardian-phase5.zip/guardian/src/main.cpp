// Extraction Guardian - entry point.
//
//   guardian run <game-folder> [--units-folder <folder>] [--config <file>]
//   guardian resume <game-folder> ...        (same as run)
//
// Exit codes: 0 = all units done, 1 = failed, 2 = wrong usage,
//             86 = deliberate debug crash (--crash-after).
#include <exception>
#include <iostream>
#include <string>
#include <vector>

#include "cli_options.h"
#include "debug_crash.h"
#include "resume_runner.h"
#include "utf8_arguments.h"

namespace {

constexpr int kExitOk = 0;
constexpr int kExitFailed = 1;
constexpr int kExitUsage = 2;

}  // namespace

int main(int argc, char** argv) {
    try {
        std::cout << "Extraction Guardian\n";

        // UTF-8 arguments on every platform (Windows argv would mangle non-ASCII folder names).
        std::vector<std::string> arguments = utf8_command_line_arguments(argc, argv);
        if (arguments.empty()) {
            std::cerr << "error: cannot read the command line\n";
            return kExitUsage;
        }
        arguments.erase(arguments.begin());  // drop the program name

        if (arguments.empty()) {  // plain "guardian": show how to use it
            std::cout << cli_usage_text();
            return kExitUsage;
        }

        CliOptions options;
        std::string error;
        if (!parse_cli_arguments(arguments, options, error)) {
            std::cerr << "error: " << error << "\n\n" << cli_usage_text();
            return kExitUsage;
        }
        if (options.command == CliCommand::ShowHelp) {
            std::cout << cli_usage_text();
            return kExitOk;
        }

        // Started BEFORE any work so the simulated power cut can land anywhere,
        // including during start-up.
        if (options.crash_after_seconds.has_value() &&
            !start_debug_crash_timer(*options.crash_after_seconds, error)) {
            std::cerr << "error: " << error << '\n';
            return kExitFailed;
        }

        const ResumeResult result = resume_extraction(options.resume, std::cout);
        if (!result.ok) {
            std::cerr << "error: " << result.error << '\n';
            return kExitFailed;
        }
        return kExitOk;
    } catch (const std::exception& problem) {
        std::cerr << "error: unexpected failure: " << problem.what() << '\n';
        return kExitFailed;
    }
}
