#include "debug_crash.h"

#include <charconv>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <exception>
#include <system_error>
#include <thread>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <unistd.h>
#endif

bool parse_crash_after_seconds(const std::string& text, double& seconds, std::string& error) {
    if (text.empty()) {
        error = "--crash-after needs a number of seconds";
        return false;
    }
    // from_chars would accept a leading '-' and the words "inf" / "nan"; those
    // are rejected below. It never accepts a leading '+', a space or "0x..".
    double parsed = 0.0;
    const char* const text_end = text.data() + text.size();
    const std::from_chars_result result = std::from_chars(text.data(), text_end, parsed);
    if (result.ec != std::errc() || result.ptr != text_end) {
        error = "--crash-after: '" + text + "' is not a plain number of seconds (examples: 3, 2.5)";
        return false;
    }
    if (!std::isfinite(parsed) || parsed < 0.0 || text.front() == '-') {
        error = "--crash-after: the number of seconds must be 0 or more";
        return false;
    }
    if (parsed > kMaxDebugCrashSeconds) {
        error = "--crash-after: more than 86400 seconds (one day) is not allowed";
        return false;
    }
    seconds = parsed;
    return true;
}

[[noreturn]] void crash_immediately() {
#ifdef _WIN32
    // Ends the process at once; when the last handle of our job object closes
    // during process teardown, Windows also kills the extractor (process.h).
    TerminateProcess(GetCurrentProcess(), static_cast<UINT>(kDebugCrashExitCode));
#else
    _exit(kDebugCrashExitCode);  // async-signal-safe, skips atexit handlers and stdio flushing
#endif
    // Reached only if TerminateProcess failed (practically never). _Exit is
    // the next best thing: it also runs no destructors.
    std::_Exit(kDebugCrashExitCode);
}

bool start_debug_crash_timer(double seconds, std::string& error) {
    try {
        // Detached on purpose: nothing ever joins it. If the program finishes
        // first, the process simply ends and takes the sleeping thread along.
        std::thread([seconds]() {
            std::this_thread::sleep_for(std::chrono::duration<double>(seconds));
            crash_immediately();
        }).detach();
        return true;
    } catch (const std::exception& problem) {
        error = std::string("cannot start the crash timer: ") + problem.what();
        return false;
    }
}
