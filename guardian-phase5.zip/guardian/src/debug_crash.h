// Task 5.2: a DEBUG switch that simulates a power cut.
//
//     guardian run <game-folder> --crash-after 2.5
//
// After the given number of seconds the process ends IMMEDIATELY and abruptly:
//   * no destructors, no atexit handlers, no flushing of C++/C streams, no
//     journal "clean shutdown" - exactly like pulling the plug on the process.
//   * Windows: TerminateProcess on ourselves. POSIX: _exit().
//   * The extractor that Guardian started dies with us (kill-on-close job
//     object / parent-death signal, see process.h), as it would in a real crash.
// The exit code is kDebugCrashExitCode, so a test script can tell "crashed on
// purpose" (86) from "finished" (0) and from "failed" (1).
//
// The timer runs on its own thread, so it fires even while the main thread is
// busy inside a long extractor run or a journal write. That is the point: the
// crash can land in ANY step of the pipeline (see unit_extractor.h).
#pragma once

#include <string>

// Exit code of a deliberate debug crash. Chosen to be unlike the codes used for
// ordinary results (0 = done, 1 = failed, 2 = usage error).
inline constexpr int kDebugCrashExitCode = 86;

// Upper limit accepted for --crash-after (one day). Anything bigger is surely a typo.
inline constexpr double kMaxDebugCrashSeconds = 86400.0;

// Parses the value of --crash-after: a plain decimal number of seconds, e.g.
// "0", "3", "2.5", ".25". Rejects empty text, signs, spaces, trailing garbage,
// "inf" / "nan" and values above kMaxDebugCrashSeconds. 0 is allowed and
// means "crash right at start-up". `seconds` is modified only on success.
bool parse_crash_after_seconds(const std::string& text, double& seconds, std::string& error);

// Starts the crash timer and returns immediately. After `seconds` the process
// ends via crash_immediately(). Call it at most once. Returns false (with
// `error`) only if the helper thread could not be created.
bool start_debug_crash_timer(double seconds, std::string& error);

// Ends the process right now, without any cleanup, with kDebugCrashExitCode.
[[noreturn]] void crash_immediately();
