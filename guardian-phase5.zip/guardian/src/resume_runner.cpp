#include "resume_runner.h"

#include <exception>
#include <filesystem>
#include <optional>
#include <ostream>
#include <system_error>
#include <utility>
#include <vector>

#include "command_template.h"
#include "file_ops.h"
#include "ini_file.h"
#include "journal.h"
#include "unit_extractor.h"
#include "unit_state.h"
#include "units.h"

namespace {

namespace fs = std::filesystem;

// Turns a user-given folder / file path into an absolute UTF-8 path, so the
// extractor and every later step see the same location even if the working
// directory differs (for example a Task Scheduler start, task 6.1).
// Does not touch the disk and does not resolve links.
bool make_absolute_utf8(const std::string& text, const char* description, std::string& absolute,
                        std::string& error) {
    if (text.empty()) {
        error = std::string(description) + " must not be empty";
        return false;
    }
    absolute = fs::absolute(fs::u8path(text)).u8string();  // may throw on invalid UTF-8; caller catches
    return true;
}

bool is_existing_folder(const fs::path& folder) {
    std::error_code status_error;
    return fs::is_directory(folder, status_error) && !status_error;
}

// Called only after EVERY unit is Done, so nothing is running and nothing in
// ".staging" is still needed. Deletes leftover staging folders (for example of a
// unit that was started once and whose archive piece has since been removed) and
// then the empty ".staging" folder itself. Problems are reported as a warning:
// the extraction itself is complete and must not be reported as failed because
// of clutter.
void tidy_staging_root(const fs::path& game_path, std::ostream& log) {
    try {
        const fs::path staging_root = game_path / kStagingFolderName;

        // symlink_status does not follow links: a link or file named ".staging" is left alone.
        std::error_code status_error;
        const fs::file_status root_status = fs::symlink_status(staging_root, status_error);
        if (status_error || root_status.type() != fs::file_type::directory) return;

        std::vector<fs::path> leftovers;
        for (const fs::directory_entry& entry : fs::directory_iterator(staging_root)) leftovers.push_back(entry.path());

        for (const fs::path& leftover : leftovers) {
            std::string error;
            // remove_folder_tree refuses links and plain files, so only real folders are deleted.
            if (!remove_folder_tree(leftover.u8string(), error)) {
                log << "warning: could not remove leftover '" << leftover.u8string() << "': " << error << '\n';
            }
        }

        std::error_code remove_error;
        fs::remove(staging_root, remove_error);  // succeeds only if it is empty
        if (remove_error && fs::exists(fs::symlink_status(staging_root))) {
            log << "warning: could not remove the staging folder '" << staging_root.u8string()
                << "': " << remove_error.message() << '\n';
        }
    } catch (const std::exception& problem) {
        log << "warning: could not tidy the staging folder: " << problem.what() << '\n';
    }
}

}  // namespace

ResumeResult resume_extraction(const ResumeOptions& options, std::ostream& log) {
    ResumeResult result;

    // Every failure goes through here, so the counters reached so far are kept.
    const auto fail = [&result](std::string message) -> ResumeResult {
        result.ok = false;
        result.error = std::move(message);
        return result;
    };

    try {
        std::string error;

        // ---- Paths ----------------------------------------------------------
        std::string game_folder;
        std::string units_folder;
        std::string config_path;
        if (!make_absolute_utf8(options.game_folder, "the game folder", game_folder, error)) return fail(error);
        const fs::path game_path = fs::u8path(game_folder);
        if (!is_existing_folder(game_path)) {
            return fail("game folder '" + game_folder + "' does not exist or is not a folder");
        }

        if (options.units_folder.empty()) {
            units_folder = game_folder;
        } else if (!make_absolute_utf8(options.units_folder, "the units folder", units_folder, error)) {
            return fail(error);
        }
        if (options.config_path.empty()) {
            config_path = (game_path / kConfigFileName).u8string();
        } else if (!make_absolute_utf8(options.config_path, "the config file path", config_path, error)) {
            return fail(error);
        }

        // ---- Configuration (read once: command and unit pattern) ------------
        IniFile ini;
        if (!load_ini_file(config_path, ini, error)) return fail(error);

        const std::optional<std::string> command_text = ini.get("extractor_cmd");
        if (!command_text.has_value()) return fail(config_path + ": missing 'extractor_cmd'");
        CommandTemplate command_template;
        if (!CommandTemplate::parse(*command_text, command_template, error)) {
            return fail(config_path + ": extractor_cmd: " + error);
        }

        // ---- Units ----------------------------------------------------------
        const std::string unit_pattern = unit_pattern_from_ini(ini);
        std::vector<Unit> units;
        if (!find_units(units_folder, unit_pattern, units, error)) return fail(error);
        if (units.empty()) {
            // Not "all done": zero units almost always means a wrong folder or pattern.
            return fail("no archive pieces matching '" + unit_pattern + "' were found in '" + units_folder +
                        "' (check unit_pattern in " + config_path + " and --units-folder)");
        }
        result.units_total = units.size();

        // ---- Journal -> state of every unit ---------------------------------
        Journal journal((game_path / kJournalFileName).u8string());
        const LoadResult loaded = journal.load();
        if (!loaded.ok) return fail("cannot use the journal '" + journal.path() + "': " + loaded.error);
        if (loaded.tail_dropped) {
            log << "note: ignored an incomplete last journal line (the previous run was cut off while writing it)\n";
        }
        State unit_states;
        if (!State::from_journal(loaded.records, unit_states, error)) {
            return fail("journal '" + journal.path() + "': " + error);
        }

        // ---- Main loop ------------------------------------------------------
        // The InProgress case needs no extra code here: extract_unit() starts by
        // deleting the unit's old staging folder (its step 2) and it checks that
        // ".staging" is a real folder first, which a separate clean-up here would
        // have to repeat. Interrupted files that were already moved into the game
        // folder are simply replaced when the unit is redone.
        const UnitExtractionContext context{journal, command_template, game_folder, nullptr};
        const std::size_t unit_count = units.size();

        for (std::size_t index = 0; index < unit_count; ++index) {
            const Unit& unit = units[index];
            const std::string label = "Unit " + std::to_string(index + 1) + "/" + std::to_string(unit_count) + ": " + unit.name;
            const UnitState state = unit_states.state_of(unit.name);

            if (state == UnitState::Done) {
                ++result.units_skipped;
                log << label << " - already done, skipping" << std::endl;
                continue;
            }

            const bool was_interrupted = (state == UnitState::InProgress);
            log << label << (was_interrupted ? " - interrupted last time, redoing from the start..."
                                              : " - extracting...")
                << std::endl;

            const UnitExtractionResult unit_result = extract_unit(unit, context);
            if (!unit_result.ok) {
                result.failed_unit = unit.name;
                return fail("unit '" + unit.name + "' failed at stage " + to_string(unit_result.failed_stage) + ": " +
                            unit_result.error);
            }
            if (!unit_result.warning.empty()) log << "warning: " << unit_result.warning << '\n';

            ++result.units_extracted;
            if (was_interrupted) ++result.units_redone;
            log << label << " - done (" << unit_result.files_extracted << " files, " << unit_result.bytes_extracted
                << " bytes)" << std::endl;
        }

        // ---- Finished -------------------------------------------------------
        tidy_staging_root(game_path, log);
        result.ok = true;
        log << "all units done: " << result.units_extracted << " extracted now";
        if (result.units_redone != 0) log << " (" << result.units_redone << " redone after an interruption)";
        log << ", " << result.units_skipped << " skipped (already finished)" << std::endl;
        return result;
    } catch (const std::exception& problem) {
        // bad_alloc, invalid UTF-8 in a path, filesystem errors that escaped ...
        return fail(std::string("unexpected error: ") + problem.what());
    }
}
