#include "cli_options.h"

#include <utility>

#include "debug_crash.h"

namespace {

constexpr char kOptionPrefix[] = "--";

bool looks_like_option(const std::string& argument) {
    return argument.rfind(kOptionPrefix, 0) == 0;  // starts with "--"
}

}  // namespace

bool parse_cli_arguments(const std::vector<std::string>& arguments, CliOptions& out, std::string& error) {
    if (arguments.empty()) {
        error = "no command given";
        return false;
    }

    const std::string& command = arguments[0];
    if (command == "help" || command == "--help" || command == "-h") {
        CliOptions help;
        help.command = CliCommand::ShowHelp;
        out = std::move(help);
        return true;
    }
    if (command != "run" && command != "resume") {
        error = "unknown command '" + command + "'";
        return false;
    }

    CliOptions parsed;
    parsed.command = CliCommand::Run;

    bool have_game_folder = false;
    bool have_units_folder = false;
    bool have_config = false;
    bool have_crash_after = false;

    for (std::size_t index = 1; index < arguments.size(); ++index) {
        const std::string& argument = arguments[index];

        if (!looks_like_option(argument)) {
            if (have_game_folder) {
                error = "unexpected extra argument '" + argument + "' (only one game folder is allowed)";
                return false;
            }
            if (argument.empty()) {
                error = "the game folder must not be empty";
                return false;
            }
            parsed.resume.game_folder = argument;
            have_game_folder = true;
            continue;
        }

        // Every option takes exactly one value.
        if (index + 1 >= arguments.size()) {
            error = "option '" + argument + "' needs a value";
            return false;
        }
        const std::string& value = arguments[index + 1];
        if (value.empty()) {
            error = "option '" + argument + "' needs a non-empty value";
            return false;
        }
        if (looks_like_option(value)) {
            error = "option '" + argument + "' needs a value, but the next argument is the option '" + value + "'";
            return false;
        }

        bool* already_given = nullptr;
        if (argument == "--units-folder") {
            already_given = &have_units_folder;
        } else if (argument == "--config") {
            already_given = &have_config;
        } else if (argument == "--crash-after") {
            already_given = &have_crash_after;
        } else {
            error = "unknown option '" + argument + "'";
            return false;
        }
        if (*already_given) {
            error = "option '" + argument + "' was given more than once";
            return false;
        }
        *already_given = true;

        if (argument == "--units-folder") {
            parsed.resume.units_folder = value;
        } else if (argument == "--config") {
            parsed.resume.config_path = value;
        } else {  // --crash-after
            double seconds = 0.0;
            if (!parse_crash_after_seconds(value, seconds, error)) return false;
            parsed.crash_after_seconds = seconds;
        }
        ++index;  // the value is consumed
    }

    if (!have_game_folder) {
        error = "missing <game-folder>";
        return false;
    }

    out = std::move(parsed);
    return true;
}

std::string cli_usage_text() {
    return "usage:\n"
           "  guardian run <game-folder> [--units-folder <folder>] [--config <file>]\n"
           "  guardian resume <game-folder> [same options]   (same as run)\n"
           "  guardian help\n"
           "\n"
           "  <game-folder>     where the extracted files go; also holds guardian.journal and .staging\n"
           "  --units-folder    where the archive pieces (fg-1.bin, ...) are; default: the game folder\n"
           "  --config          path of guardian.ini; default: <game-folder>/guardian.ini\n"
           "  --crash-after S   DEBUG: end the process abruptly after S seconds (simulates a power cut)\n"
           "\n"
           "exit codes: 0 = all units done, 1 = failed, 2 = wrong usage, 86 = deliberate debug crash\n";
}
