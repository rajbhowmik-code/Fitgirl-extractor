// Command-line parsing for guardian.exe, kept apart from main() so it can be tested.
//
//     guardian run <game-folder> [--units-folder <folder>] [--config <file>]
//                                [--crash-after <seconds>]
//     guardian resume <game-folder> ...      (identical to "run": a run always
//                                             continues where the last one stopped)
//     guardian help
//
// Strict on purpose: unknown options, missing or empty values, repeated options
// and a missing or second game folder are errors, so a typo never silently
// changes what Guardian does. Every option takes exactly one value, and a value
// may not itself start with "--" (that is almost certainly a forgotten value).
//
// Arguments are UTF-8 strings (see utf8_arguments.h).
#pragma once

#include <optional>
#include <string>
#include <vector>

#include "resume_runner.h"

enum class CliCommand { ShowHelp, Run };

struct CliOptions {
    CliCommand command = CliCommand::ShowHelp;
    ResumeOptions resume;                       // filled for CliCommand::Run
    std::optional<double> crash_after_seconds;  // --crash-after (debug only)
};

// `arguments` EXCLUDES the program name. On failure returns false, sets `error`
// and leaves `out` unchanged.
bool parse_cli_arguments(const std::vector<std::string>& arguments, CliOptions& out, std::string& error);

// The text printed by "guardian help" and after a usage error.
std::string cli_usage_text();
