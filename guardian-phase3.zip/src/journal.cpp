#include "journal.h"

#include <algorithm>
#include <exception>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string_view>
#include <system_error>
#include <utility>

#include "crc32.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>

#include <cerrno>
#endif

namespace fs = std::filesystem;

// ============================================================================
// Line encoding (task 1.2)
// ============================================================================
namespace {

constexpr char kFieldSeparator = '|';
constexpr char kEscapeMarker = '%';
constexpr std::size_t kCrcHexDigits = 8;

// Characters that must never appear raw inside a type/field.
inline bool needs_escape(unsigned char c) {
    return c == static_cast<unsigned char>(kEscapeMarker) ||
           c == static_cast<unsigned char>(kFieldSeparator) || c < 0x20 || c == 0x7F;
}

inline bool is_control_char(unsigned char c) { return c < 0x20 || c == 0x7F; }

// Returns 0..15, or -1 if `c` is not a LOWERCASE hex digit. Lowercase only, so
// every record has exactly one valid spelling (a case-flipped checksum digit
// is then detected like any other single-character change).
inline int hex_digit_value(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

void append_escaped(std::string& out, std::string_view text) {
    static constexpr char kHexDigits[] = "0123456789abcdef";
    for (const char raw : text) {
        const unsigned char c = static_cast<unsigned char>(raw);
        if (needs_escape(c)) {
            out += kEscapeMarker;
            out += kHexDigits[c >> 4];
            out += kHexDigits[c & 0x0F];
        } else {
            out += raw;
        }
    }
}

// Decodes %xx escapes. Returns false on a truncated/invalid escape or on a raw
// control character (which make_line never produces).
bool append_unescaped(std::string& out, std::string_view text) {
    for (std::size_t i = 0; i < text.size(); ++i) {
        const char raw = text[i];
        if (raw == kEscapeMarker) {
            if (i + 2 >= text.size()) return false;  // an escape needs two hex digits after '%'
            const int high = hex_digit_value(text[i + 1]);
            const int low = hex_digit_value(text[i + 2]);
            if (high < 0 || low < 0) return false;
            out += static_cast<char>((high << 4) | low);
            i += 2;
        } else if (is_control_char(static_cast<unsigned char>(raw))) {
            return false;
        } else {
            out += raw;
        }
    }
    return true;
}

std::string crc_to_hex(std::uint32_t crc) {
    static constexpr char kHexDigits[] = "0123456789abcdef";
    std::string text(kCrcHexDigits, '0');
    for (std::size_t i = 0; i < kCrcHexDigits; ++i) {
        text[kCrcHexDigits - 1 - i] = kHexDigits[(crc >> (4 * i)) & 0x0Fu];
    }
    return text;
}

// Exactly 8 lowercase hex digits, nothing else.
bool parse_crc_hex(std::string_view text, std::uint32_t& out) {
    if (text.size() != kCrcHexDigits) return false;
    std::uint32_t value = 0;
    for (const char c : text) {
        const int digit = hex_digit_value(c);
        if (digit < 0) return false;
        value = (value << 4) | static_cast<std::uint32_t>(digit);
    }
    out = value;
    return true;
}

}  // namespace

std::string make_line(const Record& record) {
    if (record.type.empty()) {
        throw std::invalid_argument("make_line: record type must not be empty");
    }

    // Cheap early size check on the RAW sizes (escaping only makes text longer)
    // so a gigantic field is rejected before we allocate anything for it.
    std::size_t raw_size = record.type.size() + 1 + kCrcHexDigits;
    for (const std::string& field : record.fields) raw_size += field.size() + 1;
    if (raw_size > kMaxJournalLineBytes) {
        throw std::length_error("make_line: record is too large for one journal line");
    }

    std::string line;
    line.reserve(raw_size + raw_size / 8);
    append_escaped(line, record.type);
    for (const std::string& field : record.fields) {
        line += kFieldSeparator;
        append_escaped(line, field);
    }

    // The checksum covers everything before the final separator.
    const std::uint32_t crc = crc32_update(0, line.data(), line.size());
    line += kFieldSeparator;
    line += crc_to_hex(crc);

    if (line.size() > kMaxJournalLineBytes) {  // escaping pushed it over the limit
        throw std::length_error("make_line: record is too large for one journal line");
    }
    return line;
}

bool parse_line(const std::string& line, Record& out) {
    if (line.size() > kMaxJournalLineBytes) return false;

    // The checksum is whatever follows the LAST separator. Fields can never
    // contain a raw '|' (it is escaped), so this split is unambiguous.
    const std::size_t last_separator = line.rfind(kFieldSeparator);
    if (last_separator == std::string::npos) return false;

    const std::string_view whole_line(line);
    std::uint32_t stored_crc = 0;
    if (!parse_crc_hex(whole_line.substr(last_separator + 1), stored_crc)) return false;

    const std::string_view body = whole_line.substr(0, last_separator);
    if (crc32_update(0, body.data(), body.size()) != stored_crc) return false;

    // Checksum is good: split the body into type + fields and unescape each.
    Record parsed;
    bool is_type_piece = true;
    std::size_t piece_start = 0;
    for (;;) {
        const std::size_t separator = body.find(kFieldSeparator, piece_start);
        const std::string_view piece =
            (separator == std::string_view::npos)
                ? body.substr(piece_start)
                : body.substr(piece_start, separator - piece_start);

        std::string decoded;
        if (!append_unescaped(decoded, piece)) return false;

        if (is_type_piece) {
            if (decoded.empty()) return false;  // make_line never writes an empty type
            parsed.type = std::move(decoded);
            is_type_piece = false;
        } else {
            parsed.fields.push_back(std::move(decoded));
        }

        if (separator == std::string_view::npos) break;
        piece_start = separator + 1;
    }

    out = std::move(parsed);
    return true;
}

// ============================================================================
// Platform layer: durable append / truncate (task 1.3)
// ============================================================================
namespace {

#ifdef _WIN32
using NativeErrorCode = DWORD;
inline NativeErrorCode last_native_error() { return GetLastError(); }
inline std::string native_error_text(NativeErrorCode code) {
    return std::system_category().message(static_cast<int>(code));
}

// Owns a Win32 HANDLE; always closed, even on early return.
class ScopedFile {
public:
    explicit ScopedFile(HANDLE handle) : handle_(handle) {}
    ~ScopedFile() {
        if (is_open()) CloseHandle(handle_);
    }
    ScopedFile(const ScopedFile&) = delete;
    ScopedFile& operator=(const ScopedFile&) = delete;
    bool is_open() const { return handle_ != INVALID_HANDLE_VALUE; }
    HANDLE get() const { return handle_; }

private:
    HANDLE handle_;
};
#else
using NativeErrorCode = int;
inline NativeErrorCode last_native_error() { return errno; }
inline std::string native_error_text(NativeErrorCode code) {
    return std::generic_category().message(code);
}

// Owns a POSIX file descriptor; always closed, even on early return.
class ScopedFile {
public:
    explicit ScopedFile(int descriptor) : descriptor_(descriptor) {}
    ~ScopedFile() {
        if (is_open()) ::close(descriptor_);
    }
    ScopedFile(const ScopedFile&) = delete;
    ScopedFile& operator=(const ScopedFile&) = delete;
    bool is_open() const { return descriptor_ >= 0; }
    int get() const { return descriptor_; }

private:
    int descriptor_;
};
#endif

std::string describe_failure(const char* action, const fs::path& file_path) {
    return std::string(action) + " '" + file_path.u8string() + "': " +
           native_error_text(last_native_error());
}

#ifdef _WIN32

// Appends `bytes` at the end of the file (creating it if needed) and forces
// them to disk. FILE_APPEND_DATA *without* FILE_WRITE_DATA makes Windows
// position every write at the current end of file, so we never overwrite
// existing records even if the file pointer is wrong.
bool append_bytes_durably(const fs::path& file_path, const std::string& bytes,
                          std::string& error) {
    ScopedFile file(CreateFileW(file_path.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ, nullptr,
                                OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (!file.is_open()) {
        error = describe_failure("cannot open journal", file_path);
        return false;
    }

    const char* cursor = bytes.data();
    std::size_t remaining = bytes.size();
    while (remaining > 0) {
        const DWORD chunk = static_cast<DWORD>(std::min<std::size_t>(remaining, 1u << 30));
        DWORD written = 0;
        if (!WriteFile(file.get(), cursor, chunk, &written, nullptr)) {
            error = describe_failure("cannot write journal", file_path);
            return false;
        }
        if (written == 0) {  // would loop forever otherwise
            error = "cannot write journal '" + file_path.u8string() + "': zero bytes written";
            return false;
        }
        cursor += written;
        remaining -= written;
    }

    // Without this the data may sit in the OS cache and vanish in a power cut.
    if (!FlushFileBuffers(file.get())) {
        error = describe_failure("cannot flush journal", file_path);
        return false;
    }
    return true;
}

// Cuts the file down to `new_size` bytes and flushes (used to drop a torn tail).
bool truncate_file_durably(const fs::path& file_path, std::uint64_t new_size,
                           std::string& error) {
    ScopedFile file(CreateFileW(file_path.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr,
                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (!file.is_open()) {
        error = describe_failure("cannot open journal for repair", file_path);
        return false;
    }
    LARGE_INTEGER position;
    position.QuadPart = static_cast<LONGLONG>(new_size);
    if (!SetFilePointerEx(file.get(), position, nullptr, FILE_BEGIN) || !SetEndOfFile(file.get())) {
        error = describe_failure("cannot truncate journal", file_path);
        return false;
    }
    if (!FlushFileBuffers(file.get())) {
        error = describe_failure("cannot flush journal after repair", file_path);
        return false;
    }
    return true;
}

#else  // POSIX

// A newly created file is only crash-safe once its directory entry is on disk.
bool sync_parent_directory(const fs::path& file_path, std::string& error) {
    fs::path directory = file_path.parent_path();
    if (directory.empty()) directory = ".";
    ScopedFile dir(::open(directory.c_str(), O_RDONLY | O_CLOEXEC));
    if (!dir.is_open()) {
        error = describe_failure("cannot open journal directory", directory);
        return false;
    }
    if (::fsync(dir.get()) != 0) {
        const int code = errno;
        // Some file systems refuse fsync on directories; that is not data loss.
        if (code == EINVAL || code == ENOTSUP) return true;
        error = describe_failure("cannot sync journal directory", directory);
        return false;
    }
    return true;
}

bool append_bytes_durably(const fs::path& file_path, const std::string& bytes,
                          std::string& error) {
    std::error_code ignored;
    const bool file_existed = fs::exists(file_path, ignored);

    // O_APPEND: every write goes to the current end of file.
    ScopedFile file(::open(file_path.c_str(), O_WRONLY | O_APPEND | O_CREAT | O_CLOEXEC, 0644));
    if (!file.is_open()) {
        error = describe_failure("cannot open journal", file_path);
        return false;
    }

    const char* cursor = bytes.data();
    std::size_t remaining = bytes.size();
    while (remaining > 0) {
        const ssize_t written = ::write(file.get(), cursor, remaining);
        if (written < 0) {
            if (errno == EINTR) continue;  // interrupted by a signal: just retry
            error = describe_failure("cannot write journal", file_path);
            return false;
        }
        cursor += written;
        remaining -= static_cast<std::size_t>(written);
    }

    if (::fsync(file.get()) != 0) {
        error = describe_failure("cannot flush journal", file_path);
        return false;
    }
    return file_existed || sync_parent_directory(file_path, error);
}

bool truncate_file_durably(const fs::path& file_path, std::uint64_t new_size,
                           std::string& error) {
    ScopedFile file(::open(file_path.c_str(), O_WRONLY | O_CLOEXEC));
    if (!file.is_open()) {
        error = describe_failure("cannot open journal for repair", file_path);
        return false;
    }
    if (::ftruncate(file.get(), static_cast<off_t>(new_size)) != 0) {
        error = describe_failure("cannot truncate journal", file_path);
        return false;
    }
    if (::fsync(file.get()) != 0) {
        error = describe_failure("cannot flush journal after repair", file_path);
        return false;
    }
    return true;
}

#endif

}  // namespace

// ============================================================================
// Journal
// ============================================================================

Journal::Journal(std::string path) : path_(std::move(path)) {}

bool Journal::append(const Record& record, std::string* error) {
    std::string message;
    try {
        // Encode first: if the record is invalid we have not touched the file.
        std::string line = make_line(record);
        line += '\n';  // '\n' only (binary mode everywhere): no CRLF translation

        if (path_.empty()) {
            message = "journal path is empty";
        } else if (!tail_checked_ && !ensure_tail_clean(message)) {
            // message already filled in
        } else {
            tail_checked_ = true;
            if (append_bytes_durably(fs::u8path(path_), line, message)) return true;
            // The write may have stopped half-way (disk full, power-cut-like
            // failure). Force a tail check before the next append so a torn
            // fragment can never be glued to the next record.
            tail_checked_ = false;
        }
    } catch (const std::exception& e) {
        message = std::string("cannot append journal record: ") + e.what();
        tail_checked_ = false;
    }
    if (error != nullptr) *error = std::move(message);
    return false;
}

// Makes sure the file contains only complete, valid lines before we append.
bool Journal::ensure_tail_clean(std::string& error) {
    const LoadResult state = load();
    if (!state.ok) {
        // Never append after real corruption: it would bury the damage.
        error = "refusing to append to an unusable journal: " + state.error;
        return false;
    }
    if (state.tail_dropped) {
        // A previous run died mid-write. Cut the partial line off so the next
        // record starts on a fresh line and the damage does not end up in the
        // middle of the file (which load() treats as fatal).
        if (!truncate_file_durably(fs::u8path(path_), state.valid_bytes, error)) return false;
    }
    return true;
}

LoadResult Journal::load() const {
    LoadResult result;

    // Reports a fatal problem and discards partial results so a caller that
    // forgets to check `ok` cannot act on half-read data.
    const auto fail = [&result](std::string message) {
        result.ok = false;
        result.error = std::move(message);
        result.records.clear();
        result.tail_dropped = false;
        result.valid_bytes = 0;
    };

    if (path_.empty()) {
        fail("journal path is empty");
        return result;
    }

    try {
        const fs::path journal_path = fs::u8path(path_);

        std::error_code status_error;
        const fs::file_status status = fs::status(journal_path, status_error);
        if (status.type() == fs::file_type::not_found) return result;  // fresh start: no journal yet
        if (status_error) {
            fail("cannot access journal '" + path_ + "': " + status_error.message());
            return result;
        }
        if (!fs::is_regular_file(status)) {
            fail("journal '" + path_ + "' is not a regular file");
            return result;
        }

        std::ifstream input(journal_path, std::ios::binary);
        if (!input) {
            fail("cannot open journal '" + path_ + "' for reading");
            return result;
        }

        // ---- streaming line scanner (bounded memory) -------------------------
        constexpr std::size_t kReadChunkBytes = 64 * 1024;
        // +2: room for a trailing '\r' on a line that is exactly at the limit.
        constexpr std::size_t kLineBufferLimit = kMaxJournalLineBytes + 2;

        std::vector<char> chunk(kReadChunkBytes);
        std::string current_line;
        bool current_line_too_long = false;

        std::uint64_t bytes_consumed = 0;      // bytes scanned so far
        std::uint64_t last_newline_end = 0;    // offset just after the last '\n' seen
        std::size_t line_number = 0;           // 1-based number of the last complete line
        bool damaged_line_seen = false;        // a bad line exists; it must turn out to be the LAST
        std::size_t damaged_line_number = 0;

        const auto fail_middle_damage = [&]() {
            fail("journal '" + path_ + "' is corrupt at line " +
                 std::to_string(damaged_line_number) +
                 ": a damaged record is followed by more data (only a torn last line is tolerated)");
        };

        // Handles one '\n'-terminated line. Returns false when scanning must stop.
        const auto handle_complete_line = [&]() -> bool {
            ++line_number;
            last_newline_end = bytes_consumed;

            // Tolerate CRLF line endings (e.g. file touched by a Windows text
            // editor). A raw '\r' can never be part of a valid record.
            if (!current_line.empty() && current_line.back() == '\r') current_line.pop_back();

            Record record;
            const bool good = !current_line_too_long && parse_line(current_line, record);

            current_line.clear();
            current_line_too_long = false;

            if (damaged_line_seen) {  // a bad line was NOT the last one -> real corruption
                fail_middle_damage();
                return false;
            }
            if (good) {
                result.records.push_back(std::move(record));
                result.valid_bytes = bytes_consumed;
            } else {
                damaged_line_seen = true;
                damaged_line_number = line_number;
            }
            return true;
        };

        for (;;) {
            input.read(chunk.data(), static_cast<std::streamsize>(chunk.size()));
            const std::streamsize bytes_read = input.gcount();
            for (std::streamsize i = 0; i < bytes_read; ++i) {
                const char c = chunk[static_cast<std::size_t>(i)];
                ++bytes_consumed;
                if (c == '\n') {
                    if (!handle_complete_line()) return result;
                } else if (current_line.size() < kLineBufferLimit) {
                    current_line.push_back(c);
                } else {
                    current_line_too_long = true;  // keep scanning to the newline, store nothing more
                }
            }
            if (!input) break;  // end of file or read error
        }
        if (input.bad() || !input.eof()) {
            fail("I/O error while reading journal '" + path_ + "'");
            return result;
        }

        // Bytes after the last '\n' form an unterminated (incomplete) last line.
        const bool has_unterminated_tail = bytes_consumed > last_newline_end;
        if (has_unterminated_tail && damaged_line_seen) {
            fail_middle_damage();  // the damaged line is followed by more bytes
            return result;
        }
        if (has_unterminated_tail || damaged_line_seen) {
            result.tail_dropped = true;  // valid_bytes already points at the good prefix
        }
        return result;
    } catch (const std::exception& e) {
        fail("cannot read journal '" + path_ + "': " + e.what());
        return result;
    }
}
