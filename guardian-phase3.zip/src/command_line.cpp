#include "command_line.h"

#include <cstddef>

namespace {

constexpr char kSeparatorCharacters[] = " \t\n\v\"";  // a value containing any of these needs quotes

}  // namespace

std::string quote_argument(const std::string& argument) {
    // Fast path: nothing that could be misread, so leave the value alone.
    if (!argument.empty() && argument.find_first_of(kSeparatorCharacters) == std::string::npos) {
        return argument;
    }

    std::string quoted;
    quoted.reserve(argument.size() + 2);
    quoted.push_back('"');

    std::size_t position = 0;
    while (position < argument.size()) {
        // Count a run of backslashes; what follows decides how they are written.
        std::size_t backslash_count = 0;
        while (position < argument.size() && argument[position] == '\\') {
            ++backslash_count;
            ++position;
        }

        if (position == argument.size()) {
            // Backslashes right before the closing quote must be doubled,
            // otherwise they would escape that closing quote.
            quoted.append(backslash_count * 2, '\\');
        } else if (argument[position] == '"') {
            // Double the backslashes AND escape the quote itself.
            quoted.append(backslash_count * 2 + 1, '\\');
            quoted.push_back('"');
            ++position;
        } else {
            // Backslashes followed by an ordinary character are literal.
            quoted.append(backslash_count, '\\');
            quoted.push_back(argument[position]);
            ++position;
        }
    }

    quoted.push_back('"');
    return quoted;
}

std::vector<std::string> split_command_line(const std::string& command_line) {
    std::vector<std::string> arguments;
    std::string current;
    bool argument_started = false;  // true once the current argument has any character (even "")
    bool inside_quotes = false;

    const std::size_t length = command_line.size();
    std::size_t position = 0;
    while (position < length) {
        const char character = command_line[position];

        if (character == '\\') {
            std::size_t backslash_count = 0;
            while (position < length && command_line[position] == '\\') {
                ++backslash_count;
                ++position;
            }
            argument_started = true;
            if (position < length && command_line[position] == '"') {
                current.append(backslash_count / 2, '\\');
                if (backslash_count % 2 == 1) {
                    current.push_back('"');  // odd count: the quote is escaped, i.e. literal
                    ++position;
                }
                // Even count: leave the quote for the next loop pass; it toggles quoting.
            } else {
                current.append(backslash_count, '\\');
            }
            continue;
        }

        if (character == '"') {
            argument_started = true;
            if (inside_quotes && position + 1 < length && command_line[position + 1] == '"') {
                current.push_back('"');  // "" inside quotes: one literal quote, stay inside
                position += 2;
            } else {
                inside_quotes = !inside_quotes;
                ++position;
            }
            continue;
        }

        if ((character == ' ' || character == '\t') && !inside_quotes) {
            if (argument_started) {
                arguments.push_back(current);
                current.clear();
                argument_started = false;
            }
            ++position;
            continue;
        }

        current.push_back(character);
        argument_started = true;
        ++position;
    }

    if (argument_started) arguments.push_back(current);
    return arguments;
}
