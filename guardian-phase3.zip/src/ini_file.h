// Reader for guardian.ini: a tiny, strict "key = value" format.
//
//   ; a comment            (also: # a comment) - whole lines only
//   extractor_cmd = "setup.exe /unit {unit} /out {out}"
//   unit_pattern = *.bin
//
// Rules (deliberately simple and strict, so typos are caught instead of ignored):
//   * One "key = value" per line. Spaces around key and value are trimmed.
//   * Keys: letters, digits, '_', '-', '.'. Case-insensitive (stored lowercase).
//   * A duplicate key is an error.
//   * A value that is wrapped in ONE pair of double quotes and contains no
//     other double quote has that pair removed. So  a = "x y"  gives  x y,
//     while  b = "C:\p q\a.exe" /f "{unit}"  is kept exactly as written.
//   * No inline comments (a ';' or '#' inside a value is part of the value,
//     which matters for command lines). No [sections].
//   * A UTF-8 byte-order mark at the start (Notepad adds one) is ignored;
//     both LF and CRLF line endings work.
//   * Files larger than kMaxIniFileBytes are rejected.
// Paths are UTF-8 strings on every platform.
#pragma once

#include <cstddef>
#include <map>
#include <optional>
#include <string>

inline constexpr std::size_t kMaxIniFileBytes = 1u << 20;  // 1 MiB: a config file is tiny

struct IniFile {
    std::map<std::string, std::string> values;  // lowercase key -> value

    // The value for `key` (looked up case-insensitively), or nullopt if absent.
    std::optional<std::string> get(const std::string& key) const;
};

// Parses INI text. On failure returns false, sets `error` (with a line
// number) and leaves `out` unchanged.
bool parse_ini_text(const std::string& text, IniFile& out, std::string& error);

// Reads and parses a file. Fails (with `error`) if the file is missing,
// unreadable, too large, or malformed.
bool load_ini_file(const std::string& path, IniFile& out, std::string& error);
