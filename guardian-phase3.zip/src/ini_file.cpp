#include "ini_file.h"

#include <exception>
#include <filesystem>
#include <fstream>
#include <utility>

namespace {

namespace fs = std::filesystem;

constexpr char kWhitespace[] = " \t";
constexpr char kUtf8Bom[] = "\xEF\xBB\xBF";

std::string trim(const std::string& text) {
    const std::size_t first = text.find_first_not_of(kWhitespace);
    if (first == std::string::npos) return std::string();
    const std::size_t last = text.find_last_not_of(kWhitespace);
    return text.substr(first, last - first + 1);
}

char to_lower_ascii(char character) {
    return (character >= 'A' && character <= 'Z') ? static_cast<char>(character - 'A' + 'a') : character;
}

std::string to_lower_ascii(const std::string& text) {
    std::string lowered = text;
    for (char& character : lowered) character = to_lower_ascii(character);
    return lowered;
}

bool is_valid_key_character(char character) {
    return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z') ||
           (character >= '0' && character <= '9') || character == '_' || character == '-' ||
           character == '.';
}

// Removes ONE pair of surrounding double quotes, but only when the text
// between them contains no other double quote (see ini_file.h for why).
std::string strip_wrapping_quotes(const std::string& value) {
    if (value.size() >= 2 && value.front() == '"' && value.back() == '"' &&
        value.find('"', 1) == value.size() - 1) {
        return value.substr(1, value.size() - 2);
    }
    return value;
}

std::string line_error(std::size_t line_number, const std::string& message) {
    return "line " + std::to_string(line_number) + ": " + message;
}

}  // namespace

std::optional<std::string> IniFile::get(const std::string& key) const {
    const auto found = values.find(to_lower_ascii(key));
    if (found == values.end()) return std::nullopt;
    return found->second;
}

bool parse_ini_text(const std::string& text, IniFile& out, std::string& error) {
    IniFile parsed;

    std::size_t position = 0;
    if (text.compare(0, 3, kUtf8Bom) == 0) position = 3;  // skip the byte-order mark

    std::size_t line_number = 0;
    while (position <= text.size()) {
        std::size_t line_end = text.find('\n', position);
        const bool is_last_piece = (line_end == std::string::npos);
        if (is_last_piece) line_end = text.size();

        std::string line = text.substr(position, line_end - position);
        position = line_end + 1;
        ++line_number;
        if (!line.empty() && line.back() == '\r') line.pop_back();  // CRLF

        const std::string trimmed = trim(line);
        if (!trimmed.empty() && trimmed[0] != ';' && trimmed[0] != '#') {
            const std::size_t equals_position = trimmed.find('=');
            if (equals_position == std::string::npos) {
                error = line_error(line_number, "expected 'key = value'");
                return false;
            }
            const std::string key = trim(trimmed.substr(0, equals_position));
            const std::string value = strip_wrapping_quotes(trim(trimmed.substr(equals_position + 1)));

            if (key.empty()) {
                error = line_error(line_number, "missing key before '='");
                return false;
            }
            for (const char character : key) {
                if (!is_valid_key_character(character)) {
                    error = line_error(line_number, "invalid character in key '" + key + "'");
                    return false;
                }
            }
            if (!parsed.values.emplace(to_lower_ascii(key), value).second) {
                error = line_error(line_number, "duplicate key '" + key + "'");
                return false;
            }
        }

        if (is_last_piece) break;
    }

    out = std::move(parsed);
    return true;
}

bool load_ini_file(const std::string& path, IniFile& out, std::string& error) {
    try {
        // u8path: treat `path` as UTF-8 on every platform (plain ifstream(string)
        // would use the ANSI code page on Windows and fail on non-ASCII folders).
        std::ifstream input(fs::u8path(path), std::ios::binary);
        if (!input) {
            error = "cannot open '" + path + "'";
            return false;
        }

        // Read one byte more than the limit so "too large" can be detected
        // without loading an arbitrarily big file.
        std::string text(kMaxIniFileBytes + 1, '\0');
        input.read(&text[0], static_cast<std::streamsize>(text.size()));
        const std::size_t bytes_read = static_cast<std::size_t>(input.gcount());
        if (input.bad()) {
            error = "cannot read '" + path + "'";
            return false;
        }
        if (bytes_read > kMaxIniFileBytes) {
            error = "'" + path + "' is too large for a config file";
            return false;
        }
        text.resize(bytes_read);

        std::string parse_error;
        if (!parse_ini_text(text, out, parse_error)) {
            error = path + ": " + parse_error;
            return false;
        }
        return true;
    } catch (const std::exception& problem) {
        // bad_alloc, invalid UTF-8 path on Windows, ...
        error = "cannot read '" + path + "': " + problem.what();
        return false;
    }
}
