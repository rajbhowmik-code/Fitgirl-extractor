// Extraction Guardian - entry point.
// Task 0.1: only prints the program name; real features come in later phases.
#include <iostream>

int main() {
    std::cout << "Extraction Guardian\n";
    return 0;
}
