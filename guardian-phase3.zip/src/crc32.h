// CRC-32 (IEEE 802.3, the same polynomial as zlib / zip / PNG / 7-Zip).
//
// Used for two jobs in Extraction Guardian:
//   * detecting torn / corrupted journal lines (journal.h)
//   * building file manifests to verify extracted files (later phases)
//
// NOTE: CRC-32 detects accidental damage (power cuts, bit rot). It is NOT a
// security hash: an attacker can forge matching values. Do not use it to
// authenticate anything.
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

// Continues a running CRC-32 over `len` bytes at `data`.
//
//   * Start a new checksum with crc = 0.
//   * Pre/post inversion is done internally (zlib convention), so chunks can
//     be chained directly:  c = crc32_update(c, a, na); c = crc32_update(c, b, nb);
//     gives exactly the same value as one call over a+b.
//   * len == 0 returns `crc` unchanged (data may be nullptr in that case).
//   * Precondition: data != nullptr whenever len > 0.
std::uint32_t crc32_update(std::uint32_t crc, const void* data, std::size_t len);

// CRC-32 of a whole file, read in 1 MiB chunks so memory use stays constant no
// matter how big the file is (repack archives can be many GB).
//
//   * `path` is UTF-8 (converted to the native wide path on Windows).
//   * Returns true and sets `out` only if the entire file was read to its end.
//   * Returns false (and leaves `out` untouched) if the file does not exist,
//     is not readable, is a directory, or a read error happens half-way.
//   * An empty file is valid and has CRC 0.
bool crc32_file(const std::string& path, std::uint32_t& out);
