// Runs an external program (the extractor) and waits for it to finish.
//
// The command line is a single UTF-8 string using the Windows quoting rules
// (see command_line.h). No shell is involved: the program is started directly,
// so characters like & | % ^ in file names are harmless.
//
// Crash safety: the child is placed in a "kill on close" group. If Guardian
// itself dies (crash, kill, power cut) the operating system also kills the
// extractor and everything it started. Without this, an orphaned extractor
// could keep writing into the staging folder while the next Guardian run is
// already deleting and refilling it.
//   * Windows: Job Object with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE.
//   * Linux:   PR_SET_PDEATHSIG (best effort; covers the direct child only).
// On Windows the same group also ends any leftover processes the extractor
// left behind when run_process() returns normally, so nothing can still be
// writing while the caller verifies or deletes the output. (On Linux only the
// direct child is covered; Linux is a secondary target.)
// Limitation: run_process() waits for the program it started, not for its
// descendants. An extractor that hands the real work to a helper and exits
// early would be reported as finished; the verification step (task 4.2) then
// fails instead of accepting incomplete output.
//
// SECURITY: if the program name has no folder part ("setup.exe") the operating
// system searches for it (Windows: the folder of guardian.exe, the current
// folder, system folders, PATH). Use an absolute path in guardian.ini so
// nobody can plant a look-alike program in the current folder.
#pragma once

#include <string>

// Returned by the one-argument run_process() when the program could not be
// started or waited for. A program can also genuinely exit with -1, so callers
// that must tell the two apart use the three-argument overload.
inline constexpr int kProcessStartFailed = -1;

// Starts `command_line`, waits until it exits, and stores its exit code.
//   * Returns true  -> the program ran to completion; `exit_code` is set.
//   * Returns false -> it could not be started (empty command, program not
//     found, no permission, command line too long, invalid UTF-8, ...) or
//     waiting failed; `exit_code` is untouched and `*error` (if given)
//     explains why.
// Exit-code conventions: Windows exit codes are 32-bit values and are returned
// as a signed int (a crash such as 0xC0000005 appears as a negative number).
// On POSIX a program killed by signal N is reported as 128 + N.
// Blocks until the program (and only that program) has exited.
bool run_process(const std::string& command_line, int& exit_code, std::string* error = nullptr);

// Convenience form from the project plan: returns the exit code, or
// kProcessStartFailed if the program could not be started.
int run_process(const std::string& command_line);
