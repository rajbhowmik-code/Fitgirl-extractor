#include "crc32.h"

#include <array>
#include <cassert>
#include <exception>
#include <filesystem>
#include <fstream>
#include <vector>

namespace {

namespace fs = std::filesystem;

constexpr std::uint32_t kReflectedPolynomial = 0xEDB88320u;  // IEEE 802.3, bit-reversed
constexpr std::size_t kFileChunkBytes = 1u << 20;            // 1 MiB read buffer

// "Slicing-by-8" lookup tables: table[0] is the classic one-byte table, and
// table[k] is the CRC contribution of a byte that is followed by k zero bytes.
// This lets us consume 8 input bytes per loop iteration (several times faster
// than the one-byte-at-a-time loop) while still using only 8 KiB of tables.
// Built at compile time, so there is no start-up cost and no init-order or
// thread-safety problem.
using CrcTables = std::array<std::array<std::uint32_t, 256>, 8>;

constexpr CrcTables build_tables() {
    CrcTables tables{};
    for (std::uint32_t byte_value = 0; byte_value < 256; ++byte_value) {
        std::uint32_t crc = byte_value;
        for (int bit = 0; bit < 8; ++bit) {
            crc = (crc & 1u) ? (crc >> 1) ^ kReflectedPolynomial : (crc >> 1);
        }
        tables[0][byte_value] = crc;
    }
    for (std::uint32_t byte_value = 0; byte_value < 256; ++byte_value) {
        std::uint32_t crc = tables[0][byte_value];
        for (std::size_t slice = 1; slice < 8; ++slice) {
            crc = tables[0][crc & 0xFFu] ^ (crc >> 8);
            tables[slice][byte_value] = crc;
        }
    }
    return tables;
}

constexpr CrcTables kTables = build_tables();

// Reads 4 bytes as a little-endian value. Byte-wise on purpose: it is correct
// on any CPU endianness, has no unaligned-access / strict-aliasing UB, and
// compilers turn it into a single load on x86/ARM anyway.
inline std::uint32_t load_le32(const unsigned char* p) {
    return static_cast<std::uint32_t>(p[0]) |
           (static_cast<std::uint32_t>(p[1]) << 8) |
           (static_cast<std::uint32_t>(p[2]) << 16) |
           (static_cast<std::uint32_t>(p[3]) << 24);
}

}  // namespace

std::uint32_t crc32_update(std::uint32_t crc, const void* data, std::size_t len) {
    if (len == 0) return crc;
    assert(data != nullptr && "crc32_update: null data with non-zero length");

    const unsigned char* bytes = static_cast<const unsigned char*>(data);
    std::uint32_t state = ~crc;  // undo the final inversion of the previous call

    // Fast path: 8 bytes per iteration.
    while (len >= 8) {
        const std::uint32_t low_word = load_le32(bytes) ^ state;
        const std::uint32_t high_word = load_le32(bytes + 4);
        state = kTables[7][low_word & 0xFFu] ^ kTables[6][(low_word >> 8) & 0xFFu] ^
                kTables[5][(low_word >> 16) & 0xFFu] ^ kTables[4][low_word >> 24] ^
                kTables[3][high_word & 0xFFu] ^ kTables[2][(high_word >> 8) & 0xFFu] ^
                kTables[1][(high_word >> 16) & 0xFFu] ^ kTables[0][high_word >> 24];
        bytes += 8;
        len -= 8;
    }

    // Tail: the remaining 0..7 bytes, one at a time.
    while (len-- > 0) {
        state = kTables[0][(state ^ *bytes++) & 0xFFu] ^ (state >> 8);
    }

    return ~state;
}

bool crc32_file(const std::string& path, std::uint32_t& out) {
    try {
        // u8path: treat `path` as UTF-8 on every platform. A plain
        // std::ifstream(std::string) would use the ANSI code page on Windows
        // and fail on non-ASCII folder names.
        std::ifstream input(fs::u8path(path), std::ios::binary);
        if (!input) return false;

        // Heap buffer: 1 MiB would be risky on a 1 MiB default Windows stack.
        std::vector<unsigned char> buffer(kFileChunkBytes);
        std::uint32_t crc = 0;

        for (;;) {
            input.read(reinterpret_cast<char*>(buffer.data()),
                       static_cast<std::streamsize>(buffer.size()));
            const std::streamsize bytes_read = input.gcount();
            if (bytes_read > 0) {
                crc = crc32_update(crc, buffer.data(), static_cast<std::size_t>(bytes_read));
            }
            if (!input) break;  // reached end of file OR a read error; checked below
        }

        // A clean finish means eofbit is set and badbit is not. Anything else
        // (e.g. reading a directory, I/O error mid-file) must not look like success.
        if (input.bad() || !input.eof()) return false;

        out = crc;
        return true;
    } catch (const std::exception&) {
        // bad_alloc, invalid UTF-8 in the path on Windows, ios failure, ...
        return false;
    }
}
