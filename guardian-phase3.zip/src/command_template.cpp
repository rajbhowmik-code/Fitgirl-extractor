#include "command_template.h"

#include <utility>

#include "command_line.h"
#include "ini_file.h"

namespace {

// 1-based character position, as people count when they look at the text.
std::string at_position(std::size_t zero_based_index) {
    return " (at character " + std::to_string(zero_based_index + 1) + ")";
}

// True if the '"' at `quote_index` is escaped by an odd number of backslashes.
bool is_escaped_quote(const std::string& text, std::size_t quote_index) {
    std::size_t backslash_count = 0;
    while (backslash_count < quote_index && text[quote_index - 1 - backslash_count] == '\\') {
        ++backslash_count;
    }
    return backslash_count % 2 == 1;
}

}  // namespace

bool CommandTemplate::parse(const std::string& template_text, CommandTemplate& out, std::string& error) {
    if (template_text.find_first_not_of(" \t") == std::string::npos) {
        error = "the extractor command is empty";
        return false;
    }
    if (template_text.find('\0') != std::string::npos) {
        error = "the extractor command contains a NUL character";
        return false;
    }

    std::vector<Part> parts;
    std::string literal;                      // literal text collected since the last placeholder
    bool inside_quotes = false;               // quote state of the literal template text
    bool previous_was_placeholder = false;    // the item just before the current position
    bool has_unit = false;
    bool has_output = false;

    std::size_t index = 0;
    while (index < template_text.size()) {
        const char character = template_text[index];

        if (character == '{') {
            if (index + 1 < template_text.size() && template_text[index + 1] == '{') {
                literal.push_back('{');  // "{{" is a literal brace
                index += 2;
                previous_was_placeholder = false;
                continue;
            }

            const std::size_t close_index = template_text.find('}', index + 1);
            if (close_index == std::string::npos) {
                error = "'{' without a closing '}'" + at_position(index) + "; write {{ for a literal '{'";
                return false;
            }
            const std::string name = template_text.substr(index + 1, close_index - index - 1);
            PartKind kind;
            if (name == "unit") {
                kind = PartKind::Unit;
            } else if (name == "out") {
                kind = PartKind::Output;
            } else {
                error = "unknown placeholder '{" + name + "}'" + at_position(index) +
                        "; supported placeholders are {unit} and {out}";
                return false;
            }

            if (inside_quotes) {
                error = "{" + name + "} is inside double quotes" + at_position(index) +
                        "; remove the quotes, Guardian adds them when needed";
                return false;
            }
            if (previous_was_placeholder) {
                error = "{" + name + "} directly follows another placeholder" + at_position(index) +
                        "; put a space between them";
                return false;
            }
            if (index > 0 && template_text[index - 1] == '\\') {
                error = "{" + name + "} directly follows a backslash" + at_position(index) +
                        "; write the folder separator inside the value instead";
                return false;
            }

            if (!literal.empty()) {
                parts.push_back(Part{PartKind::Literal, std::move(literal)});
                literal.clear();
            }
            parts.push_back(Part{kind, std::string()});
            (kind == PartKind::Unit ? has_unit : has_output) = true;
            index = close_index + 1;
            previous_was_placeholder = true;
            continue;
        }

        if (character == '}') {
            if (index + 1 < template_text.size() && template_text[index + 1] == '}') {
                literal.push_back('}');  // "}}" is a literal brace
                index += 2;
                previous_was_placeholder = false;
                continue;
            }
            error = "unmatched '}'" + at_position(index) + "; write }} for a literal '}'";
            return false;
        }

        if (character == '"') {
            if (previous_was_placeholder) {
                error = "a quote directly follows a placeholder" + at_position(index) +
                        "; put a space after the placeholder";
                return false;
            }
            if (!is_escaped_quote(template_text, index)) inside_quotes = !inside_quotes;
        }

        literal.push_back(character);
        ++index;
        previous_was_placeholder = false;
    }

    if (inside_quotes) {
        error = "unbalanced double quotes in the extractor command";
        return false;
    }
    if (!has_unit || !has_output) {
        error = std::string("the extractor command must contain both {unit} and {out}") +
                (has_unit ? " ({out} is missing)" : (has_output ? " ({unit} is missing)" : ""));
        return false;
    }

    if (!literal.empty()) parts.push_back(Part{PartKind::Literal, std::move(literal)});
    out.parts_ = std::move(parts);
    return true;
}

bool CommandTemplate::expand(const std::string& unit, const std::string& output_folder,
                             std::string& command_line, std::string& error) const {
    if (parts_.empty()) {
        error = "no extractor command is configured";
        return false;
    }
    if (unit.empty() || output_folder.empty()) {
        error = std::string(unit.empty() ? "the unit" : "the output folder") + " value is empty";
        return false;
    }
    // A NUL would silently cut the command line short inside the OS call.
    if (unit.find('\0') != std::string::npos || output_folder.find('\0') != std::string::npos) {
        error = "a value contains a NUL character";
        return false;
    }

    std::string result;
    for (const Part& part : parts_) {
        switch (part.kind) {
            case PartKind::Literal: result += part.text; break;
            case PartKind::Unit: result += quote_argument(unit); break;
            case PartKind::Output: result += quote_argument(output_folder); break;
        }
    }
    command_line = std::move(result);
    return true;
}

bool load_extractor_template(const std::string& ini_path, CommandTemplate& out, std::string& error) {
    IniFile ini;
    if (!load_ini_file(ini_path, ini, error)) return false;

    const std::optional<std::string> command_text = ini.get("extractor_cmd");
    if (!command_text.has_value()) {
        error = ini_path + ": missing 'extractor_cmd'";
        return false;
    }

    std::string parse_error;
    if (!CommandTemplate::parse(*command_text, out, parse_error)) {
        error = ini_path + ": extractor_cmd: " + parse_error;
        return false;
    }
    return true;
}
