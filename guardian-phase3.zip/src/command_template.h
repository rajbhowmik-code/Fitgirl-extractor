// The extractor command template from guardian.ini, e.g.
//
//     extractor_cmd = "C:\Repack\setup.exe /unit {unit} /out {out}"
//
// Placeholders:
//     {unit}  the archive piece being extracted (a full path, supplied by the caller)
//     {out}   the folder the extractor must write into
//     {{ }}   a literal '{' or '}'
//
// SAFETY / HOW VALUES ARE INSERTED
//   Guardian inserts each value as exactly ONE argument and adds the quotes
//   itself when they are needed (quote_argument in command_line.h). So:
//     * Paths with spaces, quotes, '&', '%' ... work and cannot add extra
//       arguments (no command injection through a crafted file name).
//     * Do NOT write quotes around a placeholder. {unit} is right; "{unit}"
//       is rejected, because quoting twice would break the argument.
//     * A placeholder cannot directly follow a backslash (C:\out\{out}) or
//       directly touch a quote or another placeholder. These forms cannot be
//       quoted reliably, so they are rejected with a message when the template
//       is parsed (at start-up, before any unit runs).
//   Both {unit} and {out} must appear: without them every unit would run the
//   same command, or the output would not land in the staging folder.
//   Because no shell is used, the template must not rely on cmd.exe features
//   (%VAR%, &&, >). To use them, start cmd.exe explicitly in the template.
#pragma once

#include <string>
#include <vector>

class CommandTemplate {
public:
    // Parses and validates `template_text`. On failure returns false, sets
    // `error` (with the character position) and leaves `out` unchanged.
    static bool parse(const std::string& template_text, CommandTemplate& out, std::string& error);

    // Builds the final command line for one unit. Fails (with `error`) if a
    // value is empty or contains a NUL character. On a default-constructed
    // (empty) template it fails as well.
    bool expand(const std::string& unit, const std::string& output_folder, std::string& command_line,
                std::string& error) const;

    bool is_empty() const { return parts_.empty(); }

private:
    enum class PartKind { Literal, Unit, Output };
    struct Part {
        PartKind kind;
        std::string text;  // only used for Literal
    };
    std::vector<Part> parts_;
};

// Loads `extractor_cmd` from the INI file at `ini_path` and parses it.
// Fails with a readable message if the file or key is missing or the
// template is invalid.
bool load_extractor_template(const std::string& ini_path, CommandTemplate& out, std::string& error);
