// Helpers for building and reading command lines with the Windows rules
// (the rules used by CommandLineToArgvW and the Microsoft C runtime).
//
// Why this exists: on Windows a process receives ONE command-line string, and
// every program splits it into arguments itself. If we paste a file name that
// contains a space or a quote into that string without escaping it, the
// extractor sees different arguments than we intended (and a hostile file name
// could even inject extra arguments). quote_argument() escapes a value so that
// split_command_line() - and every normal Windows program - reads it back as
// exactly ONE argument with exactly the original characters.
//
// No shell (cmd.exe) is ever involved, so shell characters such as & | % ^ need
// no escaping.
#pragma once

#include <string>
#include <vector>

// Returns `argument` ready to be pasted into a command line.
//   * Plain values (no space, tab, newline, vertical tab or quote, and not
//     empty) are returned unchanged.
//   * Everything else is wrapped in double quotes; embedded quotes become \"
//     and backslashes that precede a quote (or the closing quote) are doubled.
// Round-trip guarantee: split_command_line(quote_argument(v)) == { v }.
std::string quote_argument(const std::string& argument);

// Splits a command line into arguments using the Windows rules:
//   * Space and tab separate arguments (outside quotes).
//   * 2n backslashes + '"'   -> n backslashes, and the quote toggles quoting.
//   * 2n+1 backslashes + '"' -> n backslashes and a literal quote.
//   * Backslashes not followed by a quote are literal.
//   * Inside quotes, "" produces one literal quote (modern C runtime rule).
//   * "" on its own is an empty argument.
// Unlike the C runtime this treats the program name (first argument) like any
// other argument. Used by the POSIX run_process and by the tests.
std::vector<std::string> split_command_line(const std::string& command_line);
