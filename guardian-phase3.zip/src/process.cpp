#include "process.h"

#include <climits>
#include <cstddef>
#include <system_error>
#include <vector>

#include "command_line.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <cerrno>
#include <csignal>
#ifdef __linux__
#include <sys/prctl.h>
#endif
#endif

namespace {

// Rejects command lines that can never work, with a clear message, before any
// operating-system call is made.
bool check_command_line_text(const std::string& command_line, std::string& error) {
    if (command_line.find_first_not_of(" \t") == std::string::npos) {
        error = "command line is empty";
        return false;
    }
    // A NUL would silently cut the command line short inside the OS call.
    if (command_line.find('\0') != std::string::npos) {
        error = "command line contains a NUL character";
        return false;
    }
    return true;
}

}  // namespace

#ifdef _WIN32
// ============================================================================
// Windows: CreateProcessW + Job Object
// ============================================================================
namespace {

// CreateProcessW limit: 32,767 characters INCLUDING the terminating NUL.
constexpr std::size_t kMaxCommandLineChars = 32766;

// Owns a HANDLE; always closed, even on early return.
class ScopedHandle {
public:
    explicit ScopedHandle(HANDLE handle = nullptr) : handle_(handle) {}
    ~ScopedHandle() {
        if (is_valid()) CloseHandle(handle_);
    }
    ScopedHandle(const ScopedHandle&) = delete;
    ScopedHandle& operator=(const ScopedHandle&) = delete;
    bool is_valid() const { return handle_ != nullptr && handle_ != INVALID_HANDLE_VALUE; }
    HANDLE get() const { return handle_; }

private:
    HANDLE handle_;
};

std::string describe_win32_failure(const char* action, DWORD error_code) {
    return std::string(action) + ": " + std::system_category().message(static_cast<int>(error_code));
}

// UTF-8 -> UTF-16. Fails (instead of silently substituting characters) when the
// text is not valid UTF-8.
bool utf8_to_wide(const std::string& text, std::wstring& wide) {
    if (text.empty()) {
        wide.clear();
        return true;
    }
    if (text.size() > static_cast<std::size_t>(INT_MAX)) return false;
    const int needed = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(),
                                           static_cast<int>(text.size()), nullptr, 0);
    if (needed <= 0) return false;
    wide.resize(static_cast<std::size_t>(needed));
    const int written = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(),
                                            static_cast<int>(text.size()), &wide[0], needed);
    return written == needed;
}

// Best-effort stop of a child we could not finish setting up. It never ran
// (still suspended) or just started, so killing it loses nothing.
void kill_unstarted_child(HANDLE process) {
    TerminateProcess(process, 1);
    WaitForSingleObject(process, 5000);
}

}  // namespace

bool run_process(const std::string& command_line, int& exit_code, std::string* error) {
    std::string local_error;
    std::string& error_text = (error != nullptr) ? *error : local_error;
    error_text.clear();

    if (!check_command_line_text(command_line, error_text)) return false;

    std::wstring wide_command_line;
    if (!utf8_to_wide(command_line, wide_command_line)) {
        error_text = "command line is not valid UTF-8";
        return false;
    }
    if (wide_command_line.size() > kMaxCommandLineChars) {
        error_text = "command line is too long (limit is " + std::to_string(kMaxCommandLineChars) +
                     " characters)";
        return false;
    }
    // CreateProcessW may modify the buffer, so it must be writable and NUL-terminated.
    std::vector<wchar_t> command_buffer(wide_command_line.begin(), wide_command_line.end());
    command_buffer.push_back(L'\0');

    // The job is created first so the child can be put into it BEFORE it runs
    // a single instruction (it starts suspended): it cannot escape by starting
    // grandchildren early.
    ScopedHandle job(CreateJobObjectW(nullptr, nullptr));
    if (!job.is_valid()) {
        error_text = describe_win32_failure("cannot create job object", GetLastError());
        return false;
    }
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits = {};
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (!SetInformationJobObject(job.get(), JobObjectExtendedLimitInformation, &limits,
                                 sizeof(limits))) {
        error_text = describe_win32_failure("cannot configure job object", GetLastError());
        return false;
    }

    STARTUPINFOW startup_info = {};
    startup_info.cb = sizeof(startup_info);
    PROCESS_INFORMATION process_info = {};
    // lpApplicationName = nullptr: the program is the first token of the command line.
    // bInheritHandles = FALSE: the child does not get our open file handles
    // (e.g. the journal). A console child still shares our console for output.
    if (!CreateProcessW(nullptr, command_buffer.data(), nullptr, nullptr, FALSE, CREATE_SUSPENDED,
                        nullptr, nullptr, &startup_info, &process_info)) {
        error_text = describe_win32_failure("cannot start program", GetLastError());
        return false;
    }
    ScopedHandle process(process_info.hProcess);
    ScopedHandle main_thread(process_info.hThread);

    if (!AssignProcessToJobObject(job.get(), process.get())) {
        error_text = describe_win32_failure("cannot add program to job object", GetLastError());
        kill_unstarted_child(process.get());
        return false;
    }
    if (ResumeThread(main_thread.get()) == static_cast<DWORD>(-1)) {
        error_text = describe_win32_failure("cannot resume program", GetLastError());
        kill_unstarted_child(process.get());
        return false;
    }

    if (WaitForSingleObject(process.get(), INFINITE) != WAIT_OBJECT_0) {
        error_text = describe_win32_failure("waiting for program failed", GetLastError());
        return false;  // closing the job (scope exit) kills the program
    }

    DWORD raw_exit_code = 0;
    if (!GetExitCodeProcess(process.get(), &raw_exit_code)) {
        error_text = describe_win32_failure("cannot read exit code", GetLastError());
        return false;
    }
    exit_code = static_cast<int>(raw_exit_code);
    return true;  // `job` closes here and ends any processes the program left behind
}

#else
// ============================================================================
// POSIX (Linux / macOS): fork + execvp. Mainly so the project builds and the
// tests run on non-Windows machines; Windows is the primary target.
// ============================================================================
namespace {

// Owns a file descriptor; always closed, even on early return.
class ScopedDescriptor {
public:
    explicit ScopedDescriptor(int descriptor = -1) : descriptor_(descriptor) {}
    ~ScopedDescriptor() { reset(); }
    ScopedDescriptor(const ScopedDescriptor&) = delete;
    ScopedDescriptor& operator=(const ScopedDescriptor&) = delete;
    int get() const { return descriptor_; }
    void reset() {
        if (descriptor_ >= 0) ::close(descriptor_);
        descriptor_ = -1;
    }

private:
    int descriptor_;
};

std::string describe_errno(const char* action, int error_number) {
    return std::string(action) + ": " + std::generic_category().message(error_number);
}

// Waits for `child`, retrying when a signal interrupts the wait.
bool wait_for_child(pid_t child, int& status) {
    for (;;) {
        const pid_t result = ::waitpid(child, &status, 0);
        if (result == child) return true;
        if (result < 0 && errno == EINTR) continue;
        return false;
    }
}

}  // namespace

bool run_process(const std::string& command_line, int& exit_code, std::string* error) {
    std::string local_error;
    std::string& error_text = (error != nullptr) ? *error : local_error;
    error_text.clear();

    if (!check_command_line_text(command_line, error_text)) return false;

    // Build argv BEFORE fork(): after fork only async-signal-safe calls are allowed.
    const std::vector<std::string> arguments = split_command_line(command_line);
    if (arguments.empty()) {
        error_text = "command line is empty";
        return false;
    }
    std::vector<char*> argument_pointers;
    argument_pointers.reserve(arguments.size() + 1);
    for (const std::string& argument : arguments) {
        argument_pointers.push_back(const_cast<char*>(argument.c_str()));
    }
    argument_pointers.push_back(nullptr);

    // Pipe used by the child to report a failed exec(): its write end closes
    // automatically on a successful exec (FD_CLOEXEC), so "end of file" on the
    // read end means the program really started.
    int pipe_ends[2] = {-1, -1};
    if (::pipe(pipe_ends) != 0) {
        error_text = describe_errno("cannot create pipe", errno);
        return false;
    }
    ScopedDescriptor read_end(pipe_ends[0]);
    ScopedDescriptor write_end(pipe_ends[1]);
    if (::fcntl(read_end.get(), F_SETFD, FD_CLOEXEC) != 0 ||
        ::fcntl(write_end.get(), F_SETFD, FD_CLOEXEC) != 0) {
        error_text = describe_errno("cannot configure pipe", errno);
        return false;
    }

    const pid_t parent_pid = ::getpid();
    const pid_t child = ::fork();
    if (child < 0) {
        error_text = describe_errno("cannot start program (fork)", errno);
        return false;
    }

    if (child == 0) {
#ifdef __linux__
        // If Guardian dies, the kernel kills this child. Re-check the parent
        // afterwards in case it died between fork() and prctl().
        ::prctl(PR_SET_PDEATHSIG, SIGKILL);
        if (::getppid() != parent_pid) ::_exit(127);
#else
        (void)parent_pid;
#endif
        ::execvp(argument_pointers[0], argument_pointers.data());
        const int exec_error = errno;
        [[maybe_unused]] const ssize_t ignored = ::write(write_end.get(), &exec_error, sizeof(exec_error));
        ::_exit(127);
    }

    write_end.reset();  // the parent must close its copy or the read below never ends

    int child_exec_error = 0;
    std::size_t bytes_received = 0;
    while (bytes_received < sizeof(child_exec_error)) {
        const ssize_t count = ::read(read_end.get(), reinterpret_cast<char*>(&child_exec_error) + bytes_received,
                                     sizeof(child_exec_error) - bytes_received);
        if (count > 0) {
            bytes_received += static_cast<std::size_t>(count);
        } else if (count == 0) {
            break;  // end of file: exec succeeded
        } else if (errno != EINTR) {
            break;
        }
    }

    int status = 0;
    const bool waited = wait_for_child(child, status);

    if (bytes_received == sizeof(child_exec_error)) {
        error_text = describe_errno("cannot start program", child_exec_error);
        return false;
    }
    if (!waited) {
        error_text = describe_errno("waiting for program failed", errno);
        return false;
    }

    if (WIFEXITED(status)) {
        exit_code = WEXITSTATUS(status);
    } else if (WIFSIGNALED(status)) {
        exit_code = 128 + WTERMSIG(status);
    } else {
        error_text = "program ended in an unknown state";
        return false;
    }
    return true;
}

#endif  // _WIN32

int run_process(const std::string& command_line) {
    int exit_code = 0;
    if (!run_process(command_line, exit_code, nullptr)) return kProcessStartFailed;
    return exit_code;
}
