// Crash-safe journal: an append-only text file, one record per line.
//
// Line format (task 1.2):
//     <type>|<field>|<field>|...|<crc32 hex>
//   * The CRC-32 covers every byte BEFORE the last '|' and is written as exactly
//     8 lowercase hex digits.
//   * '|', '%', and control characters (< 0x20, 0x7F) inside the type/fields are
//     percent-escaped ("%7c", "%25", "%0a", ...). So a line never contains a raw
//     newline or separator from the data, and a hostile file name (or one with a
//     '|' in it) cannot forge or split records.
//   * Bytes >= 0x80 (UTF-8 text) are stored as-is.
//
// Durability rules (tasks 1.3 / 1.4):
//   * A record counts only if its line is complete: ends with '\n' AND passes
//     the CRC check.
//   * After a power cut, only the LAST line may be damaged (it was being
//     written). Such a tail is ignored on load and physically removed before the
//     next append, so it can never end up "in the middle" of the file.
//   * A damaged line FOLLOWED by more data means real corruption: load() fails
//     and append() refuses to write.
//
// Paths are UTF-8 std::strings on every platform.
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

// One journal entry, e.g. {"UNIT_DONE", {"fg-1.bin"}}.
struct Record {
    std::string type;                 // never empty
    std::vector<std::string> fields;  // may be empty; individual fields may be empty

    bool operator==(const Record& other) const {
        return type == other.type && fields == other.fields;
    }
    bool operator!=(const Record& other) const { return !(*this == other); }
};

// Upper bound for one encoded line (without '\n'). Enforced when writing AND
// when reading, so (a) we never write a line we could not read back and (b) a
// corrupt file full of garbage without newlines cannot make us allocate
// unbounded memory.
inline constexpr std::size_t kMaxJournalLineBytes = 1u << 20;  // 1 MiB

// Encodes a record as one line WITHOUT the trailing '\n'.
// Throws std::invalid_argument if record.type is empty, and std::length_error
// if the encoded line would exceed kMaxJournalLineBytes.
std::string make_line(const Record& record);

// Decodes one line (without '\n'). Returns false when the line is malformed:
// bad/missing/non-canonical checksum, checksum mismatch (flipped or truncated
// line), invalid escape, raw control character, empty type, or too long.
// `out` is modified only when true is returned.
bool parse_line(const std::string& line, Record& out);

// Outcome of Journal::load().
struct LoadResult {
    std::vector<Record> records;       // valid records, in file order (empty if !ok)
    bool ok = true;                    // false: unreadable file or damage in the middle
    std::string error;                 // human-readable reason when !ok
    bool tail_dropped = false;         // true: a damaged/incomplete LAST line was ignored
    std::uint64_t valid_bytes = 0;     // size of the good prefix (== file size unless tail_dropped)
};

class Journal {
public:
    explicit Journal(std::string path);

    // Durably appends one record: write + flush to disk (FlushFileBuffers on
    // Windows, fsync on POSIX) before returning true. On false, `*error` (if
    // given) explains why, and the record must be treated as NOT recorded
    // (a later retry may produce a duplicate line if only the flush failed;
    // journal records are designed to be idempotent).
    //
    // The first append in the life of a Journal object first repairs a torn
    // tail left by a previous crash (see header comment). Not thread-safe.
    bool append(const Record& record, std::string* error = nullptr);

    // Reads every valid record. A missing file is NOT an error (fresh start).
    // Read-only: never modifies the file.
    LoadResult load() const;

    const std::string& path() const { return path_; }

private:
    bool ensure_tail_clean(std::string& error);

    std::string path_;
    bool tail_checked_ = false;  // reset to false whenever a write may have left a torn tail
};
