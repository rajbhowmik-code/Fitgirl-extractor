// Command-line arguments as UTF-8, on every platform.
//
// On Windows, main(argc, argv) receives arguments converted to the ANSI code
// page, which turns non-ASCII file names (e.g. Bengali or accented folder
// names) into '?' characters. This helper reads the real UTF-16 command line
// instead and converts it to UTF-8. On other platforms argv is used as is.
//
// Used by the small helper programs (fake_extractor and the test helpers).
// On Windows the program must link shell32 (CMake does this).
#pragma once

#include <cstddef>
#include <string>
#include <utility>
#include <vector>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <shellapi.h>
#endif

#ifdef _WIN32
namespace utf8_arguments_detail {

// UTF-16 -> UTF-8; false if the text is not valid UTF-16 (e.g. a lone surrogate).
inline bool wide_to_utf8(const wchar_t* wide, std::string& utf8) {
    const int needed = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, wide, -1, nullptr, 0, nullptr, nullptr);
    if (needed <= 0) return false;
    utf8.assign(static_cast<std::size_t>(needed), '\0');  // size includes the terminating NUL
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, wide, -1, &utf8[0], needed, nullptr, nullptr) !=
        needed) {
        return false;
    }
    utf8.pop_back();  // drop the NUL
    return true;
}

}  // namespace utf8_arguments_detail
#endif

// Returns all arguments including the program name (index 0).
// Returns an empty vector if the command line cannot be read or converted.
inline std::vector<std::string> utf8_command_line_arguments(int argc, char** argv) {
    std::vector<std::string> arguments;
#ifdef _WIN32
    (void)argc;
    (void)argv;
    int wide_count = 0;
    LPWSTR* wide_arguments = CommandLineToArgvW(GetCommandLineW(), &wide_count);
    if (wide_arguments == nullptr) return arguments;

    bool all_converted = true;
    for (int index = 0; index < wide_count && all_converted; ++index) {
        std::string converted;
        all_converted = utf8_arguments_detail::wide_to_utf8(wide_arguments[index], converted);
        if (all_converted) arguments.push_back(std::move(converted));
    }
    LocalFree(wide_arguments);
    if (!all_converted) arguments.clear();
#else
    for (int index = 0; index < argc; ++index) arguments.emplace_back(argv[index]);
#endif
    return arguments;
}
