// Deterministic "pretend extraction" content, shared by the fake_extractor
// program and by the tests.
//
// Because the content is a pure function of the unit name, a test can compute
// the EXPECTED files (and, with crc32, the expected manifest) for a unit
// without running anything, then compare them with what the extractor wrote.
// That is what the verification tests (task 4.2 and later) rely on.
#pragma once

#include <string>
#include <vector>

struct FakeFile {
    std::string relative_path;  // always '/'-separated, never absolute, never contains ".."
    std::string content;        // raw bytes
};

// The files "extracted" from `unit`. Only the part of `unit` after the last '/'
// or '\' is used, so "fg-1.bin", "D:\repack\fg-1.bin" and "/repack/fg-1.bin" all
// give the same result.
//
// Properties the tests depend on:
//   * Same input -> identical output on every run, machine and compiler.
//   * Different unit names -> different content.
//   * Files live in folders named after the unit (e.g. "fg-1/data/medium.dat"),
//     so different units never write the same path.
//   * Includes an empty file, a 1-byte file, a file larger than 64 KiB and a
//     file in nested folders, to cover the awkward cases of later tasks.
//   * Folder names are made of letters, digits, '_' and '-' only; every other
//     character in the unit name becomes '_'. (Names that differ only in such
//     characters share folder names but still get different content.)
std::vector<FakeFile> make_fake_unit_files(const std::string& unit);
