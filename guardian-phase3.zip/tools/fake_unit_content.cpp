#include "fake_unit_content.h"

#include <cstddef>
#include <cstdint>

namespace {

// std::mt19937 and friends are not used on purpose: the standard does not
// fix the output of its distributions, so results could differ between
// compilers. SplitMix64 is a few lines and produces identical bytes everywhere.
constexpr std::uint64_t kGoldenGamma = 0x9E3779B97F4A7C15ull;

class SplitMix64 {
public:
    explicit SplitMix64(std::uint64_t seed) : state_(seed) {}
    std::uint64_t next() {
        state_ += kGoldenGamma;
        std::uint64_t mixed = state_;
        mixed = (mixed ^ (mixed >> 30)) * 0xBF58476D1CE4E5B9ull;
        mixed = (mixed ^ (mixed >> 27)) * 0x94D049BB133111EBull;
        return mixed ^ (mixed >> 31);
    }

private:
    std::uint64_t state_;
};

// FNV-1a: a simple, well-known, platform-independent string hash.
std::uint64_t fnv1a_64(const std::string& text) {
    std::uint64_t hash = 0xCBF29CE484222325ull;
    for (const char character : text) {
        hash ^= static_cast<unsigned char>(character);
        hash *= 0x100000001B3ull;
    }
    return hash;
}

// `size` pseudo-random bytes derived only from `seed`. Bytes are cut from each
// 64-bit word in a fixed (little-endian) order, so the result never depends on
// the CPU's endianness.
std::string pseudo_random_bytes(std::uint64_t seed, std::size_t size) {
    std::string bytes;
    bytes.reserve(size);
    SplitMix64 generator(seed);
    while (bytes.size() < size) {
        const std::uint64_t word = generator.next();
        for (int shift = 0; shift < 64 && bytes.size() < size; shift += 8) {
            bytes.push_back(static_cast<char>((word >> shift) & 0xFFu));
        }
    }
    return bytes;
}

// The part of `unit` after the last '/' or '\' (handles both path styles on
// every platform, unlike std::filesystem which follows the host OS only).
std::string base_name_of(const std::string& unit) {
    const std::size_t separator = unit.find_last_of("/\\");
    return (separator == std::string::npos) ? unit : unit.substr(separator + 1);
}

// "fg-1.bin" -> "fg-1"; every character outside [A-Za-z0-9_-] becomes '_'.
std::string folder_name_of(const std::string& base_name) {
    std::string stem = base_name;
    const std::size_t dot = stem.find_last_of('.');
    if (dot != std::string::npos && dot > 0) stem.resize(dot);  // keep names like ".hidden"

    for (char& character : stem) {
        const bool allowed = (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z') ||
                             (character >= '0' && character <= '9') || character == '_' || character == '-';
        if (!allowed) character = '_';
    }
    return stem.empty() ? std::string("unit") : stem;
}

}  // namespace

std::vector<FakeFile> make_fake_unit_files(const std::string& unit) {
    const std::string base_name = base_name_of(unit);
    const std::string folder = folder_name_of(base_name);
    const std::uint64_t unit_seed = fnv1a_64(base_name);

    struct Plan {
        const char* relative_path;
        std::size_t size;
    };
    // Sizes chosen to cover: empty, 1 byte, just over 64 KiB, and a larger file.
    const Plan plan[] = {
        {"data/tiny.dat", 1},
        {"data/medium.dat", 70000},
        {"data/nested/deep/large.dat", 300000},
        {"empty.dat", 0},
    };

    std::vector<FakeFile> files;

    // A small human-readable text file (handy when someone looks at the output).
    files.push_back(FakeFile{folder + "/readme.txt",
                             "fake extractor output\nunit: " + base_name + "\n"});

    std::uint64_t file_index = 1;
    for (const Plan& entry : plan) {
        // Each file gets its own seed so no two files share content.
        const std::uint64_t file_seed = unit_seed ^ (file_index * kGoldenGamma);
        files.push_back(FakeFile{folder + "/" + entry.relative_path, pseudo_random_bytes(file_seed, entry.size)});
        ++file_index;
    }
    return files;
}
