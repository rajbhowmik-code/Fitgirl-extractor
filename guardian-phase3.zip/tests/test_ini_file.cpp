// Tests for ini_file.h: the guardian.ini reader.
#include "test_common.h"

#include <string>

#include "ini_file.h"
#include "test_util.h"

namespace {

// Parses text that must be valid and returns the result.
IniFile parse_ok(const std::string& text) {
    IniFile ini;
    std::string error;
    const bool ok = parse_ini_text(text, ini, error);
    assert(ok && error.empty());
    return ini;
}

// Parses text that must be rejected and returns the error message.
std::string parse_error_of(const std::string& text) {
    IniFile ini;
    ini.values["sentinel"] = "unchanged";
    std::string error;
    const bool ok = parse_ini_text(text, ini, error);
    assert(!ok && !error.empty());
    assert(ini.values.size() == 1 && ini.values.at("sentinel") == "unchanged");  // `out` untouched on failure
    return error;
}

void test_basic_values_and_trimming() {
    const IniFile ini = parse_ok("extractor_cmd = \"setup.exe /unit {unit} /out {out}\"\n"
                                 "  unit_pattern\t=\t*.bin  \n");
    assert(ini.get("extractor_cmd").value() == "setup.exe /unit {unit} /out {out}");  // wrapping quotes removed
    assert(ini.get("unit_pattern").value() == "*.bin");
    assert(!ini.get("missing").has_value());
}

void test_keys_are_case_insensitive() {
    const IniFile ini = parse_ok("Extractor_Cmd = x\n");
    assert(ini.get("extractor_cmd").value() == "x");
    assert(ini.get("EXTRACTOR_CMD").value() == "x");
}

void test_comments_blank_lines_and_line_endings() {
    const std::string text = "; comment\r\n# another\r\n\r\n   \r\na = 1\r\nb = 2";  // CRLF, no final newline
    const IniFile ini = parse_ok(text);
    assert(ini.values.size() == 2 && ini.get("a").value() == "1" && ini.get("b").value() == "2");

    assert(parse_ok("").values.empty());
    assert(parse_ok("\n\n").values.empty());
}

void test_utf8_bom_is_ignored() {
    const IniFile ini = parse_ok("\xEF\xBB\xBF" "a = 1\n");  // what Notepad writes
    assert(ini.get("a").value() == "1");
    assert(parse_ok("\xEF\xBB\xBF").values.empty());
}

void test_values_keep_inner_text_exactly() {
    // ';' and '#' inside a value are data (command lines use them), and '=' after the first one too.
    const IniFile ini = parse_ok("a = x ; not a comment # nor this\nb = k=v\nc =\n");
    assert(ini.get("a").value() == "x ; not a comment # nor this");
    assert(ini.get("b").value() == "k=v");
    assert(ini.get("c").value().empty());  // empty value is allowed
}

void test_wrapping_quote_rule() {
    // Removed only when exactly one pair wraps the whole value with no other quote inside.
    assert(parse_ok("a = \"x y\"\n").get("a").value() == "x y");
    assert(parse_ok("a = \"\"\n").get("a").value().empty());
    assert(parse_ok("a = \"C:\\p q\\a.exe\" /f \"{unit}\"\n").get("a").value() == "\"C:\\p q\\a.exe\" /f \"{unit}\"");
    assert(parse_ok("a = \"unterminated\n").get("a").value() == "\"unterminated");
    assert(parse_ok("a = \"\n").get("a").value() == "\"");  // a lone quote is not a pair
}

void test_errors_name_the_line() {
    assert(parse_error_of("a = 1\nthis is wrong\n").find("line 2") != std::string::npos);
    assert(parse_error_of("= 5\n").find("line 1") != std::string::npos);        // missing key
    assert(parse_error_of("bad key = 5\n").find("line 1") != std::string::npos);  // space inside key
    assert(parse_error_of("a = 1\na = 2\n").find("duplicate") != std::string::npos);
    assert(parse_error_of("A = 1\na = 2\n").find("line 2") != std::string::npos);   // case-insensitive duplicate
    assert(parse_error_of("[section]\n").find("line 1") != std::string::npos);      // sections unsupported
}

void test_load_from_file() {
    test_util::TempDir dir("ini_load");

    // Folder with a non-ASCII name: the path must be handled as UTF-8.
    const std::string path = dir.file(u8"\u09AC\u09BE\u0982\u09B2\u09BE.ini");
    test_util::write_file(path, "extractor_cmd = x {unit} {out}\n");
    IniFile ini;
    std::string error;
    assert(load_ini_file(path, ini, error) && error.empty());
    assert(ini.get("extractor_cmd").value() == "x {unit} {out}");
}

void test_load_failures() {
    test_util::TempDir dir("ini_fail");
    IniFile ini;
    std::string error;

    assert(!load_ini_file(dir.file("nope.ini"), ini, error) && error.find("nope.ini") != std::string::npos);

    error.clear();
    assert(!load_ini_file(dir.path_utf8(), ini, error) && !error.empty());  // a folder, not a file

    test_util::write_file(dir.file("bad.ini"), "a = 1\nnonsense\n");
    error.clear();
    assert(!load_ini_file(dir.file("bad.ini"), ini, error));
    assert(error.find("bad.ini") != std::string::npos && error.find("line 2") != std::string::npos);

    // Size limit: exactly at the limit is fine, one byte over is rejected.
    const std::string filler_key = "k = ";
    std::string at_limit = filler_key + std::string(kMaxIniFileBytes - filler_key.size(), 'x');
    test_util::write_file(dir.file("limit.ini"), at_limit);
    error.clear();
    assert(load_ini_file(dir.file("limit.ini"), ini, error) && error.empty());

    test_util::write_file(dir.file("over.ini"), at_limit + "x");
    error.clear();
    assert(!load_ini_file(dir.file("over.ini"), ini, error) && error.find("too large") != std::string::npos);
}

}  // namespace

int main() {
    test_basic_values_and_trimming();
    test_keys_are_case_insensitive();
    test_comments_blank_lines_and_line_endings();
    test_utf8_bom_is_ignored();
    test_values_keep_inner_text_exactly();
    test_wrapping_quote_rule();
    test_errors_name_the_line();
    test_load_from_file();
    test_load_failures();
    return 0;
}
