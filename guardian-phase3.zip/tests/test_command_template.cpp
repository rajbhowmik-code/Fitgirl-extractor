// Task 3.2: extractor command template with {unit} / {out} substitution.
#include "test_common.h"

#include <string>
#include <vector>

#include "command_line.h"
#include "command_template.h"
#include "test_util.h"

namespace {

using Arguments = std::vector<std::string>;

CommandTemplate parse_ok(const std::string& text) {
    CommandTemplate parsed;
    std::string error;
    const bool ok = CommandTemplate::parse(text, parsed, error);
    assert(ok && error.empty());
    return parsed;
}

// Parses text that must be rejected; returns the message.
std::string parse_error_of(const std::string& text) {
    CommandTemplate parsed;
    std::string error;
    const bool ok = CommandTemplate::parse(text, parsed, error);
    assert(!ok && !error.empty());
    assert(parsed.is_empty());  // `out` untouched on failure
    return error;
}

std::string expand_ok(const CommandTemplate& command_template, const std::string& unit, const std::string& out) {
    std::string command_line;
    std::string error;
    const bool ok = command_template.expand(unit, out, command_line, error);
    assert(ok && error.empty());
    return command_line;
}

bool contains(const std::string& text, const std::string& part) { return text.find(part) != std::string::npos; }

// The task's "Done when" check: correct substitution, including paths with spaces.
void test_simple_substitution() {
    const CommandTemplate command_template = parse_ok("setup.exe /unit {unit} /out {out}");
    assert(expand_ok(command_template, R"(D:\repack\fg-1.bin)", R"(D:\game\.staging\fg-1)") ==
           R"(setup.exe /unit D:\repack\fg-1.bin /out D:\game\.staging\fg-1)");
}

void test_paths_with_spaces_become_one_argument() {
    const CommandTemplate command_template = parse_ok("setup.exe /unit {unit} /out {out}");
    const std::string unit = R"(D:\My Repacks\Big Game\fg-1.bin)";
    const std::string out = R"(D:\Games\Big Game\.staging\fg-1)";

    const std::string command_line = expand_ok(command_template, unit, out);
    assert(command_line == R"(setup.exe /unit "D:\My Repacks\Big Game\fg-1.bin" /out "D:\Games\Big Game\.staging\fg-1")");
    assert((split_command_line(command_line) == Arguments{"setup.exe", "/unit", unit, "/out", out}));
}

void test_value_glued_to_text_and_trailing_backslash() {
    // Inno-Setup style "/DIR=<path>"; a folder path ending in a backslash.
    const CommandTemplate command_template = parse_ok("setup.exe /DIR={out} /unit {unit}");
    const std::string out = R"(D:\Big Games\out\)";
    const std::string command_line = expand_ok(command_template, "u", out);
    assert(command_line == R"(setup.exe /DIR="D:\Big Games\out\\" /unit u)");
    assert((split_command_line(command_line) == Arguments{"setup.exe", "/DIR=" + out, "/unit", "u"}));
}

void test_hostile_values_cannot_add_arguments() {
    const CommandTemplate command_template = parse_ok("tool {unit} {out}");
    const std::string hostile_unit = R"(a" --evil "b)";
    const std::string hostile_out = "x & del /q *.* & \" ^ %PATH% | y";
    const Arguments parsed = split_command_line(expand_ok(command_template, hostile_unit, hostile_out));
    assert((parsed == Arguments{"tool", hostile_unit, hostile_out}));
}

void test_values_with_non_ascii_text() {
    const CommandTemplate command_template = parse_ok("tool {unit} {out}");
    const std::string unit = u8"\u09B0\u09BE\u099C fg-1.bin";  // Bengali letters + a space
    const std::string out = u8"D:\\g\u00E4mes\\";
    assert((split_command_line(expand_ok(command_template, unit, out)) == Arguments{"tool", unit, out}));
}

void test_placeholder_can_repeat_and_order_is_free() {
    const CommandTemplate command_template = parse_ok("x {out} {unit} {out}");
    assert(expand_ok(command_template, "u", "o") == "x o u o");
}

void test_literal_braces() {
    const CommandTemplate command_template = parse_ok("x {{GUID}} {unit} {out}");
    assert(expand_ok(command_template, "u", "o") == "x {GUID} u o");
}

void test_quotes_in_the_literal_part_are_kept() {
    const CommandTemplate command_template = parse_ok(R"("C:\Program Files\Repack\setup.exe" /unit {unit} /out {out})");
    assert(expand_ok(command_template, "u", "o") == R"("C:\Program Files\Repack\setup.exe" /unit u /out o)");

    // An escaped quote in the literal part does not count as opening a quoted section.
    parse_ok(R"(x \"{unit}\" {out})");
}

void test_template_errors() {
    assert(contains(parse_error_of(""), "empty"));
    assert(contains(parse_error_of("   \t"), "empty"));
    assert(contains(parse_error_of("x {unit}"), "{out}"));            // {out} missing
    assert(contains(parse_error_of("x {out}"), "{unit}"));            // {unit} missing
    assert(contains(parse_error_of("x y z"), "{unit}"));              // neither present
    assert(contains(parse_error_of("x {unti} {out}"), "{unti}"));     // typo is named
    assert(contains(parse_error_of("x {UNIT} {out}"), "{UNIT}"));     // placeholders are case-sensitive
    assert(contains(parse_error_of("x {unit {out}"), "unknown"));     // '}' found, name is "unit {out"
    assert(contains(parse_error_of("x {unit} {out} {"), "closing"));  // unclosed brace
    assert(contains(parse_error_of("x {unit} {out} }"), "unmatched"));

    // Placeholders that cannot be quoted reliably.
    assert(contains(parse_error_of(R"(x "{unit}" {out})"), "inside double quotes"));
    assert(contains(parse_error_of(R"(x "a {unit}" {out})"), "inside double quotes"));
    assert(contains(parse_error_of("x {unit}{out}"), "another placeholder"));
    assert(contains(parse_error_of(R"(x {unit}"y" {out})"), "quote directly follows"));
    assert(contains(parse_error_of(R"(x C:\dir\{unit} {out})"), "backslash"));
    assert(contains(parse_error_of(R"(x "unbalanced {unit} {out})"), "inside double quotes"));
    assert(contains(parse_error_of(R"(x "unbalanced" "{unit} {out})"), "inside double quotes"));
    assert(contains(parse_error_of(R"(x {unit} {out} ")"), "unbalanced"));

    // The message points at the character.
    assert(contains(parse_error_of("ab {nope} {unit} {out}"), "character 4"));

    assert(contains(parse_error_of(std::string("x {unit} {out}\0y", 16)), "NUL"));
}

void test_expand_rejects_bad_values() {
    const CommandTemplate command_template = parse_ok("x {unit} {out}");
    std::string command_line = "untouched";
    std::string error;

    assert(!command_template.expand("", "o", command_line, error) && contains(error, "unit"));
    assert(!command_template.expand("u", "", command_line, error) && contains(error, "output folder"));
    assert(!command_template.expand(std::string("a\0b", 3), "o", command_line, error) && contains(error, "NUL"));
    assert(!command_template.expand("u", std::string("a\0b", 3), command_line, error) && contains(error, "NUL"));
    assert(command_line == "untouched");

    const CommandTemplate never_parsed;  // default-constructed
    assert(never_parsed.is_empty());
    assert(!never_parsed.expand("u", "o", command_line, error) && contains(error, "no extractor command"));
}

void test_load_from_ini_file() {
    test_util::TempDir dir("template_ini");

    // Exactly the form shown in the plan.
    test_util::write_file(dir.file("guardian.ini"),
                          "; Extraction Guardian settings\n"
                          "extractor_cmd = \"setup.exe /unit {unit} /out {out}\"\n");
    CommandTemplate command_template;
    std::string error;
    assert(load_extractor_template(dir.file("guardian.ini"), command_template, error) && error.empty());
    assert(expand_ok(command_template, "a b.bin", "c d") == R"(setup.exe /unit "a b.bin" /out "c d")");

    // Missing key, missing file and invalid template all fail with a readable message.
    test_util::write_file(dir.file("other.ini"), "unit_pattern = *.bin\n");
    CommandTemplate untouched;
    assert(!load_extractor_template(dir.file("other.ini"), untouched, error) && contains(error, "extractor_cmd"));
    assert(!load_extractor_template(dir.file("missing.ini"), untouched, error) && contains(error, "missing.ini"));

    test_util::write_file(dir.file("typo.ini"), "extractor_cmd = setup.exe {unti} {out}\n");
    assert(!load_extractor_template(dir.file("typo.ini"), untouched, error));
    assert(contains(error, "typo.ini") && contains(error, "{unti}"));
    assert(untouched.is_empty());
}

}  // namespace

int main() {
    test_simple_substitution();
    test_paths_with_spaces_become_one_argument();
    test_value_glued_to_text_and_trailing_backslash();
    test_hostile_values_cannot_add_arguments();
    test_values_with_non_ascii_text();
    test_placeholder_can_repeat_and_order_is_free();
    test_literal_braces();
    test_quotes_in_the_literal_part_are_kept();
    test_template_errors();
    test_expand_rejects_bad_values();
    test_load_from_ini_file();
    return 0;
}
