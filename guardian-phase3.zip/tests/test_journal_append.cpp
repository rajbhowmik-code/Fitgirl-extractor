// Task 1.3: durable append. After appending 3 records the file holds exactly
// 3 lines. Also: torn-tail repair, refusing to append to a damaged file,
// failure reporting.
#include "test_common.h"

#include <filesystem>
#include <string>
#include <vector>

#include "journal.h"
#include "test_util.h"

namespace {

using test_util::count_char;
using test_util::read_file;
using test_util::write_file;

std::vector<std::string> split_lines(const std::string& text) {
    std::vector<std::string> lines;
    std::size_t start = 0;
    while (start < text.size()) {
        const std::size_t end = text.find('\n', start);
        lines.push_back(text.substr(start, end - start));
        if (end == std::string::npos) break;
        start = end + 1;
    }
    return lines;
}

void test_three_records_make_three_lines() {
    test_util::TempDir dir("append3");
    const std::string path = dir.file("journal.log");
    Journal journal(path);

    const std::vector<Record> records = {
        {"UNIT_START", {"fg-1.bin"}}, {"UNIT_DONE", {"fg-1.bin"}}, {"UNIT_START", {"fg-2.bin"}}};
    for (const Record& record : records) {
        std::string error;
        assert(journal.append(record, &error));
        assert(error.empty());
    }

    const std::string content = read_file(path);
    assert(count_char(content, '\n') == 3);          // exactly 3 lines
    assert(!content.empty() && content.back() == '\n');
    assert(content.find('\r') == std::string::npos);  // never CRLF, even on Windows

    const std::vector<std::string> lines = split_lines(content);
    assert(lines.size() == 3);
    for (std::size_t i = 0; i < lines.size(); ++i) {
        Record parsed;
        assert(parse_line(lines[i], parsed));
        assert(parsed == records[i]);
    }
}

void test_append_continues_existing_file() {
    test_util::TempDir dir("append_more");
    const std::string path = dir.file("journal.log");
    {
        Journal first_run(path);
        assert(first_run.append(Record{"A", {"1"}}));
        assert(first_run.append(Record{"A", {"2"}}));
    }
    Journal second_run(path);  // a new process after a restart
    assert(second_run.append(Record{"A", {"3"}}));

    const LoadResult loaded = second_run.load();
    assert(loaded.ok && !loaded.tail_dropped && loaded.records.size() == 3);
    assert(loaded.records[2].fields[0] == "3");
}

void test_hostile_text_cannot_add_lines() {
    test_util::TempDir dir("append_hostile");
    Journal journal(dir.file("journal.log"));
    // A file name with newline + a fake record inside: must stay ONE line.
    const Record hostile{"UNIT_DONE", {"evil\nUNIT_DONE|fake|00000000", "x|y"}};
    assert(journal.append(hostile));
    assert(count_char(read_file(dir.file("journal.log")), '\n') == 1);

    const LoadResult loaded = journal.load();
    assert(loaded.ok && loaded.records.size() == 1 && loaded.records[0] == hostile);
}

void test_many_appends() {
    test_util::TempDir dir("append_many");
    Journal journal(dir.file("journal.log"));
    for (int i = 0; i < 200; ++i) assert(journal.append(Record{"N", {std::to_string(i)}}));
    assert(count_char(read_file(dir.file("journal.log")), '\n') == 200);
    const LoadResult loaded = journal.load();
    assert(loaded.ok && loaded.records.size() == 200);
    assert(loaded.records[199].fields[0] == "199");
}

void test_non_ascii_journal_path() {
    test_util::TempDir dir("append_utf8");
    const std::string path = dir.file("jou\xC3\xA9rnal_\xE2\x82\xAC.log");  // UTF-8 name
    Journal journal(path);
    assert(journal.append(Record{"A", {"x"}}));
    assert(journal.load().records.size() == 1);
    assert(std::filesystem::exists(std::filesystem::u8path(path)));
}

void test_failures_are_reported_not_ignored() {
    test_util::TempDir dir("append_fail");
    std::string error;

    // Parent folder does not exist.
    Journal missing_folder(dir.file("no_such_folder/journal.log"));
    assert(!missing_folder.append(Record{"A", {}}, &error));
    assert(!error.empty());

    // Invalid record: reported as failure, and nothing is created.
    Journal journal(dir.file("journal.log"));
    error.clear();
    assert(!journal.append(Record{"", {"x"}}, &error));
    assert(!error.empty());
    assert(!std::filesystem::exists(dir.path() / "journal.log"));

    // Oversized record.
    error.clear();
    assert(!journal.append(Record{"T", {std::string(kMaxJournalLineBytes, 'a')}}, &error));
    assert(!error.empty());

    // Null error pointer must be fine.
    assert(!journal.append(Record{"", {}}, nullptr));

    // Empty journal path.
    Journal no_path("");
    error.clear();
    assert(!no_path.append(Record{"A", {}}, &error) && !error.empty());

    // The path is a folder, not a file.
    Journal folder_as_journal(dir.path_utf8());
    error.clear();
    assert(!folder_as_journal.append(Record{"A", {}}, &error) && !error.empty());

    // After all those failures the good journal still works.
    assert(journal.append(Record{"OK", {}}));
    assert(journal.load().records.size() == 1);
}

void test_torn_tail_is_repaired_before_append() {
    test_util::TempDir dir("append_repair");
    const std::string path = dir.file("journal.log");

    const Record first{"UNIT_DONE", {"fg-1.bin"}};
    const Record second{"UNIT_START", {"fg-2.bin"}};
    const std::string good = make_line(first) + "\n" + make_line(second) + "\n";

    // Power cut in the middle of writing the next record: no trailing newline.
    write_file(path, good + make_line(Record{"UNIT_DONE", {"fg-2.bin"}}).substr(0, 14));

    Journal journal(path);
    assert(journal.load().tail_dropped);  // load() alone does not modify the file
    assert(read_file(path).size() > good.size());

    const Record third{"UNIT_DONE", {"fg-2.bin"}};
    assert(journal.append(third));

    // The fragment is gone, the new record starts on its own line.
    assert(read_file(path) == good + make_line(third) + "\n");
    const LoadResult loaded = journal.load();
    assert(loaded.ok && !loaded.tail_dropped && loaded.records.size() == 3);
    assert(loaded.records[2] == third);
}

void test_corrupt_last_line_with_newline_is_repaired() {
    test_util::TempDir dir("append_repair_nl");
    const std::string path = dir.file("journal.log");
    const std::string good = make_line(Record{"A", {"1"}}) + "\n";
    write_file(path, good + "garbage-but-newline-terminated\n");

    Journal journal(path);
    assert(journal.append(Record{"A", {"2"}}));
    assert(read_file(path) == good + make_line(Record{"A", {"2"}}) + "\n");
}

void test_valid_checksum_without_newline_is_treated_as_torn() {
    // A line is only complete once its '\n' is there. The record is dropped
    // (and the unit simply gets redone, which is always safe).
    test_util::TempDir dir("append_nonl");
    const std::string path = dir.file("journal.log");
    const std::string good = make_line(Record{"A", {"1"}}) + "\n";
    write_file(path, good + make_line(Record{"A", {"2"}}));  // no '\n'

    Journal journal(path);
    assert(journal.append(Record{"A", {"3"}}));
    const LoadResult loaded = journal.load();
    assert(loaded.ok && loaded.records.size() == 2);
    assert(loaded.records[1].fields[0] == "3");
}

void test_refuses_to_append_to_damaged_journal() {
    test_util::TempDir dir("append_damaged");
    const std::string path = dir.file("journal.log");
    const std::string damaged = make_line(Record{"A", {"1"}}) + "\n" +
                                "this line is damaged\n" +
                                make_line(Record{"A", {"3"}}) + "\n";
    write_file(path, damaged);

    Journal journal(path);
    std::string error;
    assert(!journal.append(Record{"A", {"4"}}, &error));
    assert(!error.empty());
    assert(read_file(path) == damaged);  // untouched: evidence is preserved

    // And it keeps refusing (the check is not silently skipped the second time).
    assert(!journal.append(Record{"A", {"5"}}, &error));
    assert(read_file(path) == damaged);
}

void test_failed_append_forces_recheck_next_time() {
    // If an append fails after the tail was verified, the next append must
    // re-verify. Simulate "something wrote garbage after our last good append".
    test_util::TempDir dir("append_recheck");
    const std::string path = dir.file("journal.log");
    Journal journal(path);
    assert(journal.append(Record{"A", {"1"}}));

    // Make the NEXT write fail: replace the file with a folder of the same name.
    std::filesystem::remove(std::filesystem::u8path(path));
    std::filesystem::create_directory(std::filesystem::u8path(path));
    assert(!journal.append(Record{"A", {"2"}}));
    std::filesystem::remove(std::filesystem::u8path(path));

    // Now a torn fragment appears (as if the failed write had half-landed).
    write_file(path, make_line(Record{"A", {"1"}}) + "\n" + "TORN");
    assert(journal.append(Record{"A", {"3"}}));
    const LoadResult loaded = journal.load();
    assert(loaded.ok && !loaded.tail_dropped && loaded.records.size() == 2);
}


// Simulates a power cut at EVERY possible byte offset of a growing journal:
// whatever survived, load() must return exactly the complete records, and the
// next append must repair the file so that the result is clean and ordered.
void test_power_cut_at_every_byte_offset() {
    test_util::TempDir dir("append_everycut");
    const std::string path = dir.file("journal.log");

    const std::vector<Record> records = {
        {"UNIT_START", {"fg-1.bin"}}, {"UNIT_DONE", {"fg-1.bin"}},
        {"UNIT_START", {"fg-2.bin", "C:\\a b\\c|d"}}, {"UNIT_DONE", {"fg-2.bin"}}};
    std::string full;
    std::vector<std::size_t> line_ends;  // offset just after each '\n'
    for (const Record& record : records) {
        full += make_line(record) + "\n";
        line_ends.push_back(full.size());
    }

    const Record next{"UNIT_START", {"fg-3.bin"}};
    for (std::size_t surviving = 0; surviving <= full.size(); ++surviving) {
        write_file(path, full.substr(0, surviving));

        std::size_t complete_lines = 0;
        for (const std::size_t end : line_ends) complete_lines += (end <= surviving) ? 1 : 0;

        Journal journal(path);
        const LoadResult before = journal.load();
        assert(before.ok);
        assert(before.records.size() == complete_lines);
        for (std::size_t i = 0; i < complete_lines; ++i) assert(before.records[i] == records[i]);

        assert(journal.append(next));
        const LoadResult after = journal.load();
        assert(after.ok && !after.tail_dropped);
        assert(after.records.size() == complete_lines + 1);
        assert(after.records.back() == next);
        assert(count_char(read_file(path), '\n') == complete_lines + 1);  // no glued/leftover fragments
    }
}

}  // namespace

int main() {
    test_three_records_make_three_lines();
    test_append_continues_existing_file();
    test_hostile_text_cannot_add_lines();
    test_many_appends();
    test_non_ascii_journal_path();
    test_failures_are_reported_not_ignored();
    test_torn_tail_is_repaired_before_append();
    test_corrupt_last_line_with_newline_is_repaired();
    test_valid_checksum_without_newline_is_treated_as_torn();
    test_refuses_to_append_to_damaged_journal();
    test_failed_append_forces_recheck_next_time();
    test_power_cut_at_every_byte_offset();
    return 0;
}
