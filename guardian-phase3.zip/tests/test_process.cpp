// Task 3.1: run_process. This executable also plays the "child" in some tests:
// it starts itself with a special first argument (see main()).
#include "test_common.h"

#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>
#include <system_error>
#include <thread>
#include <vector>

#include "command_line.h"
#include "process.h"
#include "test_util.h"
#include "utf8_arguments.h"

#ifndef _WIN32
#include <sys/types.h>
#include <unistd.h>

#include <cerrno>
#include <csignal>
#endif

namespace {

namespace fs = std::filesystem;
using std::chrono::milliseconds;
using std::chrono::steady_clock;

std::string g_self;  // path of this executable, used to start helper children

constexpr auto kWaitLimit = std::chrono::seconds(10);

void sleep_ms(int count) { std::this_thread::sleep_for(milliseconds(count)); }

// ---------------------------------------------------------------------------
// Child modes (this program started by itself)
// ---------------------------------------------------------------------------

std::uint64_t current_process_id() {
#ifdef _WIN32
    return GetCurrentProcessId();
#else
    return static_cast<std::uint64_t>(::getpid());
#endif
}

// Writes `content` to `path` atomically (temp file + rename) so a reader never sees half of it.
void write_file_atomically(const std::string& path, const std::string& content) {
    const std::string temporary = path + ".tmp";
    test_util::write_file(temporary, content);
    fs::rename(fs::u8path(temporary), fs::u8path(path));
}

std::string to_hex(const std::string& text) {
    static const char digits[] = "0123456789abcdef";
    std::string hex;
    for (const char character : text) {
        const unsigned char byte = static_cast<unsigned char>(character);
        hex.push_back(digits[byte >> 4]);
        hex.push_back(digits[byte & 0x0F]);
    }
    return hex;
}

// --echo-args <file> <arg>...: writes each argument as one hex line.
int child_echo_arguments(const std::vector<std::string>& args) {
    std::string lines;
    for (std::size_t index = 3; index < args.size(); ++index) lines += to_hex(args[index]) + "\n";
    test_util::write_file(args[2], lines);
    return 0;
}

// --sleep-and-record-pid <file>: publishes its process id, then waits (30 s at most,
// so a test failure can never leave it running for long).
int child_sleep_and_record_pid(const std::string& pid_file) {
    write_file_atomically(pid_file, std::to_string(current_process_id()));
    sleep_ms(30000);
    return 0;
}

// --sleep-then-exit <ms> <code>
int child_sleep_then_exit(const std::string& milliseconds_text, const std::string& code_text) {
    sleep_ms(std::stoi(milliseconds_text));
    return std::stoi(code_text);
}

// --crash-while-child-runs <pid file>: acts like a Guardian that runs a long extractor and
// is then killed abruptly (power cut). A watcher thread ends this process with no cleanup
// at all (no destructors) as soon as the extractor has started.
int child_crash_while_child_runs(const std::string& pid_file) {
    std::thread watcher([pid_file] {
        std::error_code ignored;
        while (!fs::exists(fs::u8path(pid_file), ignored)) sleep_ms(10);
        std::_Exit(42);
    });
    watcher.detach();

    int exit_code = 0;
    run_process(quote_argument(g_self) + " --sleep-and-record-pid " + quote_argument(pid_file), exit_code);
    return 0;  // never reached: the watcher ends the process first
}

#ifdef _WIN32
// Starts a program and does NOT wait for it (what an installer that spawns a helper does).
bool start_without_waiting(const std::string& command_line) {
    const std::wstring wide = fs::u8path(command_line).wstring();
    std::vector<wchar_t> buffer(wide.begin(), wide.end());
    buffer.push_back(L'\0');
    STARTUPINFOW startup = {};
    startup.cb = sizeof(startup);
    PROCESS_INFORMATION info = {};
    if (!CreateProcessW(nullptr, buffer.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &startup, &info)) {
        return false;
    }
    CloseHandle(info.hThread);
    CloseHandle(info.hProcess);
    return true;
}

// --spawn-leftover <pid file>: starts a long-running helper, waits until it has
// started, then exits while the helper is still running.
int child_spawn_leftover(const std::string& pid_file) {
    if (!start_without_waiting(quote_argument(g_self) + " --sleep-and-record-pid " + quote_argument(pid_file))) {
        return 1;
    }
    const auto deadline = steady_clock::now() + kWaitLimit;
    std::error_code ignored;
    while (!fs::exists(fs::u8path(pid_file), ignored)) {
        if (steady_clock::now() > deadline) return 2;
        sleep_ms(10);
    }
    return 0;
}
#endif

// ---------------------------------------------------------------------------
// Helpers for the tests
// ---------------------------------------------------------------------------

std::string exit_with_code_command(int code) {
#ifdef _WIN32
    return "cmd /c exit " + std::to_string(code);
#else
    return "sh -c \"exit " + std::to_string(code) + "\"";
#endif
}

// True once the process with this id no longer runs (within the wait limit).
bool process_is_gone_soon(std::uint64_t process_id) {
#ifdef _WIN32
    HANDLE handle = OpenProcess(SYNCHRONIZE, FALSE, static_cast<DWORD>(process_id));
    if (handle == nullptr) return GetLastError() == ERROR_INVALID_PARAMETER;  // no such process
    const DWORD waited = WaitForSingleObject(handle, static_cast<DWORD>(milliseconds(kWaitLimit).count()));
    CloseHandle(handle);
    return waited == WAIT_OBJECT_0;
#else
    const auto deadline = steady_clock::now() + kWaitLimit;
    while (steady_clock::now() < deadline) {
        if (::kill(static_cast<pid_t>(process_id), 0) != 0 && errno == ESRCH) return true;
        // A killed process that nobody has collected yet is a "zombie": it is dead for our purposes.
        std::ifstream stat_file("/proc/" + std::to_string(process_id) + "/stat");
        std::string stat_text((std::istreambuf_iterator<char>(stat_file)), std::istreambuf_iterator<char>());
        const std::size_t paren = stat_text.rfind(')');
        if (paren != std::string::npos && paren + 2 < stat_text.size() && stat_text[paren + 2] == 'Z') return true;
        sleep_ms(20);
    }
    return false;
#endif
}

std::uint64_t read_process_id(const std::string& pid_file) {
    return std::stoull(test_util::read_file(pid_file));
}

std::vector<std::string> decode_hex_lines(const std::string& text) {
    std::vector<std::string> values;
    std::size_t start = 0;
    while (start < text.size()) {
        const std::size_t end = text.find('\n', start);
        const std::string hex = text.substr(start, end - start);
        std::string value;
        for (std::size_t index = 0; index + 1 < hex.size(); index += 2) {
            value.push_back(static_cast<char>(std::stoi(hex.substr(index, 2), nullptr, 16)));
        }
        values.push_back(value);
        start = end + 1;
    }
    return values;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

// The task's "Done when" check: `cmd /c exit 7` returns 7.
void test_exit_code_is_returned() {
    assert(run_process(exit_with_code_command(7)) == 7);

    for (const int code : {0, 1, 7, 42, 255}) {
        int exit_code = -999;
        std::string error;
        assert(run_process(exit_with_code_command(code), exit_code, &error));
        assert(exit_code == code && error.empty());
    }
}

void test_run_process_waits_for_the_program() {
    const auto started = steady_clock::now();
    int exit_code = 0;
    assert(run_process(quote_argument(g_self) + " --sleep-then-exit 400 5", exit_code));
    assert(exit_code == 5);
    assert(steady_clock::now() - started >= milliseconds(350));  // returned only after the child ended
}

void test_start_failures_are_reported() {
    int exit_code = 123;
    std::string error;

    assert(!run_process("this_program_does_not_exist_12345 --x", exit_code, &error));
    assert(!error.empty() && exit_code == 123);  // exit code untouched on failure
    assert(run_process("this_program_does_not_exist_12345") == kProcessStartFailed);

    error.clear();
    assert(!run_process("", exit_code, &error) && error.find("empty") != std::string::npos);
    error.clear();
    assert(!run_process("  \t ", exit_code, &error) && error.find("empty") != std::string::npos);
    error.clear();
    assert(!run_process(std::string("cmd\0 /c exit 0", 14), exit_code, &error) && error.find("NUL") != std::string::npos);

    // A file that exists but is not a program.
    test_util::TempDir dir("process_notprogram");
    test_util::write_file(dir.file("data.txt"), "hello");
    error.clear();
    assert(!run_process(quote_argument(dir.file("data.txt")), exit_code, &error) && !error.empty());

    // run_process(nullptr error pointer) must be fine too.
    assert(!run_process("this_program_does_not_exist_12345", exit_code));
    assert(exit_code == 123);

#ifdef _WIN32
    error.clear();
    assert(!run_process("cmd /c echo \xFF\xFE", exit_code, &error) && error.find("UTF-8") != std::string::npos);
    error.clear();
    assert(!run_process("cmd /c echo " + std::string(40000, 'x'), exit_code, &error) &&
           error.find("too long") != std::string::npos);
#endif
}

// Every tricky value must arrive in the child as exactly one, unchanged argument.
void test_arguments_arrive_unchanged() {
    test_util::TempDir dir("process_args");
    const std::vector<std::string> values = {
        "plain",
        "with space",
        "tab\there",
        "quote\"inside",
        R"(trailing backslash\)",
        R"(C:\dir with space\sub\)",
        R"(two\\backslashes)",
        R"(back\"quote)",
        "",
        "&|<>^%PATH%",
        "\"",
        "\\",
        "\\\\",
        R"(a"b c"d)",
        "line1\nline2",
        std::string(5000, 'x') + " y",
        u8"\u09AC\u09BE\u0982\u09B2\u09BE folder \u00E9\u00FC",  // Bengali + accents
    };

    const std::string result_file = dir.file("echo.txt");
    std::string command_line = quote_argument(g_self) + " --echo-args " + quote_argument(result_file);
    for (const std::string& value : values) command_line += " " + quote_argument(value);

    int exit_code = -1;
    std::string error;
    assert(run_process(command_line, exit_code, &error));
    assert(exit_code == 0);
    assert(decode_hex_lines(test_util::read_file(result_file)) == values);
}

// If Guardian dies abruptly, the extractor must die with it (otherwise it would keep
// writing into the staging folder while the next run is already cleaning it).
void test_child_is_killed_when_guardian_dies() {
    test_util::TempDir dir("process_crash");
    const std::string pid_file = dir.file("sleeper.pid");

    int exit_code = -1;
    std::string error;
    assert(run_process(quote_argument(g_self) + " --crash-while-child-runs " + quote_argument(pid_file),
                       exit_code, &error));
    assert(exit_code == 42);  // the "guardian" ended itself without cleanup

    assert(process_is_gone_soon(read_process_id(pid_file)));
}

#ifdef _WIN32
// A helper the extractor left running must not outlive run_process().
void test_leftover_processes_are_ended() {
    test_util::TempDir dir("process_leftover");
    const std::string pid_file = dir.file("leftover.pid");

    int exit_code = -1;
    std::string error;
    assert(run_process(quote_argument(g_self) + " --spawn-leftover " + quote_argument(pid_file), exit_code, &error));
    assert(exit_code == 0);

    assert(process_is_gone_soon(read_process_id(pid_file)));
}
#endif

}  // namespace

int main(int argc, char** argv) {
    const std::vector<std::string> args = utf8_command_line_arguments(argc, argv);
    assert(!args.empty());
    g_self = fs::absolute(fs::u8path(args[0])).u8string();

    // Child modes.
    if (args.size() >= 3 && args[1] == "--echo-args") return child_echo_arguments(args);
    if (args.size() == 3 && args[1] == "--sleep-and-record-pid") return child_sleep_and_record_pid(args[2]);
    if (args.size() == 4 && args[1] == "--sleep-then-exit") return child_sleep_then_exit(args[2], args[3]);
    if (args.size() == 3 && args[1] == "--crash-while-child-runs") return child_crash_while_child_runs(args[2]);
#ifdef _WIN32
    if (args.size() == 3 && args[1] == "--spawn-leftover") return child_spawn_leftover(args[2]);
#endif

    test_exit_code_is_returned();
    test_run_process_waits_for_the_program();
    test_start_failures_are_reported();
    test_arguments_arrive_unchanged();
    test_child_is_killed_when_guardian_dies();
#ifdef _WIN32
    test_leftover_processes_are_ended();
#endif
    return 0;
}
