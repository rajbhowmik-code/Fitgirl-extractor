// Tests for command_line.h (quoting / splitting with the Windows rules).
// The key property: split_command_line(quote_argument(v)) == { v } for EVERY v.
#include "test_common.h"

#include <cstddef>
#include <string>
#include <utility>
#include <vector>

#include "command_line.h"

namespace {

using Arguments = std::vector<std::string>;

void test_quote_known_values() {
    assert(quote_argument("plain") == "plain");
    assert(quote_argument(R"(C:\dir\file.bin)") == R"(C:\dir\file.bin)");  // backslashes alone: unchanged
    assert(quote_argument("") == R"("")");                                  // empty must stay an argument
    assert(quote_argument("a b") == R"("a b")");
    assert(quote_argument("a\tb") == "\"a\tb\"");
    assert(quote_argument(R"(say "hi")") == R"("say \"hi\"")");
    assert(quote_argument(R"(C:\my dir\)") == R"("C:\my dir\\")");          // trailing backslash doubled
    assert(quote_argument(R"(a\"b)") == R"("a\\\"b")");                     // backslash before quote: 2n+1
    assert(quote_argument(R"(\\server\share dir)") == R"("\\server\share dir")");  // inner backslashes literal
}

void test_split_known_values() {
    // Examples from Microsoft's documentation of the parsing rules.
    assert((split_command_line(R"("abc" d e)") == Arguments{"abc", "d", "e"}));
    assert((split_command_line(R"(a\\b d"e f"g h)") == Arguments{R"(a\\b)", "de fg", "h"}));
    assert((split_command_line(R"(a\\\"b c d)") == Arguments{R"(a\"b)", "c", "d"}));
    assert((split_command_line(R"(a\\\\"b c" d e)") == Arguments{R"(a\\b c)", "d", "e"}));

    // Whitespace handling and empty arguments.
    assert(split_command_line("").empty());
    assert(split_command_line("   \t  ").empty());
    assert((split_command_line("  a \t b  ") == Arguments{"a", "b"}));
    assert((split_command_line(R"("")") == Arguments{""}));
    assert((split_command_line(R"(a "" b)") == Arguments{"a", "", "b"}));
    assert((split_command_line(R"(--dir="a b")") == Arguments{"--dir=a b"}));  // quotes in the middle
    assert((split_command_line("\"a\nb\"") == Arguments{"a\nb"}));              // newline inside quotes is data

    // Modern C-runtime rule: "" inside quotes is one literal quote.
    assert((split_command_line(R"("a""b")") == Arguments{R"(a"b)"}));
    // Unterminated quote: the rest of the line belongs to the argument.
    assert((split_command_line(R"("a b)") == Arguments{"a b"}));
}

// Every string up to `max_length` over a deliberately nasty alphabet.
void for_each_value(std::size_t max_length, void (*check)(const std::string&)) {
    const std::string alphabet = std::string("a \t\\\"\n|");
    std::vector<std::string> current = {""};
    check("");
    for (std::size_t length = 1; length <= max_length; ++length) {
        std::vector<std::string> next;
        next.reserve(current.size() * alphabet.size());
        for (const std::string& prefix : current) {
            for (const char symbol : alphabet) {
                next.push_back(prefix + symbol);
                check(next.back());
            }
        }
        current = std::move(next);
    }
}

void check_single_round_trip(const std::string& value) {
    const Arguments parsed = split_command_line(quote_argument(value));
    assert(parsed.size() == 1);
    assert(parsed[0] == value);
}

void check_value_after_prefix(const std::string& value) {
    // Mirrors "/DIR={out}" style arguments: text glued directly in front of a quoted value.
    const Arguments parsed = split_command_line("--dir=" + quote_argument(value));
    assert(parsed.size() == 1);
    assert(parsed[0] == "--dir=" + value);
}

void test_round_trip_exhaustive() {
    for_each_value(6, check_single_round_trip);  // ~137,000 values
    for_each_value(4, check_value_after_prefix);
}

void test_two_arguments_stay_separate() {
    const std::vector<std::string> samples = {"", "a", "a b", "\\", "\"", "x\\", "\\\"", "a\tb", "q\"r s"};
    for (const std::string& first : samples) {
        for (const std::string& second : samples) {
            const Arguments parsed = split_command_line(quote_argument(first) + " " + quote_argument(second));
            assert((parsed == Arguments{first, second}));
        }
    }
}

void test_hostile_value_cannot_inject_arguments() {
    // A file name crafted to look like extra arguments stays ONE argument.
    const std::string hostile = R"(x" /out "C:\Windows\System32)";
    const Arguments parsed = split_command_line("setup.exe /unit " + quote_argument(hostile) + " /out safe");
    assert((parsed == Arguments{"setup.exe", "/unit", hostile, "/out", "safe"}));
}

}  // namespace

int main() {
    test_quote_known_values();
    test_split_known_values();
    test_round_trip_exhaustive();
    test_two_arguments_stay_separate();
    test_hostile_value_cannot_inject_arguments();
    return 0;
}
