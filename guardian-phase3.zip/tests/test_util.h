// Small helpers shared by the file-based tests.
// Include "test_common.h" BEFORE this header (keeps assert() active in Release).
#pragma once

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <random>
#include <string>

namespace test_util {

namespace fs = std::filesystem;

// A fresh, unique temp folder that is deleted again when the object dies.
class TempDir {
public:
    explicit TempDir(const std::string& label) {
        std::random_device entropy;
        const std::uint64_t unique = (static_cast<std::uint64_t>(entropy()) << 32) ^ entropy();
        path_ = fs::temp_directory_path() / ("guardian_test_" + label + "_" + std::to_string(unique));
        fs::create_directories(path_);
    }
    ~TempDir() {
        std::error_code ignored;
        fs::remove_all(path_, ignored);
    }
    TempDir(const TempDir&) = delete;
    TempDir& operator=(const TempDir&) = delete;

    // UTF-8 path string (the same convention the production code uses).
    std::string file(const std::string& name) const { return (path_ / fs::u8path(name)).u8string(); }
    const fs::path& path() const { return path_; }
    std::string path_utf8() const { return path_.u8string(); }

private:
    fs::path path_;
};

inline void write_file(const std::string& path, const std::string& content) {
    std::ofstream out(fs::u8path(path), std::ios::binary | std::ios::trunc);
    out.write(content.data(), static_cast<std::streamsize>(content.size()));
}

inline std::string read_file(const std::string& path) {
    std::ifstream in(fs::u8path(path), std::ios::binary);
    return std::string(std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>());
}

inline std::size_t count_char(const std::string& text, char wanted) {
    std::size_t count = 0;
    for (const char c : text) count += (c == wanted) ? 1 : 0;
    return count;
}

}  // namespace test_util
