// Task 0.2: dummy test proving the test harness works.
// Must be the first include so assert() stays enabled in Release builds.
#include "test_common.h"

int main() {
    assert(1 + 1 == 2);
    return 0;  // exit code 0 = pass; a failed assert aborts = non-zero = fail
}
