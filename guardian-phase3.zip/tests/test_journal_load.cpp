// Task 1.4: load() with corruption tolerance.
//   * damaged / half-written LAST line  -> ignored, earlier records returned, no error
//   * damaged line in the MIDDLE        -> stop and report an error
#include "test_common.h"

#include <string>
#include <vector>

#include "journal.h"
#include "test_util.h"

namespace {

using test_util::read_file;
using test_util::write_file;

std::string line_of(const char* type, const char* field) {
    return make_line(Record{type, {field}}) + "\n";
}

void test_missing_and_empty_file_are_fine() {
    test_util::TempDir dir("load_empty");

    const LoadResult missing = Journal(dir.file("nope.log")).load();  // fresh start
    assert(missing.ok && missing.records.empty() && !missing.tail_dropped && missing.valid_bytes == 0);

    write_file(dir.file("empty.log"), "");
    const LoadResult empty = Journal(dir.file("empty.log")).load();
    assert(empty.ok && empty.records.empty() && !empty.tail_dropped);
}

void test_clean_file() {
    test_util::TempDir dir("load_clean");
    const std::string content = line_of("A", "1") + line_of("B", "2") + line_of("A", "1");  // duplicates are kept
    write_file(dir.file("j.log"), content);

    const LoadResult result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.error.empty() && !result.tail_dropped);
    assert(result.records.size() == 3);
    assert(result.records[0] == (Record{"A", {"1"}}));
    assert(result.records[1] == (Record{"B", {"2"}}));
    assert(result.records[2] == (Record{"A", {"1"}}));
    assert(result.valid_bytes == content.size());
}

// The task's "Done when" check.
void test_truncated_last_line_is_ignored() {
    test_util::TempDir dir("load_trunc");
    const std::string good = line_of("UNIT_START", "fg-1.bin") + line_of("UNIT_DONE", "fg-1.bin") +
                             line_of("UNIT_START", "fg-2.bin");
    const std::string last = line_of("UNIT_DONE", "fg-2.bin");

    // Cut the last line at EVERY possible length (a power cut can stop anywhere).
    for (std::size_t keep = 0; keep < last.size(); ++keep) {
        write_file(dir.file("j.log"), good + last.substr(0, keep));
        const LoadResult result = Journal(dir.file("j.log")).load();
        assert(result.ok);                       // no error
        assert(result.records.size() == 3);      // earlier records returned
        assert(result.valid_bytes == good.size());
        assert(result.tail_dropped == (keep > 0));  // nothing to drop if the cut is exactly at a line start
    }

    // Not truncated at all: all 4 records.
    write_file(dir.file("j.log"), good + last);
    const LoadResult complete = Journal(dir.file("j.log")).load();
    assert(complete.ok && complete.records.size() == 4 && !complete.tail_dropped);
}

void test_load_never_modifies_the_file() {
    test_util::TempDir dir("load_readonly");
    const std::string content = line_of("A", "1") + "TORN";
    write_file(dir.file("j.log"), content);
    assert(Journal(dir.file("j.log")).load().tail_dropped);
    assert(read_file(dir.file("j.log")) == content);
}

void test_other_damaged_last_lines() {
    test_util::TempDir dir("load_lastbad");
    const std::string good = line_of("A", "1");

    // Newline-terminated but corrupt (e.g. sectors persisted out of order).
    write_file(dir.file("j.log"), good + "corrupt but terminated\n");
    LoadResult result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.size() == 1 && result.tail_dropped && result.valid_bytes == good.size());

    // Valid checksum but no newline: not complete -> dropped.
    write_file(dir.file("j.log"), good + make_line(Record{"B", {"2"}}));
    result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.size() == 1 && result.tail_dropped && result.valid_bytes == good.size());

    // Blank line at the end.
    write_file(dir.file("j.log"), good + "\n");
    result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.size() == 1 && result.tail_dropped);

    // File zero-filled after a power cut (common on NTFS).
    write_file(dir.file("j.log"), good + std::string(4096, '\0'));
    result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.size() == 1 && result.tail_dropped && result.valid_bytes == good.size());

    // Only garbage in the whole file: single bad (= last) line -> no records, no error.
    write_file(dir.file("j.log"), "garbage only");
    result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.empty() && result.tail_dropped && result.valid_bytes == 0);
}

void test_damage_in_the_middle_is_an_error() {
    test_util::TempDir dir("load_middle");
    const std::string a = line_of("A", "1");
    const std::string c = line_of("A", "3");

    // good, BAD, good  -> error naming line 2; no partial results leak out.
    write_file(dir.file("j.log"), a + "damaged line\n" + c);
    LoadResult result = Journal(dir.file("j.log")).load();
    assert(!result.ok);
    assert(result.records.empty());
    assert(result.valid_bytes == 0 && !result.tail_dropped);
    assert(result.error.find("line 2") != std::string::npos);

    // BAD at the very start, followed by good data.
    write_file(dir.file("j.log"), "damaged\n" + a);
    result = Journal(dir.file("j.log")).load();
    assert(!result.ok && result.records.empty() && result.error.find("line 1") != std::string::npos);

    // good, BAD, BAD: the first bad one is not last -> error.
    write_file(dir.file("j.log"), a + "bad one\nbad two\n");
    result = Journal(dir.file("j.log")).load();
    assert(!result.ok && result.error.find("line 2") != std::string::npos);

    // good, BAD (terminated), then an unterminated fragment: still middle damage.
    write_file(dir.file("j.log"), a + "bad one\nTORN");
    result = Journal(dir.file("j.log")).load();
    assert(!result.ok);

    // One flipped character inside an otherwise good file.
    std::string flipped = a + line_of("B", "2") + c;
    flipped[a.size() + 3] ^= 0x01;
    write_file(dir.file("j.log"), flipped);
    result = Journal(dir.file("j.log")).load();
    assert(!result.ok && result.error.find("line 2") != std::string::npos);
}

void test_crlf_line_endings_are_tolerated() {
    test_util::TempDir dir("load_crlf");
    write_file(dir.file("j.log"),
               make_line(Record{"A", {"1"}}) + "\r\n" + make_line(Record{"B", {"2"}}) + "\r\n");
    const LoadResult result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.size() == 2 && !result.tail_dropped);
}

void test_overlong_lines_are_bounded() {
    test_util::TempDir dir("load_long");
    const std::string a = line_of("A", "1");

    // Garbage far beyond the limit, no newline: dropped as a torn tail, and we
    // never buffer more than ~1 MiB of it.
    write_file(dir.file("j.log"), a + std::string(5 * (1u << 20), 'x'));
    LoadResult result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.size() == 1 && result.tail_dropped && result.valid_bytes == a.size());

    // An overlong line followed by a good line is middle damage.
    write_file(dir.file("j.log"), a + std::string(kMaxJournalLineBytes + 100, 'x') + "\n" + a);
    result = Journal(dir.file("j.log")).load();
    assert(!result.ok);

    // A line that is exactly at the limit is still readable.
    const std::string biggest = make_line(Record{"T", {std::string(kMaxJournalLineBytes - 11, 'a')}}) + "\n";
    write_file(dir.file("j.log"), a + biggest + a);
    result = Journal(dir.file("j.log")).load();
    assert(result.ok && result.records.size() == 3 && !result.tail_dropped);
}

void test_unreadable_targets_are_errors() {
    test_util::TempDir dir("load_unreadable");
    const LoadResult folder = Journal(dir.path_utf8()).load();  // a folder, not a file
    assert(!folder.ok && !folder.error.empty() && folder.records.empty());

    const LoadResult no_path = Journal("").load();
    assert(!no_path.ok && !no_path.error.empty());
}

}  // namespace

int main() {
    test_missing_and_empty_file_are_fine();
    test_clean_file();
    test_truncated_last_line_is_ignored();
    test_load_never_modifies_the_file();
    test_other_damaged_last_lines();
    test_damage_in_the_middle_is_an_error();
    test_crlf_line_endings_are_tolerated();
    test_overlong_lines_are_bounded();
    test_unreadable_targets_are_errors();
    return 0;
}
