// Shared header for all plain assert-based tests.
// IMPORTANT: Release builds define NDEBUG, which silently turns assert()
// into a no-op and would make every test "pass" without checking anything.
// We undefine it here so assertions are ALWAYS active in tests.
#pragma once
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
