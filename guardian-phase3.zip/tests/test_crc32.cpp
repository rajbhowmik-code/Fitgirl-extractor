// Task 1.1: CRC32 known values, chaining, slicing-by-8 vs a simple reference,
// and chunked file reading (including exact chunk boundaries).
#include "test_common.h"

#include <cstdint>
#include <random>
#include <string>
#include <vector>

#include "crc32.h"
#include "test_util.h"

namespace {

// Slow but obviously-correct bit-by-bit CRC-32 used to cross-check the fast one.
std::uint32_t reference_crc32(const unsigned char* data, std::size_t len) {
    std::uint32_t crc = 0xFFFFFFFFu;
    for (std::size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (int bit = 0; bit < 8; ++bit) crc = (crc & 1u) ? (crc >> 1) ^ 0xEDB88320u : (crc >> 1);
    }
    return ~crc;
}

std::uint32_t crc_of(const std::string& text) {
    return crc32_update(0, text.data(), text.size());
}

void test_known_values() {
    assert(crc_of("123456789") == 0xCBF43926u);  // the standard check value
    assert(crc_of("") == 0u);
    assert(crc_of("a") == 0xE8B7BE43u);
    assert(crc_of("abc") == 0x352441C2u);
    assert(crc_of("The quick brown fox jumps over the lazy dog") == 0x414FA339u);
    assert(crc_of(std::string(32, '\0')) == 0x190A55ADu);
    assert(crc_of(std::string(32, '\xFF')) == 0xFF6CAB0Bu);

    std::string ascending;
    for (int i = 0; i < 32; ++i) ascending.push_back(static_cast<char>(i));
    assert(crc_of(ascending) == 0x91267E8Au);
}

void test_zero_length_and_null() {
    assert(crc32_update(0, nullptr, 0) == 0u);
    assert(crc32_update(0x12345678u, nullptr, 0) == 0x12345678u);  // unchanged
}

void test_chaining_equals_single_call() {
    const std::string text = "123456789";
    for (std::size_t split = 0; split <= text.size(); ++split) {
        std::uint32_t crc = crc32_update(0, text.data(), split);
        crc = crc32_update(crc, text.data() + split, text.size() - split);
        assert(crc == 0xCBF43926u);
    }
}

void test_fast_path_matches_reference() {
    std::mt19937 rng(12345);  // fixed seed: the test is deterministic
    std::vector<unsigned char> data(1024 + 16);
    for (auto& byte : data) byte = static_cast<unsigned char>(rng());

    // Every length around the 8-byte block size, from every start alignment,
    // including bytes >= 0x80 (sign-extension bugs would show up here).
    for (std::size_t offset = 0; offset < 8; ++offset) {
        for (std::size_t len = 0; len <= 300; ++len) {
            const std::uint32_t fast = crc32_update(0, data.data() + offset, len);
            assert(fast == reference_crc32(data.data() + offset, len));
        }
    }
    assert(crc32_update(0, data.data(), 1024) == reference_crc32(data.data(), 1024));
}

void test_file_known_value_and_edge_sizes() {
    test_util::TempDir dir("crc");

    // Known value.
    const std::string small_path = dir.file("small.bin");
    test_util::write_file(small_path, "123456789");
    std::uint32_t crc = 0;
    assert(crc32_file(small_path, crc) && crc == 0xCBF43926u);

    // Empty file is valid, CRC 0.
    const std::string empty_path = dir.file("empty.bin");
    test_util::write_file(empty_path, "");
    crc = 0xDEADBEEFu;
    assert(crc32_file(empty_path, crc) && crc == 0u);

    // Sizes around the 1 MiB read-chunk boundary must give the same answer as
    // hashing the same bytes in memory.
    const std::size_t mib = 1u << 20;
    const std::size_t sizes[] = {1, mib - 1, mib, mib + 1, 2 * mib, 2 * mib + 13, 3 * mib - 1};
    std::mt19937 rng(777);
    for (const std::size_t size : sizes) {
        std::string content(size, '\0');
        for (char& c : content) c = static_cast<char>(rng());
        const std::string path = dir.file("sized.bin");
        test_util::write_file(path, content);
        std::uint32_t from_file = 0;
        assert(crc32_file(path, from_file));
        assert(from_file == crc_of(content));
    }
}

void test_file_failures_leave_output_untouched() {
    test_util::TempDir dir("crc_fail");

    std::uint32_t crc = 0xABCD1234u;
    assert(!crc32_file(dir.file("does_not_exist.bin"), crc));
    assert(crc == 0xABCD1234u);

    // A directory is not a file we can checksum.
    assert(!crc32_file(dir.path_utf8(), crc));
    assert(crc == 0xABCD1234u);

    assert(!crc32_file("", crc));  // empty path
    assert(crc == 0xABCD1234u);
}

void test_file_with_non_ascii_name() {
    test_util::TempDir dir("crc_utf8");
    const std::string path = dir.file("jeu_\xC3\xA9t\xC3\xA9_\xE2\x82\xAC.bin");  // "jeu_été_€.bin" in UTF-8
    test_util::write_file(path, "123456789");
    std::uint32_t crc = 0;
    assert(crc32_file(path, crc) && crc == 0xCBF43926u);
}

}  // namespace

int main() {
    test_known_values();
    test_zero_length_and_null();
    test_chaining_equals_single_call();
    test_fast_path_matches_reference();
    test_file_known_value_and_edge_sizes();
    test_file_failures_leave_output_untouched();
    test_file_with_non_ascii_name();
    return 0;
}
