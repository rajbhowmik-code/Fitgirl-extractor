// Task 3.3: fake_extractor writes the same files every time.
// Usage: test_fake_extractor [path-to-fake_extractor]
// Without an argument the program is looked up next to this test executable.
#include "test_common.h"

#include <chrono>
#include <filesystem>
#include <map>
#include <set>
#include <string>
#include <system_error>
#include <vector>

#include "command_line.h"
#include "command_template.h"
#include "fake_unit_content.h"
#include "process.h"
#include "test_util.h"
#include "utf8_arguments.h"

namespace {

namespace fs = std::filesystem;

std::string g_extractor;  // path of the fake_extractor executable

// Relative '/'-separated path -> file content, for every regular file below `root`.
std::map<std::string, std::string> read_tree(const fs::path& root) {
    std::map<std::string, std::string> tree;
    for (const fs::directory_entry& entry : fs::recursive_directory_iterator(root)) {
        if (!entry.is_regular_file()) continue;
        const std::string relative = fs::relative(entry.path(), root).generic_u8string();
        tree[relative] = test_util::read_file(entry.path().u8string());
    }
    return tree;
}

std::map<std::string, std::string> expected_tree(const std::string& unit) {
    std::map<std::string, std::string> tree;
    for (const FakeFile& file : make_fake_unit_files(unit)) tree[file.relative_path] = file.content;
    return tree;
}

// Runs the extractor through the same path the real tool will use:
// template -> expand -> run_process.
int run_extractor(const std::string& unit, const std::string& out, const std::string& extra_options = "--delay-ms 0") {
    CommandTemplate command_template;
    std::string error;
    const bool parsed = CommandTemplate::parse(quote_argument(g_extractor) + " {unit} {out} " + extra_options,
                                               command_template, error);
    assert(parsed);

    std::string command_line;
    const bool expanded = command_template.expand(unit, out, command_line, error);
    assert(expanded);

    int exit_code = -1;
    const bool ran = run_process(command_line, exit_code, &error);
    assert(ran);
    return exit_code;
}

// The task's "Done when" check: running it produces the same files every time.
void test_same_files_every_time() {
    test_util::TempDir dir("fake_same");
    const std::string first = dir.file("first run");   // folder names with spaces on purpose
    const std::string second = dir.file("second run");

    assert(run_extractor("fg-1.bin", first) == 0);
    assert(run_extractor("fg-1.bin", second) == 0);

    const auto first_tree = read_tree(fs::u8path(first));
    assert(first_tree.size() == 5);
    assert(first_tree == read_tree(fs::u8path(second)));
    assert(first_tree == expected_tree("fg-1.bin"));  // the test can predict the output

    // Running again into the same folder overwrites with identical content.
    assert(run_extractor("fg-1.bin", first) == 0);
    assert(first_tree == read_tree(fs::u8path(first)));
}

void test_file_set_covers_awkward_cases() {
    const std::vector<FakeFile> files = make_fake_unit_files("fg-1.bin");
    bool has_empty = false, has_one_byte = false, has_over_64k = false, has_nested = false;
    std::set<std::string> paths;
    for (const FakeFile& file : files) {
        has_empty |= file.content.empty();
        has_one_byte |= file.content.size() == 1;
        has_over_64k |= file.content.size() > 65536;
        has_nested |= file.relative_path.find("nested/deep/") != std::string::npos;
        assert(paths.insert(file.relative_path).second);                    // no duplicate paths
        assert(file.relative_path.find("..") == std::string::npos);         // cannot escape the output folder
        assert(!file.relative_path.empty() && file.relative_path[0] != '/');
        assert(file.relative_path.find('\\') == std::string::npos);
    }
    assert(has_empty && has_one_byte && has_over_64k && has_nested);
}

void test_content_is_a_function_of_the_unit_name_only() {
    // Fixed bytes: if the generator ever changes, this fails loudly (expected manifests depend on it).
    const std::vector<FakeFile> files = make_fake_unit_files("fg-1.bin");
    assert(files[0].relative_path == "fg-1/readme.txt");
    assert(files[0].content == "fake extractor output\nunit: fg-1.bin\n");

    // Same bytes whether given as a name or as a path in either style.
    assert(expected_tree("fg-1.bin") == expected_tree(R"(D:\repack\fg-1.bin)"));
    assert(expected_tree("fg-1.bin") == expected_tree("/repack/fg-1.bin"));

    // Different units: different folders AND different bytes.
    const auto one = expected_tree("fg-1.bin");
    const auto two = expected_tree("fg-2.bin");
    assert(one != two);
    for (const auto& [path, content] : one) assert(two.count(path) == 0);

    // Names that sanitize to the same folder still differ in content.
    const auto spaced = make_fake_unit_files("a b.bin");
    const auto underscored = make_fake_unit_files("a_b.bin");
    assert(spaced[0].relative_path == underscored[0].relative_path);
    assert(spaced[2].content != underscored[2].content);

    // Odd names must not break the generator.
    assert(make_fake_unit_files("").front().relative_path == "unit/readme.txt");
    assert(make_fake_unit_files("..").front().relative_path.find("..") == std::string::npos);
    assert(make_fake_unit_files("../../evil.bin").front().relative_path == "evil/readme.txt");
}

void test_unit_given_as_a_path() {
    test_util::TempDir dir("fake_path");
    assert(run_extractor(dir.file("some folder/fg-3.bin"), dir.file("out")) == 0);
    assert(read_tree(fs::u8path(dir.file("out"))) == expected_tree("fg-3.bin"));
}

void test_non_ascii_output_folder() {
    test_util::TempDir dir("fake_unicode");
    const std::string out = dir.file(u8"\u0997\u09C7\u09AE games \u00E9");
    assert(run_extractor("fg-1.bin", out) == 0);
    assert(read_tree(fs::u8path(out)) == expected_tree("fg-1.bin"));
}

void test_delay_option_slows_it_down() {
    test_util::TempDir dir("fake_delay");
    const auto started = std::chrono::steady_clock::now();
    assert(run_extractor("fg-1.bin", dir.file("slow"), "--delay-ms 80") == 0);
    // 5 files x 80 ms; only a lower bound is asserted so slow machines cannot make this flaky.
    assert(std::chrono::steady_clock::now() - started >= std::chrono::milliseconds(350));
}

void test_usage_and_io_errors() {
    test_util::TempDir dir("fake_errors");
    const std::string out = dir.file("out");

    assert(run_process(quote_argument(g_extractor)) == 2);                                       // no arguments
    assert(run_process(quote_argument(g_extractor) + " onlyone") == 2);                          // missing folder
    assert(run_process(quote_argument(g_extractor) + " a b c") == 2);                            // too many
    assert(run_extractor("fg-1.bin", out, "--delay-ms abc") == 2);                               // bad number
    assert(run_extractor("fg-1.bin", out, "--delay-ms -5") == 2);                                // negative
    assert(run_extractor("fg-1.bin", out, "--delay-ms 60001") == 2);                             // too big
    assert(run_extractor("fg-1.bin", out, "--delay-ms") == 2);                                   // missing value
    assert(run_extractor("fg-1.bin", out, "--bogus") == 2);                                      // unknown option
    assert(!fs::exists(fs::u8path(out)));                                                        // nothing written on usage errors

    // Output folder cannot be created because a FILE is in the way.
    test_util::write_file(dir.file("blocker"), "x");
    assert(run_extractor("fg-1.bin", dir.file("blocker")) == 3);
    assert(run_extractor("fg-1.bin", dir.file("blocker/inside")) == 3);
}

}  // namespace

int main(int argc, char** argv) {
    const std::vector<std::string> args = utf8_command_line_arguments(argc, argv);
    assert(!args.empty());
    if (args.size() >= 2) {
        g_extractor = args[1];
    } else {
        fs::path candidate = fs::absolute(fs::u8path(args[0])).parent_path() / "fake_extractor";
#ifdef _WIN32
        candidate += ".exe";
#endif
        g_extractor = candidate.u8string();
    }
    assert(fs::exists(fs::u8path(g_extractor)) && "fake_extractor not found next to the test");

    test_file_set_covers_awkward_cases();
    test_content_is_a_function_of_the_unit_name_only();
    test_same_files_every_time();
    test_unit_given_as_a_path();
    test_non_ascii_output_folder();
    test_delay_option_slows_it_down();
    test_usage_and_io_errors();
    return 0;
}
