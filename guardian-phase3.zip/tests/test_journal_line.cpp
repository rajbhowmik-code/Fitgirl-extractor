// Task 1.2: journal line format. Valid line parses, any flipped character
// fails, any truncation fails (plus escaping, limits and malformed input).
#include "test_common.h"

#include <cstdio>
#include <stdexcept>
#include <string>

#include "crc32.h"
#include "journal.h"

namespace {

// Builds a line with a CORRECT checksum around an arbitrary body, so we can
// test the decoder's own validation (bad escapes etc.) and not just the CRC.
std::string forge_line(const std::string& body) {
    char crc_text[16];
    std::snprintf(crc_text, sizeof(crc_text), "%08x",
                  static_cast<unsigned>(crc32_update(0, body.data(), body.size())));
    return body + "|" + crc_text;
}

void test_exact_format_and_roundtrip() {
    const Record original{"UNIT_DONE", {"fg-1.bin"}};
    const std::string line = make_line(original);

    // crc32("UNIT_DONE|fg-1.bin") = 324603a5 (cross-checked with Python zlib).
    assert(line == "UNIT_DONE|fg-1.bin|324603a5");

    Record parsed;
    assert(parse_line(line, parsed));
    assert(parsed == original);
}

void test_field_counts() {
    Record parsed;

    const Record no_fields{"HELLO", {}};
    const std::string no_fields_line = make_line(no_fields);
    assert(parse_line(no_fields_line, parsed) && parsed == no_fields);
    assert(parsed.fields.empty());

    const Record empty_fields{"X", {"", ""}};  // empty != missing
    const std::string empty_fields_line = make_line(empty_fields);
    assert(parse_line(empty_fields_line, parsed) && parsed == empty_fields);
    assert(parsed.fields.size() == 2);

    const Record one_empty_field{"X", {""}};
    assert(make_line(one_empty_field) != make_line(no_fields));  // distinguishable on disk
    assert(parse_line(make_line(one_empty_field), parsed) && parsed.fields.size() == 1);

    Record many{"M", {}};
    for (int i = 0; i < 500; ++i) many.fields.push_back("field" + std::to_string(i));
    assert(parse_line(make_line(many), parsed) && parsed == many);
}

void test_special_characters_roundtrip() {
    const std::string nul_text("a\0b", 3);
    const Record nasty{"T|YPE%", {"pipe|inside", "percent%41", "line\nbreak", "carriage\rreturn",
                                  "tab\there", nul_text, "del\x7F", "utf8 \xC3\xA9\xE2\x82\xAC",
                                  "%", "%%", "|", "||", "\\", "C:\\Games\\fitgirl repack\\x.bin"}};
    const std::string line = make_line(nasty);

    // The encoded line must be one clean line: no raw control characters, and
    // exactly (fields + 1) separators ('|' only as separators, never in data).
    for (const char c : line) {
        const unsigned char u = static_cast<unsigned char>(c);
        assert(u >= 0x20 && u != 0x7F);
    }
    std::size_t pipes = 0;
    for (const char c : line) pipes += (c == '|') ? 1 : 0;
    assert(pipes == nasty.fields.size() + 1);

    Record parsed;
    assert(parse_line(line, parsed));
    assert(parsed == nasty);

    // Escapes are lowercase hex: '|' -> %7c.
    assert(make_line(Record{"T", {"a|b"}}).find("a%7cb") != std::string::npos);
}

void test_every_flipped_bit_fails() {
    const Record original{"UNIT_START", {"fg-10.bin", "C:\\Games\\x y", "%|"}};
    const std::string line = make_line(original);
    Record parsed;
    assert(parse_line(line, parsed));

    // CRC-32 detects every single-bit error, and the strict canonical format
    // (lowercase hex only) means even a case flip inside the checksum fails.
    for (std::size_t position = 0; position < line.size(); ++position) {
        for (int bit = 0; bit < 8; ++bit) {
            std::string damaged = line;
            damaged[position] = static_cast<char>(static_cast<unsigned char>(damaged[position]) ^ (1u << bit));
            Record untouched{"KEEP", {"ME"}};
            assert(!parse_line(damaged, untouched));
            assert(untouched.type == "KEEP" && untouched.fields.size() == 1);  // out unchanged on failure
        }
    }

    // A simple "flip one character to another" too.
    std::string swapped = line;
    swapped[3] = (swapped[3] == 'X') ? 'Y' : 'X';
    assert(!parse_line(swapped, parsed));
}

void test_every_truncation_fails() {
    const Record original{"UNIT_DONE", {"fg-1.bin", "extra"}};
    const std::string line = make_line(original);
    Record parsed;
    for (std::size_t length = 0; length < line.size(); ++length) {
        assert(!parse_line(line.substr(0, length), parsed));
    }
    assert(parse_line(line, parsed));  // the full line is still fine

    // Extra bytes after a valid line are also rejected.
    assert(!parse_line(line + "x", parsed));
    assert(!parse_line(line + "|", parsed));
    assert(!parse_line(line + "\n", parsed));
    assert(!parse_line(line + "\r", parsed));
}

void test_malformed_lines() {
    Record parsed;
    assert(!parse_line("", parsed));
    assert(!parse_line("|", parsed));
    assert(!parse_line("UNIT_DONE", parsed));                    // no separator
    assert(!parse_line("UNIT_DONE|a", parsed));                  // checksum too short
    assert(!parse_line("UNIT_DONE|a|324603a", parsed));          // 7 digits
    assert(!parse_line("UNIT_DONE|a|324603a50", parsed));        // 9 digits
    assert(!parse_line("UNIT_DONE|fg-1.bin|324603A5", parsed));  // uppercase hex is not canonical
    assert(!parse_line("UNIT_DONE|fg-1.bin|3246 3a5", parsed));  // not hex
    assert(!parse_line("UNIT_DONE|fg-1.bin|0x4603a5", parsed));  // not hex

    // Correct checksum, but the content itself is invalid:
    assert(!parse_line(forge_line(""), parsed));         // empty type
    assert(!parse_line(forge_line("|a"), parsed));       // empty type, one field
    assert(!parse_line(forge_line("T|bad%zz"), parsed)); // bad escape digits
    assert(!parse_line(forge_line("T|cut%4"), parsed));  // truncated escape
    assert(!parse_line(forge_line("T|cut%"), parsed));   // lone '%'
    assert(!parse_line(forge_line("T|big%4G"), parsed));
    assert(!parse_line(forge_line("T|up%7C"), parsed));  // uppercase escape is not canonical
    assert(!parse_line(forge_line(std::string("T|raw\nnewline")), parsed));
    assert(!parse_line(forge_line(std::string("T|raw\0nul", 9)), parsed));
    assert(!parse_line(forge_line(std::string("T|raw\x01") + "ctl"), parsed));
    assert(!parse_line(forge_line("T|raw\x7F"), parsed));

    // ...while valid-but-unusual content with a correct checksum is accepted.
    assert(parse_line(forge_line("T|ok%41"), parsed));
    assert(parsed.type == "T" && parsed.fields.size() == 1 && parsed.fields[0] == "okA");
}

void test_make_line_rejects_bad_records() {
    bool threw_invalid = false;
    try {
        make_line(Record{"", {"a"}});
    } catch (const std::invalid_argument&) {
        threw_invalid = true;
    }
    assert(threw_invalid);
}

void test_size_limits() {
    Record parsed;

    // Line is: type(1) + '|' + field + '|' + crc(8) = field + 11 bytes.
    const std::size_t exactly_fits = kMaxJournalLineBytes - 11;
    const std::string biggest_ok = make_line(Record{"T", {std::string(exactly_fits, 'a')}});
    assert(biggest_ok.size() == kMaxJournalLineBytes);
    assert(parse_line(biggest_ok, parsed));  // we can read back everything we write

    bool too_big_threw = false;
    try {
        make_line(Record{"T", {std::string(exactly_fits + 1, 'a')}});
    } catch (const std::length_error&) {
        too_big_threw = true;
    }
    assert(too_big_threw);

    // Raw size fits, but escaping triples it past the limit.
    bool escape_blowup_threw = false;
    try {
        make_line(Record{"T", {std::string(kMaxJournalLineBytes / 2, '|')}});
    } catch (const std::length_error&) {
        escape_blowup_threw = true;
    }
    assert(escape_blowup_threw);

    // Reading side: anything over the limit is rejected without further parsing.
    assert(!parse_line(std::string(kMaxJournalLineBytes + 1, 'a'), parsed));
}

}  // namespace

int main() {
    test_exact_format_and_roundtrip();
    test_field_counts();
    test_special_characters_roundtrip();
    test_every_flipped_bit_fails();
    test_every_truncation_fails();
    test_malformed_lines();
    test_make_line_rejects_bad_records();
    test_size_limits();
    return 0;
}
