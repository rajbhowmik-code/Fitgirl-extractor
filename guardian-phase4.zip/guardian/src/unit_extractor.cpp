#include "unit_extractor.h"

#include <exception>
#include <filesystem>
#include <set>
#include <system_error>
#include <utility>

#include "file_ops.h"
#include "process.h"
#include "unit_state.h"

namespace {

namespace fs = std::filesystem;

// Builds a failed result in one line.
UnitExtractionResult make_failure(ExtractionStage stage, std::string message) {
    UnitExtractionResult result;
    result.ok = false;
    result.failed_stage = stage;
    result.error = std::move(message);
    return result;
}

// True if `folder` exists and is a REAL folder (not a link to one).
bool is_real_folder(const fs::path& folder) {
    std::error_code status_error;
    const fs::file_status status = fs::symlink_status(folder, status_error);
    return !status_error && fs::is_directory(status);
}

}  // namespace

bool is_safe_unit_name(const std::string& unit_name) {
    // A unit name becomes a folder name, so it follows the same Windows-safe rules as any path part.
    return is_safe_path_component(unit_name);
}

bool staging_folder_for_unit(const std::string& game_folder, const std::string& unit_name,
                             std::string& staging_folder, std::string& error) {
    if (game_folder.empty()) {
        error = "the game folder is empty";
        return false;
    }
    if (!is_safe_unit_name(unit_name)) {
        error = "unit name '" + unit_name + "' cannot be used as a staging folder name";
        return false;
    }
    try {
        const fs::path staging = fs::absolute(fs::u8path(game_folder)) / kStagingFolderName / fs::u8path(unit_name);
        staging_folder = staging.u8string();
        return true;
    } catch (const std::exception& problem) {
        error = "cannot build the staging folder path: " + std::string(problem.what());
        return false;
    }
}

bool prepare_staging_folder(const std::string& game_folder, const std::string& unit_name,
                            std::string& staging_folder, std::string& error) {
    std::string unit_staging;
    if (!staging_folder_for_unit(game_folder, unit_name, unit_staging, error)) return false;

    try {
        const fs::path game_path = fs::absolute(fs::u8path(game_folder));
        if (!is_real_folder(game_path)) {
            error = "game folder '" + game_folder + "' does not exist or is not a folder";
            return false;
        }

        // ".staging" may be missing (created below) or a real folder. A link or
        // a file with that name is refused: deleting and creating things through
        // a link could touch files outside the game folder.
        const fs::path staging_root = game_path / kStagingFolderName;
        std::error_code root_error;
        const fs::file_status root_status = fs::symlink_status(staging_root, root_error);
        if (root_status.type() != fs::file_type::not_found && !is_real_folder(staging_root)) {
            error = "'" + staging_root.u8string() + "' exists but is not a real folder (a file or a link); remove it";
            return false;
        }

        // 1) Delete leftovers of an earlier, interrupted attempt of THIS unit.
        if (!remove_folder_tree(unit_staging, error)) return false;

        // 2) Create the fresh, empty staging folder.
        const fs::path unit_staging_path = fs::u8path(unit_staging);
        std::error_code create_error;
        fs::create_directories(unit_staging_path, create_error);
        if (create_error || !is_real_folder(unit_staging_path)) {
            error = "cannot create staging folder '" + unit_staging + "'" +
                    (create_error ? ": " + create_error.message() : std::string());
            return false;
        }

        staging_folder = unit_staging;
        return true;
    } catch (const std::exception& problem) {
        error = "cannot prepare staging folder '" + unit_staging + "': " + problem.what();
        return false;
    }
}

bool verify_staging_folder(const std::string& staging_folder, const Manifest* expected, Manifest& actual,
                           std::string& error) {
    Manifest built;
    if (!build_manifest(staging_folder, built, error)) return false;

    if (expected != nullptr) {
        std::string differences;
        if (!compare_manifests(*expected, built, differences)) {
            error = "the extracted files do not match the expected files:\n" + differences;
            return false;
        }
    } else if (built.is_empty()) {
        error = "the extractor reported success but produced no files";
        return false;
    }

    actual = std::move(built);
    return true;
}

bool commit_staging_folder(const std::string& staging_folder, const std::string& game_folder,
                           const Manifest& manifest, std::string& error) {
    if (staging_folder.empty() || game_folder.empty()) {
        error = "staging folder and game folder must not be empty";
        return false;
    }

    try {
        const fs::path staging_path = fs::u8path(staging_folder);
        const fs::path game_path = fs::u8path(game_folder);

        // Check every path first: nothing is moved if any entry looks wrong.
        for (const ManifestEntry& file : manifest.files) {
            if (!is_safe_relative_path(file.relative_path)) {
                error = "refusing to move unsafe path '" + file.relative_path + "'";
                return false;
            }
        }
        for (const std::string& folder : manifest.empty_directories) {
            if (!is_safe_relative_path(folder)) {
                error = "refusing to create unsafe folder '" + folder + "'";
                return false;
            }
        }

        // 1) Make the file DATA durable BEFORE the files get their final names
        //    (see flush_file_to_disk for why).
        for (const ManifestEntry& file : manifest.files) {
            if (!flush_file_to_disk((staging_path / fs::u8path(file.relative_path)).u8string(), error)) return false;
        }

        // Folders already created / known to exist; avoids one system call per file
        // and doubles as the list of folders to flush at the end.
        std::set<std::string> prepared_folders;
        const auto ensure_folder = [&prepared_folders, &error](const fs::path& folder) -> bool {
            const std::string folder_text = folder.u8string();
            if (prepared_folders.count(folder_text) != 0) return true;
            std::error_code create_error;
            fs::create_directories(folder, create_error);
            if (create_error || !is_real_folder(folder)) {
                error = "cannot create folder '" + folder_text + "'" +
                        (create_error ? ": " + create_error.message() : std::string(" (a file or link is in the way)"));
                return false;
            }
            prepared_folders.insert(folder_text);
            return true;
        };

        // 2) Folders that must exist although they hold no file.
        for (const std::string& folder : manifest.empty_directories) {
            if (!ensure_folder(game_path / fs::u8path(folder))) return false;
        }

        // 3) Move every file; an existing file with the same name is replaced.
        for (const ManifestEntry& file : manifest.files) {
            const fs::path relative = fs::u8path(file.relative_path);
            const fs::path destination = game_path / relative;
            if (!ensure_folder(destination.parent_path())) return false;
            if (!move_file_replacing((staging_path / relative).u8string(), destination.u8string(), error)) {
                return false;
            }
        }

        // 4) Make the new file names durable (does something on POSIX only).
        for (const std::string& folder : prepared_folders) {
            if (!flush_directory_to_disk(folder, error)) return false;
        }
        return true;
    } catch (const std::exception& problem) {
        error = std::string("cannot move extracted files: ") + problem.what();
        return false;
    }
}

const char* to_string(ExtractionStage stage) {
    switch (stage) {
        case ExtractionStage::Completed: return "Completed";
        case ExtractionStage::ValidateInput: return "ValidateInput";
        case ExtractionStage::BuildCommand: return "BuildCommand";
        case ExtractionStage::WriteStartRecord: return "WriteStartRecord";
        case ExtractionStage::PrepareStaging: return "PrepareStaging";
        case ExtractionStage::RunExtractor: return "RunExtractor";
        case ExtractionStage::VerifyStaging: return "VerifyStaging";
        case ExtractionStage::MoveFiles: return "MoveFiles";
        case ExtractionStage::WriteDoneRecord: return "WriteDoneRecord";
    }
    return "Unknown";
}

UnitExtractionResult extract_unit(const Unit& unit, const UnitExtractionContext& context) {
    // Remembered so that an unexpected exception is reported with the step it happened in.
    ExtractionStage current_stage = ExtractionStage::ValidateInput;
    try {
        std::string error;

        // ---- Checks that have no side effects (nothing is written yet) ------
        std::string planned_staging_folder;
        if (!staging_folder_for_unit(context.game_folder, unit.name, planned_staging_folder, error)) {
            return make_failure(ExtractionStage::ValidateInput, error);
        }
        if (!is_real_folder(fs::absolute(fs::u8path(context.game_folder)))) {
            return make_failure(ExtractionStage::ValidateInput,
                                "game folder '" + context.game_folder + "' does not exist or is not a folder");
        }
        current_stage = ExtractionStage::BuildCommand;
        std::string command_line;
        if (!context.command_template.expand(unit.path, planned_staging_folder, command_line, error)) {
            return make_failure(ExtractionStage::BuildCommand, error);
        }

        // ---- Step 1: journal FIRST ------------------------------------------
        // From here on the unit counts as InProgress, even if we die while
        // cleaning the staging folder.
        current_stage = ExtractionStage::WriteStartRecord;
        if (!context.journal.append(make_unit_start_record(unit.name), &error)) {
            return make_failure(ExtractionStage::WriteStartRecord, "cannot write UNIT_START: " + error);
        }

        // ---- Step 2: clean staging ------------------------------------------
        current_stage = ExtractionStage::PrepareStaging;
        std::string staging_folder;
        if (!prepare_staging_folder(context.game_folder, unit.name, staging_folder, error)) {
            return make_failure(ExtractionStage::PrepareStaging, error);
        }

        // ---- Step 3: run the extractor into staging -------------------------
        current_stage = ExtractionStage::RunExtractor;
        UnitExtractionResult result;
        int exit_code = 0;
        if (!run_process(command_line, exit_code, &error)) {
            return make_failure(ExtractionStage::RunExtractor, "cannot run the extractor: " + error);
        }
        result.extractor_started = true;
        result.extractor_exit_code = exit_code;
        if (exit_code != 0) {
            UnitExtractionResult failure =
                make_failure(ExtractionStage::RunExtractor, "the extractor exited with code " + std::to_string(exit_code));
            failure.extractor_started = true;
            failure.extractor_exit_code = exit_code;
            return failure;
        }

        // ---- Step 4: verify what it wrote -----------------------------------
        current_stage = ExtractionStage::VerifyStaging;
        Manifest staged_manifest;
        if (!verify_staging_folder(staging_folder, context.expected_manifest, staged_manifest, error)) {
            UnitExtractionResult failure = make_failure(ExtractionStage::VerifyStaging, error);
            failure.extractor_started = true;
            failure.extractor_exit_code = exit_code;
            return failure;
        }

        // ---- Step 5: move into the real folder, drop staging ----------------
        current_stage = ExtractionStage::MoveFiles;
        if (!commit_staging_folder(staging_folder, context.game_folder, staged_manifest, error)) {
            UnitExtractionResult failure = make_failure(ExtractionStage::MoveFiles, error);
            failure.extractor_started = true;
            failure.extractor_exit_code = exit_code;
            return failure;
        }
        // All files are in place and verified. Only empty folders remain in
        // staging, so a failed delete here is just clutter: do NOT redo hours
        // of extraction because of it. Report it as a warning instead.
        if (!remove_folder_tree(staging_folder, error)) {
            result.warning = "extraction is complete, but the staging folder was not removed: " + error;
        }

        // ---- Step 6: journal LAST -------------------------------------------
        current_stage = ExtractionStage::WriteDoneRecord;
        if (!context.journal.append(make_unit_done_record(unit.name), &error)) {
            UnitExtractionResult failure = make_failure(
                ExtractionStage::WriteDoneRecord,
                "files are in place but UNIT_DONE could not be written (the unit will simply be redone): " + error);
            failure.extractor_started = true;
            failure.extractor_exit_code = exit_code;
            return failure;
        }

        result.ok = true;
        result.failed_stage = ExtractionStage::Completed;
        result.files_extracted = staged_manifest.files.size();
        for (const ManifestEntry& file : staged_manifest.files) result.bytes_extracted += file.size;
        return result;
    } catch (const std::exception& problem) {
        // bad_alloc, std::length_error from the journal, invalid UTF-8 ...
        return make_failure(current_stage, std::string("unexpected error: ") + problem.what());
    }
}
