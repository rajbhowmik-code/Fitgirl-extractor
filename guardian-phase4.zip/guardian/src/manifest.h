// Task 4.2: a manifest is the list of everything an extractor produced:
// for every file its relative path, size and CRC-32. Guardian builds one for
// the staging folder after the extractor exits and checks it before any file
// is moved into the real game folder.
//
// What the check proves (and what it does not):
//   * Every file was read to its very end (read errors, locked or cut-off
//     files are caught).
//   * When an EXPECTED manifest is known (the fake extractor in tests), the
//     staging folder holds exactly those files: nothing missing, nothing
//     extra, same size, same CRC-32.
//   * Without an expected manifest (real repacks) the extractor's own exit
//     code and its own internal checks decide whether the content is right.
//
// Rules for what may appear inside a staging folder:
//   * Only regular files and folders. A symbolic link, a junction or a special
//     file is an ERROR: moving a link would let the extractor write outside
//     the game folder.
//   * Every relative path must pass is_safe_relative_path().
//
// Paths are UTF-8 std::strings with '/' as separator on every platform.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

struct ManifestEntry {
    std::string relative_path;  // e.g. "data/level1.pak"
    std::uint64_t size = 0;     // bytes
    std::uint32_t crc32 = 0;    // CRC-32 of the file content

    bool operator==(const ManifestEntry& other) const {
        return relative_path == other.relative_path && size == other.size && crc32 == other.crc32;
    }
    bool operator!=(const ManifestEntry& other) const { return !(*this == other); }
};

struct Manifest {
    // All files, sorted by relative_path (plain byte order), no duplicates.
    std::vector<ManifestEntry> files;
    // Folders that contain nothing at all, sorted. They are recorded because a
    // game may need an empty folder (e.g. "saves/"), and moving files alone
    // would lose it. A folder that contains files is implied by those files.
    std::vector<std::string> empty_directories;

    bool operator==(const Manifest& other) const {
        return files == other.files && empty_directories == other.empty_directories;
    }
    bool operator!=(const Manifest& other) const { return !(*this == other); }

    bool is_empty() const { return files.empty() && empty_directories.empty(); }
};

// True if `name` is a plain file or folder NAME that is valid on Windows (the
// primary target) and therefore safe everywhere:
//   * 1..255 bytes, not "." or ".."
//   * no control characters (incl. NUL) and none of  \ / : * ? " < > |
//     (':' also blocks drive letters and NTFS alternate data streams)
//   * no trailing space or dot (Windows silently strips them, so the name would
//     refer to a different file than the one we checked)
//   * not a reserved device name: CON PRN AUX NUL COM1-9 LPT1-9, with or
//     without an extension ("nul.txt" is still the NUL device)
// Bytes >= 0x80 (UTF-8 text) are fine.
bool is_safe_path_component(const std::string& name);

// True if `relative_path` is safe to join onto a folder: not empty, no leading
// or trailing '/', no empty part ("a//b"), and every '/'-separated part passes
// is_safe_path_component().
bool is_safe_relative_path(const std::string& relative_path);

// Walks `root_folder` and fills `out`. Reads every file completely (1 MiB at
// a time, so memory stays constant for multi-GB files).
// Returns false and sets `error` if the folder cannot be read, a file cannot
// be read to its end, an entry is a link / special file, or a path is unsafe.
// `out` is modified only when true is returned. An empty folder gives an empty
// manifest (deciding whether that is acceptable is the caller's job).
bool build_manifest(const std::string& root_folder, Manifest& out, std::string& error);

// Compares `actual` with `expected`. Returns true if identical. Otherwise
// returns false and `report` lists the differences, one per line, such as
//   missing file: data/a.pak
//   checksum differs: data/b.pak (expected 0cbf4392, found 12345678)
// At most 10 lines are listed, then "... and N more differences".
bool compare_manifests(const Manifest& expected, const Manifest& actual, std::string& report);
