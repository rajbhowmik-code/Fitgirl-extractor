// Small, careful file-system operations used by the safe-extraction pipeline
// (tasks 4.1 - 4.3). Each function returns true/false and explains a failure in
// `error`, so the caller can print a clear message instead of guessing.
//
// All paths are UTF-8 std::strings on every platform. On Windows they are
// converted to "extended-length" paths (\\?\C:\...), so repack folders whose
// full path is longer than 260 characters still work.
#pragma once

#include <string>

// Forces the DATA of an existing file onto the physical disk (FlushFileBuffers
// on Windows, fsync on POSIX).
//
// Why this matters: the extractor writes its files into the operating
// system's cache, not straight to the disk. If the power fails AFTER we wrote
// UNIT_DONE to the journal but BEFORE the system wrote those cached files, the
// journal would claim "done" while the files are cut short or empty. Flushing
// the files first closes that gap.
//
// Windows note: FlushFileBuffers needs write access. A file with the read-only
// attribute cannot be opened for writing; for it this function returns true
// without flushing (the failure would be permanent, and blocking the whole
// extraction over one read-only file is worse than the small risk).
bool flush_file_to_disk(const std::string& path, std::string& error);

// Forces the directory entries of a folder (new / renamed names) to disk.
// POSIX: fsync on the folder. Windows: does nothing and returns true, because
// NTFS journals its own metadata and move_file_replacing() already asks for a
// write-through rename.
bool flush_directory_to_disk(const std::string& path, std::string& error);

// Moves (renames) the file `from` to `to` and replaces `to` if it already
// exists. Both must be on the same volume, which is true for the staging
// folder because it lives INSIDE the game folder. On the same volume this is a
// single atomic step: afterwards `to` holds either the complete old file or
// the complete new one, never a mixture.
//   * Windows: MoveFileExW(MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH).
//   * POSIX:   rename().
// Windows: a read-only destination file is replaced too (its read-only
// attribute is cleared first), because a crashed earlier run may have left one.
// Fails (and changes nothing) if `from` is missing or `to` is a folder.
// The parent folder of `to` must already exist.
bool move_file_replacing(const std::string& from, const std::string& to, std::string& error);

// Deletes `folder` and everything inside it, then checks that it is really gone.
//   * A folder that does not exist counts as success.
//   * SAFETY: `folder` itself must be a real folder. If it is a symbolic link,
//     a junction or a plain file the function refuses, so a link planted at
//     ".staging/<unit>" can never make us delete something elsewhere.
//   * Read-only files inside are made writable once and the delete is retried.
bool remove_folder_tree(const std::string& folder, std::string& error);
