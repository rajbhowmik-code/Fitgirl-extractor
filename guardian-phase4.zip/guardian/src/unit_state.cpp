#include "unit_state.h"

#include <utility>

const char* to_string(UnitState state) {
    switch (state) {
        case UnitState::NotStarted: return "NotStarted";
        case UnitState::InProgress: return "InProgress";
        case UnitState::Done: return "Done";
    }
    return "Unknown";  // unreachable unless an invalid value was cast in
}

Record make_unit_start_record(const std::string& unit_name) {
    return Record{kUnitStartRecordType, {unit_name}};
}

Record make_unit_done_record(const std::string& unit_name) {
    return Record{kUnitDoneRecordType, {unit_name}};
}

bool State::from_journal(const std::vector<Record>& records, State& out, std::string& error) {
    State replayed;

    std::size_t record_number = 0;  // 1-based, for error messages
    for (const Record& record : records) {
        ++record_number;

        UnitState new_state = UnitState::NotStarted;  // always overwritten below
        if (record.type == kUnitStartRecordType) {
            new_state = UnitState::InProgress;
        } else if (record.type == kUnitDoneRecordType) {
            new_state = UnitState::Done;
        } else {
            continue;  // some other record type (maybe from a later phase): irrelevant here
        }

        if (record.fields.size() != 1 || record.fields[0].empty()) {
            error = "journal record " + std::to_string(record_number) + ": " + record.type +
                    " must have exactly one non-empty field (the unit name)";
            return false;
        }
        replayed.states_[record.fields[0]] = new_state;  // latest record wins
    }

    out = std::move(replayed);
    return true;
}

UnitState State::state_of(const std::string& unit_name) const {
    const auto found = states_.find(unit_name);
    return found == states_.end() ? UnitState::NotStarted : found->second;
}

std::size_t State::count_in_state(UnitState state) const {
    std::size_t count = 0;
    for (const auto& entry : states_) {
        if (entry.second == state) ++count;
    }
    return count;
}
