// Task 2.1: finding the archive pieces ("units") of a repack.
//
// A repack ships as many numbered pieces (fg-1.bin, fg-2.bin, ..., fg-10.bin).
// Guardian extracts them one at a time, in natural order, so "fg-2" must come
// BEFORE "fg-10" (a plain alphabetical sort would put fg-10 first).
//
// Which files count as units is decided by a glob pattern from guardian.ini:
//
//     unit_pattern = *.bin        ; default when the key is absent
//
// Pattern rules (deliberately tiny):
//   * '*' matches any run of characters (also none), '?' matches exactly one
//     byte. Everything else is literal ('[' and '{' have no special meaning).
//   * Matching is ASCII case-insensitive on every platform (Windows file names
//     are case-insensitive, so "*.bin" must also find "FG-1.BIN").
//   * The pattern is matched against the FILE NAME only. A pattern containing
//     '/' or '\' is rejected, so it can never reach outside the folder.
//   * Only the folder itself is searched (no sub-folders), and only regular
//     files count; folders such as ".staging" are never units.
//
// Paths and names are UTF-8 std::strings on every platform.
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "ini_file.h"

// One archive piece.
struct Unit {
    std::string name;    // file name only, e.g. "fg-1.bin". This is what the journal stores.
    std::string path;    // folder + name, ready to hand to the extractor
    std::uint64_t size;  // size in bytes at the moment the folder was scanned
};

// Pattern used when guardian.ini has no `unit_pattern` key.
inline constexpr char kDefaultUnitPattern[] = "*.bin";

// Longest accepted pattern (a file name is at most 255 characters anyway).
inline constexpr std::size_t kMaxUnitPatternChars = 260;

// Returns the `unit_pattern` value from `ini`, or kDefaultUnitPattern if the
// key is missing. The value is validated later, by find_units().
std::string unit_pattern_from_ini(const IniFile& ini);

// Glob match of `file_name` against `pattern` (rules above). Exposed for tests.
// Runs in O(file_name.size() * pattern.size()) worst case: no exponential
// blow-up, whatever the pattern looks like.
bool matches_unit_pattern(const std::string& pattern, const std::string& file_name);

// Natural-order "less than" for file names: digit runs compare by NUMERIC
// value ("fg-2" < "fg-10"), letters compare ASCII case-insensitively, and
// names that are equal under those rules ("fg-01" vs "fg-1", "A.bin" vs
// "a.bin") are ordered by a plain byte comparison. Result: a strict, total,
// deterministic order, so two runs on the same folder always agree.
// Digit runs of any length are fine (no integer overflow).
bool natural_name_less(const std::string& left, const std::string& right);

// Scans `folder` and returns the matching files sorted by natural_name_less.
//
//   * Returns true and fills `units` (possibly EMPTY: that is not an error
//     here, the caller decides what "no units" means).
//   * Returns false and sets `error` if the pattern is invalid, the folder
//     does not exist / is not a folder / cannot be read, or ANY entry in it
//     cannot be examined. Failing loudly beats silently skipping a piece: a
//     missing unit would otherwise look like "all done".
//   * `units` is modified only when true is returned.
bool find_units(const std::string& folder, const std::string& pattern, std::vector<Unit>& units,
                std::string& error);
