#include "file_ops.h"

#include <exception>
#include <filesystem>
#include <system_error>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <unistd.h>

#include <cerrno>
#endif

namespace {

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Delete helpers (portable)
// ---------------------------------------------------------------------------

// Adds the "owner may write" permission to everything below `root`, so a
// read-only file left by an extractor cannot block the delete.
// Links are skipped: changing a link's permissions would change its TARGET,
// which may lie outside the folder we are cleaning.
void make_tree_writable(const fs::path& root) {
    std::error_code iterate_error;
    fs::recursive_directory_iterator entry(root, iterate_error);
    const fs::recursive_directory_iterator end;
    while (!iterate_error && entry != end) {
        std::error_code entry_error;
        const fs::file_status status = entry->symlink_status(entry_error);
        if (!entry_error && !fs::is_symlink(status)) {
            fs::permissions(entry->path(), fs::perms::owner_write, fs::perm_options::add, entry_error);
        }
        entry.increment(iterate_error);
    }
}

}  // namespace

#ifdef _WIN32
// ============================================================================
// Windows
// ============================================================================
namespace {

// UTF-8 path -> absolute, normalised, extended-length wide path.
//   "C:\a\b"          -> "\\?\C:\a\b"
//   "\\server\s\x"    -> "\\?\UNC\server\s\x"
// The "\\?\" prefix switches off the 260-character limit, but it also switches
// off Windows' own clean-up of the path, so we do it ourselves first: absolute,
// no "." / ".." parts, backslashes only. May throw (bad_alloc, bad UTF-8).
std::wstring to_extended_length_path(const std::string& utf8_path) {
    fs::path normalized = fs::absolute(fs::u8path(utf8_path)).lexically_normal();
    normalized.make_preferred();
    const std::wstring text = normalized.wstring();

    if (text.rfind(L"\\\\?\\", 0) == 0) return text;  // already extended
    if (text.rfind(L"\\\\", 0) == 0) return L"\\\\?\\UNC\\" + text.substr(2);
    return L"\\\\?\\" + text;
}

std::string describe_win32_failure(const std::string& action, DWORD error_code) {
    return action + ": " + std::system_category().message(static_cast<int>(error_code));
}

}  // namespace

bool flush_file_to_disk(const std::string& path, std::string& error) {
    try {
        const std::wstring wide_path = to_extended_length_path(path);
        // Share everything: an antivirus scanner may have the file open too.
        const HANDLE file = CreateFileW(wide_path.c_str(), GENERIC_WRITE,
                                        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
                                        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file == INVALID_HANDLE_VALUE) {
            const DWORD open_error = GetLastError();
            // Read-only file: cannot be opened for writing, see header comment.
            if (open_error == ERROR_ACCESS_DENIED) return true;
            error = describe_win32_failure("cannot open '" + path + "' to flush it", open_error);
            return false;
        }
        const BOOL flushed = FlushFileBuffers(file);
        const DWORD flush_error = GetLastError();  // read BEFORE CloseHandle can overwrite it
        CloseHandle(file);
        if (!flushed) {
            error = describe_win32_failure("cannot flush '" + path + "' to disk", flush_error);
            return false;
        }
        return true;
    } catch (const std::exception& problem) {
        error = "cannot flush '" + path + "': " + problem.what();
        return false;
    }
}

bool flush_directory_to_disk(const std::string&, std::string&) {
    return true;  // see header comment
}

bool move_file_replacing(const std::string& from, const std::string& to, std::string& error) {
    try {
        const std::wstring wide_from = to_extended_length_path(from);
        const std::wstring wide_to = to_extended_length_path(to);
        const DWORD move_flags = MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH;
        if (MoveFileExW(wide_from.c_str(), wide_to.c_str(), move_flags)) return true;

        DWORD move_error = GetLastError();
        // A crashed earlier run (or the game's own installer) may have left the
        // destination with the read-only attribute; Windows then refuses to
        // replace it. Clear the attribute (never on a folder) and try once more.
        if (move_error == ERROR_ACCESS_DENIED) {
            const DWORD attributes = GetFileAttributesW(wide_to.c_str());
            if (attributes != INVALID_FILE_ATTRIBUTES && (attributes & FILE_ATTRIBUTE_READONLY) != 0 &&
                (attributes & FILE_ATTRIBUTE_DIRECTORY) == 0 &&
                SetFileAttributesW(wide_to.c_str(), attributes & ~static_cast<DWORD>(FILE_ATTRIBUTE_READONLY))) {
                if (MoveFileExW(wide_from.c_str(), wide_to.c_str(), move_flags)) return true;
                move_error = GetLastError();
            }
        }
        error = describe_win32_failure("cannot move '" + from + "' to '" + to + "'", move_error);
        return false;
    } catch (const std::exception& problem) {
        error = "cannot move '" + from + "' to '" + to + "': " + problem.what();
        return false;
    }
}

#else
// ============================================================================
// POSIX (Linux / macOS)
// ============================================================================
namespace {

// fsync() on an already opened descriptor, retried when a signal interrupts it.
bool sync_descriptor(int descriptor) {
    for (;;) {
        if (::fsync(descriptor) == 0) return true;
        if (errno != EINTR) return false;
    }
}

// Opens `path` with `open_flags`, fsyncs it and closes it again.
bool open_and_sync(const std::string& path, int open_flags, const char* what, std::string& error) {
    const int descriptor = ::open(path.c_str(), open_flags | O_CLOEXEC);
    if (descriptor < 0) {
        error = std::string("cannot open ") + what + " '" + path + "' to flush it: " +
                std::generic_category().message(errno);
        return false;
    }
    const bool synced = sync_descriptor(descriptor);
    const int sync_error = errno;  // read BEFORE close() can overwrite it
    ::close(descriptor);
    if (!synced) {
        error = std::string("cannot flush ") + what + " '" + path + "' to disk: " +
                std::generic_category().message(sync_error);
        return false;
    }
    return true;
}

}  // namespace

bool flush_file_to_disk(const std::string& path, std::string& error) {
    return open_and_sync(path, O_RDONLY, "file", error);
}

bool flush_directory_to_disk(const std::string& path, std::string& error) {
    return open_and_sync(path, O_RDONLY | O_DIRECTORY, "folder", error);
}

bool move_file_replacing(const std::string& from, const std::string& to, std::string& error) {
    try {
        std::error_code rename_error;
        fs::rename(fs::u8path(from), fs::u8path(to), rename_error);
        if (rename_error) {
            error = "cannot move '" + from + "' to '" + to + "': " + rename_error.message();
            return false;
        }
        return true;
    } catch (const std::exception& problem) {
        error = "cannot move '" + from + "' to '" + to + "': " + problem.what();
        return false;
    }
}

#endif  // _WIN32

// ============================================================================
// Portable part
// ============================================================================
bool remove_folder_tree(const std::string& folder, std::string& error) {
    if (folder.empty()) {
        error = "cannot delete a folder with an empty name";
        return false;
    }
    try {
        const fs::path folder_path = fs::u8path(folder);

        // symlink_status looks at the entry itself and does not follow a link.
        std::error_code status_error;
        const fs::file_status status = fs::symlink_status(folder_path, status_error);
        if (status.type() == fs::file_type::not_found) return true;
        if (status_error) {
            error = "cannot examine '" + folder + "': " + status_error.message();
            return false;
        }
        if (status.type() != fs::file_type::directory) {
            error = "refusing to delete '" + folder + "': it is not a real folder (link or file)";
            return false;
        }

        std::error_code remove_error;
        fs::remove_all(folder_path, remove_error);
        if (remove_error) {
            // Most common cause: a read-only file. Fix permissions once, retry once.
            make_tree_writable(folder_path);
            remove_error.clear();
            fs::remove_all(folder_path, remove_error);
        }
        if (remove_error) {
            error = "cannot delete folder '" + folder + "': " + remove_error.message();
            return false;
        }

        // Never trust "no error" alone: a locked file can leave the folder behind.
        std::error_code recheck_error;
        const fs::file_status after = fs::symlink_status(folder_path, recheck_error);
        if (after.type() != fs::file_type::not_found) {
            error = "folder '" + folder + "' still exists after deleting it (is a file in it in use?)";
            return false;
        }
        return true;
    } catch (const std::exception& problem) {
        error = "cannot delete folder '" + folder + "': " + problem.what();
        return false;
    }
}
