#include "manifest.h"

#include <algorithm>
#include <cstdio>
#include <exception>
#include <filesystem>
#include <system_error>
#include <utility>

#include "crc32.h"

namespace {

namespace fs = std::filesystem;

// How many differences compare_manifests() spells out before summarising.
constexpr std::size_t kMaxReportedDifferences = 10;

// "0cbf4392"-style text for a checksum.
std::string to_hex8(std::uint32_t value) {
    char buffer[9];
    std::snprintf(buffer, sizeof(buffer), "%08x", static_cast<unsigned int>(value));
    return std::string(buffer);
}

// Collects difference lines but keeps only the first few, counting the rest.
class DifferenceReport {
public:
    void add(const std::string& line) {
        if (lines_.size() < kMaxReportedDifferences) {
            lines_.push_back(line);
        }
        ++total_;
    }
    std::size_t total() const { return total_; }

    std::string text() const {
        std::string result;
        for (const std::string& line : lines_) {
            result += line;
            result += '\n';
        }
        if (total_ > lines_.size()) {
            result += "... and " + std::to_string(total_ - lines_.size()) + " more differences\n";
        }
        return result;
    }

private:
    std::vector<std::string> lines_;
    std::size_t total_ = 0;
};

// A copy of `items` in sorted order, made only when it is not sorted already.
template <typename Item, typename Less>
std::vector<Item> sorted_copy_if_needed(const std::vector<Item>& items, Less less) {
    std::vector<Item> copy = items;
    if (!std::is_sorted(copy.begin(), copy.end(), less)) std::sort(copy.begin(), copy.end(), less);
    return copy;
}

}  // namespace

namespace {

constexpr std::size_t kMaxPathComponentBytes = 255;  // NTFS / ext4 limit for one name

// CON, PRN, AUX, NUL, COM1-9, LPT1-9 - judged on the part before the first dot,
// ASCII case-insensitive ("Nul.TXT" is reserved too).
bool is_windows_reserved_device_name(const std::string& name) {
    const std::string stem = name.substr(0, name.find('.'));
    std::string upper;
    upper.reserve(stem.size());
    for (const char character : stem) {
        upper.push_back((character >= 'a' && character <= 'z') ? static_cast<char>(character - 'a' + 'A') : character);
    }
    if (upper == "CON" || upper == "PRN" || upper == "AUX" || upper == "NUL") return true;
    return upper.size() == 4 && (upper.compare(0, 3, "COM") == 0 || upper.compare(0, 3, "LPT") == 0) &&
           upper[3] >= '1' && upper[3] <= '9';
}

}  // namespace

bool is_safe_path_component(const std::string& name) {
    if (name.empty() || name.size() > kMaxPathComponentBytes) return false;
    if (name == "." || name == "..") return false;
    if (name.back() == ' ' || name.back() == '.') return false;

    for (const char character : name) {
        const unsigned char byte = static_cast<unsigned char>(character);
        if (byte < 0x20 || byte == 0x7F) return false;  // control characters (includes NUL)
        switch (character) {
            case '/': case '\\': case ':': case '*': case '?': case '"': case '<': case '>': case '|':
                return false;
            default:
                break;
        }
    }
    return !is_windows_reserved_device_name(name);
}

bool is_safe_relative_path(const std::string& relative_path) {
    if (relative_path.empty()) return false;

    std::size_t part_begin = 0;
    while (part_begin <= relative_path.size()) {
        std::size_t part_end = relative_path.find('/', part_begin);
        if (part_end == std::string::npos) part_end = relative_path.size();
        if (!is_safe_path_component(relative_path.substr(part_begin, part_end - part_begin))) return false;
        part_begin = part_end + 1;
    }
    return true;
}

bool build_manifest(const std::string& root_folder, Manifest& out, std::string& error) {
    if (root_folder.empty()) {
        error = "the folder to scan is empty";
        return false;
    }

    try {
        Manifest result;

        // Explicit stack instead of recursion: a hostile or buggy folder tree
        // that is thousands of levels deep cannot overflow the call stack.
        struct PendingFolder {
            fs::path path;
            std::string relative_path;  // "" for the root
        };
        std::vector<PendingFolder> pending;
        pending.push_back(PendingFolder{fs::u8path(root_folder), std::string()});

        while (!pending.empty()) {
            PendingFolder current = std::move(pending.back());
            pending.pop_back();

            std::error_code iterate_error;
            fs::directory_iterator entry(current.path, iterate_error);
            if (iterate_error) {
                error = "cannot read folder '" + current.path.u8string() + "': " + iterate_error.message();
                return false;
            }

            bool folder_has_entries = false;
            const fs::directory_iterator end;
            while (entry != end) {
                folder_has_entries = true;

                const std::string name = entry->path().filename().u8string();
                const std::string relative_path =
                    current.relative_path.empty() ? name : current.relative_path + "/" + name;
                if (!is_safe_relative_path(relative_path)) {
                    error = "unsafe file name in extractor output: '" + relative_path + "'";
                    return false;
                }

                // symlink_status does NOT follow links, so a link shows up as a
                // link (and is rejected below) instead of pretending to be its target.
                std::error_code entry_error;
                const fs::file_status status = entry->symlink_status(entry_error);
                if (entry_error) {
                    error = "cannot examine '" + relative_path + "': " + entry_error.message();
                    return false;
                }

                if (fs::is_directory(status)) {
                    pending.push_back(PendingFolder{entry->path(), relative_path});
                } else if (fs::is_regular_file(status)) {
                    const std::uintmax_t size = entry->file_size(entry_error);
                    if (entry_error) {
                        error = "cannot read the size of '" + relative_path + "': " + entry_error.message();
                        return false;
                    }
                    std::uint32_t checksum = 0;
                    if (!crc32_file(entry->path().u8string(), checksum)) {
                        error = "cannot read '" + relative_path + "' to its end (locked, damaged or removed?)";
                        return false;
                    }
                    result.files.push_back(ManifestEntry{relative_path, static_cast<std::uint64_t>(size), checksum});
                } else {
                    error = "unsupported entry in extractor output: '" + relative_path +
                            "' (a link or special file; only plain files and folders are allowed)";
                    return false;
                }

                entry.increment(iterate_error);
                if (iterate_error) {
                    error = "error while reading folder '" + current.path.u8string() + "': " + iterate_error.message();
                    return false;
                }
            }

            // The root itself is not reported: an empty root just means "no files".
            if (!folder_has_entries && !current.relative_path.empty()) {
                result.empty_directories.push_back(current.relative_path);
            }
        }

        std::sort(result.files.begin(), result.files.end(),
                  [](const ManifestEntry& left, const ManifestEntry& right) {
                      return left.relative_path < right.relative_path;
                  });
        std::sort(result.empty_directories.begin(), result.empty_directories.end());
        out = std::move(result);
        return true;
    } catch (const std::exception& problem) {
        // bad_alloc, invalid UTF-8 in a path on Windows, ...
        error = "cannot scan '" + root_folder + "': " + problem.what();
        return false;
    }
}

bool compare_manifests(const Manifest& expected, const Manifest& actual, std::string& report) {
    const auto by_path = [](const ManifestEntry& left, const ManifestEntry& right) {
        return left.relative_path < right.relative_path;
    };
    // Callers normally pass sorted manifests (build_manifest sorts); this keeps
    // the comparison correct for a hand-built one as well.
    const std::vector<ManifestEntry> expected_files = sorted_copy_if_needed(expected.files, by_path);
    const std::vector<ManifestEntry> actual_files = sorted_copy_if_needed(actual.files, by_path);

    DifferenceReport differences;

    // Merge walk over two sorted lists: O(n + m).
    std::size_t expected_index = 0;
    std::size_t actual_index = 0;
    while (expected_index < expected_files.size() || actual_index < actual_files.size()) {
        if (actual_index == actual_files.size() ||
            (expected_index < expected_files.size() &&
             expected_files[expected_index].relative_path < actual_files[actual_index].relative_path)) {
            differences.add("missing file: " + expected_files[expected_index].relative_path);
            ++expected_index;
        } else if (expected_index == expected_files.size() ||
                   actual_files[actual_index].relative_path < expected_files[expected_index].relative_path) {
            differences.add("unexpected file: " + actual_files[actual_index].relative_path);
            ++actual_index;
        } else {
            const ManifestEntry& wanted = expected_files[expected_index];
            const ManifestEntry& found = actual_files[actual_index];
            if (wanted.size != found.size) {
                differences.add("size differs: " + wanted.relative_path + " (expected " +
                                std::to_string(wanted.size) + " bytes, found " + std::to_string(found.size) + ")");
            } else if (wanted.crc32 != found.crc32) {
                differences.add("checksum differs: " + wanted.relative_path + " (expected " + to_hex8(wanted.crc32) +
                                ", found " + to_hex8(found.crc32) + ")");
            }
            ++expected_index;
            ++actual_index;
        }
    }

    // Empty folders: same merge walk over two sorted string lists.
    std::vector<std::string> expected_folders = expected.empty_directories;
    std::vector<std::string> actual_folders = actual.empty_directories;
    std::sort(expected_folders.begin(), expected_folders.end());
    std::sort(actual_folders.begin(), actual_folders.end());
    std::size_t expected_folder_index = 0;
    std::size_t actual_folder_index = 0;
    while (expected_folder_index < expected_folders.size() || actual_folder_index < actual_folders.size()) {
        if (actual_folder_index == actual_folders.size() ||
            (expected_folder_index < expected_folders.size() &&
             expected_folders[expected_folder_index] < actual_folders[actual_folder_index])) {
            differences.add("missing empty folder: " + expected_folders[expected_folder_index]);
            ++expected_folder_index;
        } else if (expected_folder_index == expected_folders.size() ||
                   actual_folders[actual_folder_index] < expected_folders[expected_folder_index]) {
            differences.add("unexpected empty folder: " + actual_folders[actual_folder_index]);
            ++actual_folder_index;
        } else {
            ++expected_folder_index;
            ++actual_folder_index;
        }
    }

    if (differences.total() == 0) {
        report.clear();
        return true;
    }
    report = differences.text();
    return false;
}
