#include "units.h"

#include <algorithm>
#include <exception>
#include <filesystem>
#include <system_error>
#include <utility>

namespace {

namespace fs = std::filesystem;

inline bool is_ascii_digit(char c) { return c >= '0' && c <= '9'; }

inline char to_lower_ascii(char c) {
    return (c >= 'A' && c <= 'Z') ? static_cast<char>(c - 'A' + 'a') : c;
}

// Returns the end of the digit run that starts at `begin`.
std::size_t end_of_digit_run(const std::string& text, std::size_t begin) {
    std::size_t end = begin;
    while (end < text.size() && is_ascii_digit(text[end])) ++end;
    return end;
}

// Compares two digit runs by numeric value without converting them to an
// integer (so a 40-digit run cannot overflow). Returns <0, 0 or >0.
int compare_digit_runs(const std::string& left, std::size_t left_begin, std::size_t left_end,
                       const std::string& right, std::size_t right_begin, std::size_t right_end) {
    // Leading zeros do not change the value.
    while (left_begin + 1 < left_end && left[left_begin] == '0') ++left_begin;
    while (right_begin + 1 < right_end && right[right_begin] == '0') ++right_begin;

    const std::size_t left_length = left_end - left_begin;
    const std::size_t right_length = right_end - right_begin;
    if (left_length != right_length) return left_length < right_length ? -1 : 1;  // longer = bigger
    return left.compare(left_begin, left_length, right, right_begin, right_length);
}

// Natural comparison only (ties are NOT broken here). Returns <0, 0 or >0.
// Think of each name as a list of tokens: a digit run is ONE token ordered by
// value, every other byte is its own token ordered case-insensitively, and a
// digit token sorts before any non-digit token. Comparing token lists
// lexicographically is a total preorder, which is what std::sort needs.
int compare_natural(const std::string& left, const std::string& right) {
    std::size_t left_pos = 0;
    std::size_t right_pos = 0;
    while (left_pos < left.size() && right_pos < right.size()) {
        const bool left_is_digit = is_ascii_digit(left[left_pos]);
        const bool right_is_digit = is_ascii_digit(right[right_pos]);

        if (left_is_digit && right_is_digit) {
            const std::size_t left_end = end_of_digit_run(left, left_pos);
            const std::size_t right_end = end_of_digit_run(right, right_pos);
            const int order = compare_digit_runs(left, left_pos, left_end, right, right_pos, right_end);
            if (order != 0) return order;
            left_pos = left_end;
            right_pos = right_end;
        } else if (left_is_digit != right_is_digit) {
            return left_is_digit ? -1 : 1;
        } else {
            // Compare as unsigned so UTF-8 bytes (>= 0x80) order the same on every compiler.
            const unsigned char left_byte = static_cast<unsigned char>(to_lower_ascii(left[left_pos]));
            const unsigned char right_byte = static_cast<unsigned char>(to_lower_ascii(right[right_pos]));
            if (left_byte != right_byte) return left_byte < right_byte ? -1 : 1;
            ++left_pos;
            ++right_pos;
        }
    }
    // One name is a prefix of the other (token-wise): the shorter one comes first.
    const bool left_has_more = left_pos < left.size();
    const bool right_has_more = right_pos < right.size();
    if (left_has_more == right_has_more) return 0;
    return left_has_more ? 1 : -1;
}

// Why a pattern is rejected, or an empty string if it is fine.
std::string pattern_problem(const std::string& pattern) {
    if (pattern.empty()) return "the unit pattern is empty";
    if (pattern.size() > kMaxUnitPatternChars) return "the unit pattern is too long";
    if (pattern.find('\0') != std::string::npos) return "the unit pattern contains a NUL character";
    if (pattern.find_first_of("/\\") != std::string::npos) {
        return "the unit pattern must be a file name pattern, not a path (no '/' or '\\')";
    }
    return std::string();
}

}  // namespace

std::string unit_pattern_from_ini(const IniFile& ini) {
    const std::optional<std::string> value = ini.get("unit_pattern");
    return value.has_value() ? *value : std::string(kDefaultUnitPattern);
}

bool matches_unit_pattern(const std::string& pattern, const std::string& file_name) {
    // Classic iterative glob matcher. When a '*' is seen we remember where it
    // was; on a later mismatch we retry with the star swallowing one more
    // character. Only the LAST star is ever retried, which keeps it O(n*m).
    std::size_t pattern_pos = 0;
    std::size_t name_pos = 0;
    std::size_t star_pattern_pos = std::string::npos;  // position just after the last '*'
    std::size_t star_name_pos = 0;                     // where that star currently stops swallowing

    while (name_pos < file_name.size()) {
        if (pattern_pos < pattern.size() && pattern[pattern_pos] == '*') {
            star_pattern_pos = ++pattern_pos;
            star_name_pos = name_pos;
        } else if (pattern_pos < pattern.size() &&
                   (pattern[pattern_pos] == '?' ||
                    to_lower_ascii(pattern[pattern_pos]) == to_lower_ascii(file_name[name_pos]))) {
            ++pattern_pos;
            ++name_pos;
        } else if (star_pattern_pos != std::string::npos) {
            pattern_pos = star_pattern_pos;  // let the star swallow one more character
            name_pos = ++star_name_pos;
        } else {
            return false;
        }
    }
    while (pattern_pos < pattern.size() && pattern[pattern_pos] == '*') ++pattern_pos;  // trailing stars match nothing
    return pattern_pos == pattern.size();
}

bool natural_name_less(const std::string& left, const std::string& right) {
    const int natural_order = compare_natural(left, right);
    if (natural_order != 0) return natural_order < 0;
    return left < right;  // tie-break: exact bytes, so the order is total and repeatable
}

bool find_units(const std::string& folder, const std::string& pattern, std::vector<Unit>& units,
                std::string& error) {
    const std::string problem = pattern_problem(pattern);
    if (!problem.empty()) {
        error = problem;
        return false;
    }
    if (folder.empty()) {
        error = "the unit folder is empty";
        return false;
    }

    try {
        const fs::path folder_path = fs::u8path(folder);

        std::error_code status_error;
        const fs::file_status folder_status = fs::status(folder_path, status_error);
        if (folder_status.type() == fs::file_type::not_found) {
            error = "unit folder '" + folder + "' does not exist";
            return false;
        }
        if (status_error) {
            error = "cannot access unit folder '" + folder + "': " + status_error.message();
            return false;
        }
        if (!fs::is_directory(folder_status)) {
            error = "'" + folder + "' is not a folder";
            return false;
        }

        std::error_code iterate_error;
        fs::directory_iterator entry(folder_path, iterate_error);
        if (iterate_error) {
            error = "cannot read unit folder '" + folder + "': " + iterate_error.message();
            return false;
        }

        std::vector<Unit> found;
        const fs::directory_iterator end;
        while (entry != end) {
            const std::string name = entry->path().filename().u8string();

            // Check the cheap name filter first: files we do not care about
            // (and could not stat anyway) never cause an error.
            if (matches_unit_pattern(pattern, name)) {
                std::error_code entry_error;
                const bool is_file = entry->is_regular_file(entry_error);
                if (entry_error) {
                    error = "cannot examine '" + name + "' in '" + folder + "': " + entry_error.message();
                    return false;
                }
                if (is_file) {
                    const std::uintmax_t size = entry->file_size(entry_error);
                    if (entry_error) {
                        error = "cannot read the size of '" + name + "': " + entry_error.message();
                        return false;
                    }
                    found.push_back(Unit{name, entry->path().u8string(), static_cast<std::uint64_t>(size)});
                }
            }

            entry.increment(iterate_error);
            if (iterate_error) {
                error = "error while reading unit folder '" + folder + "': " + iterate_error.message();
                return false;
            }
        }

        std::sort(found.begin(), found.end(),
                  [](const Unit& left, const Unit& right) { return natural_name_less(left.name, right.name); });
        units = std::move(found);
        return true;
    } catch (const std::exception& problem_exception) {
        // bad_alloc, invalid UTF-8 in the folder name on Windows, ...
        error = "cannot scan unit folder '" + folder + "': " + problem_exception.what();
        return false;
    }
}
