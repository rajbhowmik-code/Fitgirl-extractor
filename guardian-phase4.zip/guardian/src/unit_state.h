// Task 2.2: which units are finished, which were interrupted, which are untouched.
//
// Two record types are written to the journal (journal.h):
//
//     UNIT_START|<unit name>|<crc>   written BEFORE the extractor runs
//     UNIT_DONE|<unit name>|<crc>    written AFTER the output is verified and moved
//
// <unit name> is the file name only (Unit::name from units.h), never a full
// path, so the journal keeps working if the folder is moved or renamed.
//
// Reading the journal back (State::from_journal):
//   * no record for a unit            -> NotStarted
//   * UNIT_START but no UNIT_DONE     -> InProgress (the run died mid-unit:
//                                        its staging folder must be cleaned
//                                        and the unit redone from scratch)
//   * UNIT_DONE                       -> Done
//
// The LATEST record for a unit wins, because the journal is append-only:
//   * START, DONE            -> Done
//   * START, DONE, START     -> InProgress (the unit was deliberately started
//                               again; the safe choice is to redo it)
//   * START, START           -> InProgress (a retried append wrote it twice)
//   * DONE, DONE             -> Done       (same reason)
//   * DONE alone             -> Done       (the record is checksummed and is
//                               only ever written after verification)
//
// Records of any OTHER type are ignored, so later phases can add their own
// record types without breaking this code. A UNIT_START / UNIT_DONE record
// that is checksum-valid but malformed (not exactly one non-empty field)
// is an error: we refuse to guess about the state of a unit.
//
// Unit names are compared byte for byte. Names come from find_units(), which
// reports the on-disk spelling, so the spelling is the same on every run.
#pragma once

#include <cstddef>
#include <string>
#include <unordered_map>
#include <vector>

#include "journal.h"

enum class UnitState { NotStarted, InProgress, Done };

// "NotStarted", "InProgress" or "Done" (for messages and tests).
const char* to_string(UnitState state);

inline constexpr char kUnitStartRecordType[] = "UNIT_START";
inline constexpr char kUnitDoneRecordType[] = "UNIT_DONE";

// Builders, so the exact record layout lives in one place.
// `unit_name` must not be empty (make_line / State would reject the record).
Record make_unit_start_record(const std::string& unit_name);
Record make_unit_done_record(const std::string& unit_name);

class State {
public:
    // Replays `records` (in file order, as returned by Journal::load()).
    // On failure returns false, sets `error` (with the record number) and
    // leaves `out` unchanged.
    static bool from_journal(const std::vector<Record>& records, State& out, std::string& error);

    // State of one unit; NotStarted for a name the journal never mentioned.
    UnitState state_of(const std::string& unit_name) const;

    // How many units the journal currently places in `state`. Units the journal
    // never mentioned are invisible here, so this is only meaningful for
    // InProgress and Done (use state_of for a specific unit).
    std::size_t count_in_state(UnitState state) const;

private:
    std::unordered_map<std::string, UnitState> states_;
};
