// Tasks 4.1 - 4.3: extract ONE archive unit so that a crash at any moment
// leaves nothing half-done in the real game folder.
//
//   1. UNIT_START is written to the journal (durably).
//   2. Any old staging folder of this unit is deleted, a fresh one is created:
//          <game folder>/.staging/<unit name>/
//   3. The extractor runs with its output set to that staging folder.
//   4. Exit code must be 0; then a manifest (path, size, CRC-32) of the staging
//      folder is built and, when one is known, compared with the expected one.
//   5. Staged files are flushed to disk, then moved into the game folder
//      (atomic replace per file), then the staging folder is deleted.
//   6. UNIT_DONE is written to the journal (durably).
//
// What a crash leaves behind:
//   * before step 1 completes   -> unit is NotStarted; nothing changed.
//   * during steps 2 - 5        -> unit is InProgress (START without DONE).
//                                  The game folder holds only complete files
//                                  (possibly some of this unit's, already moved);
//                                  the next run deletes the staging folder and
//                                  redoes the unit, replacing those files.
//   * after step 6              -> unit is Done and never touched again.
// Redoing a unit is safe ("idempotent") because every file is replaced as a
// whole, so running it twice gives the same result as running it once.
//
// This header does NOT decide which units to run, or retry: that is the main
// loop (task 5.1) and error handling (task 7.2).
//
// Paths are UTF-8 std::strings on every platform.
#pragma once

#include <cstdint>
#include <string>

#include "command_template.h"
#include "journal.h"
#include "manifest.h"
#include "units.h"

// Name of the folder (inside the game folder) that holds all staging folders.
inline constexpr char kStagingFolderName[] = ".staging";

// A unit name is used as a folder name, so it must be a plain Windows-valid
// file name (see is_safe_path_component in manifest.h).
bool is_safe_unit_name(const std::string& unit_name);

// Computes "<game_folder>/.staging/<unit_name>" as an absolute path.
// Fails (with `error`) if the unit name is unsafe or the folder name is empty.
// Pure computation: touches no files.
bool staging_folder_for_unit(const std::string& game_folder, const std::string& unit_name,
                             std::string& staging_folder, std::string& error);

// Step 2: deletes the old staging folder of the unit (if any) and creates an
// empty one. Refuses if ".staging" or the unit's staging folder is a link or a
// plain file. On success `staging_folder` is the new, empty, absolute folder.
bool prepare_staging_folder(const std::string& game_folder, const std::string& unit_name,
                            std::string& staging_folder, std::string& error);

// Step 4: builds the manifest of `staging_folder` into `actual` and checks it.
//   * expected != nullptr: `actual` must equal *expected exactly.
//   * expected == nullptr: the folder must at least contain something. An
//     extractor that exits 0 but wrote nothing almost certainly failed or
//     handed its work to another process, so that is rejected.
// On failure `error` explains why (for a mismatch it lists the differences).
bool verify_staging_folder(const std::string& staging_folder, const Manifest* expected, Manifest& actual,
                           std::string& error);

// Step 5: flushes every file of `manifest` (taken from `staging_folder`) to
// disk, creates the empty folders, then moves every file into `game_folder`,
// replacing files that are already there. Stops at the first failure; files
// moved before it stay moved (harmless, see the crash table above).
// `manifest` must come from build_manifest(staging_folder), which guarantees
// safe relative paths; every path is checked again here regardless.
bool commit_staging_folder(const std::string& staging_folder, const std::string& game_folder,
                           const Manifest& manifest, std::string& error);

// The steps of extract_unit(), used to say where a failure happened.
enum class ExtractionStage {
    Completed,         // no failure
    ValidateInput,     // unsafe unit name, game folder missing
    BuildCommand,      // the extractor command line could not be built
    WriteStartRecord,  // journal append of UNIT_START failed (nothing ran)
    PrepareStaging,    // old staging could not be deleted / new one created
    RunExtractor,      // could not start, or exit code != 0
    VerifyStaging,     // staging folder unreadable, empty or different from expected
    MoveFiles,         // flushing or moving files into the game folder failed
    WriteDoneRecord    // journal append of UNIT_DONE failed
};

// "RunExtractor" etc., for messages and tests.
const char* to_string(ExtractionStage stage);

struct UnitExtractionContext {
    Journal& journal;                          // where UNIT_START / UNIT_DONE are recorded
    const CommandTemplate& command_template;   // extractor_cmd from guardian.ini
    std::string game_folder;                   // where the real files end up; holds ".staging"
    const Manifest* expected_manifest = nullptr;  // nullptr: no expected content known
};

struct UnitExtractionResult {
    bool ok = false;
    ExtractionStage failed_stage = ExtractionStage::Completed;  // Completed when ok
    std::string error;    // readable reason when !ok
    std::string warning;  // when ok: something harmless went wrong (e.g. staging folder not fully deleted)

    // Valid once the extractor has run (failed_stage > RunExtractor, or == RunExtractor
    // with `extractor_started` true). Task 7.2 uses it to decide about retries.
    bool extractor_started = false;
    int extractor_exit_code = 0;

    // Filled when ok: what was moved into the game folder (for progress output).
    std::uint64_t files_extracted = 0;
    std::uint64_t bytes_extracted = 0;
};

// Runs the six steps above for `unit`. Never throws. Blocks until done.
UnitExtractionResult extract_unit(const Unit& unit, const UnitExtractionContext& context);
