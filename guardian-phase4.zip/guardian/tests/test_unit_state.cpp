// Task 2.2: UNIT_START / UNIT_DONE records and State::from_journal.
// Includes the full path "journal file -> load -> state" so the pieces from
// phase 1 and phase 2 are tested working together.
#include "test_common.h"

#include <string>
#include <vector>

#include "journal.h"
#include "test_util.h"
#include "unit_state.h"

namespace {

State replay(const std::vector<Record>& records) {
    State state;
    std::string error;
    const bool ok = State::from_journal(records, state, error);
    assert(ok && error.empty());
    return state;
}

// The task's "Done when": all three states, including START with no DONE.
void test_three_states() {
    const State state = replay({
        make_unit_start_record("fg-1.bin"), make_unit_done_record("fg-1.bin"),   // finished
        make_unit_start_record("fg-2.bin"),                                       // interrupted
    });
    assert(state.state_of("fg-1.bin") == UnitState::Done);
    assert(state.state_of("fg-2.bin") == UnitState::InProgress);
    assert(state.state_of("fg-3.bin") == UnitState::NotStarted);  // never mentioned
    assert(state.count_in_state(UnitState::Done) == 1);
    assert(state.count_in_state(UnitState::InProgress) == 1);
}

void test_empty_journal_means_everything_not_started() {
    const State state = replay({});
    assert(state.state_of("fg-1.bin") == UnitState::NotStarted);
    assert(state.count_in_state(UnitState::Done) == 0);
}

void test_latest_record_wins() {
    assert(replay({make_unit_start_record("a"), make_unit_start_record("a")}).state_of("a") == UnitState::InProgress);
    assert(replay({make_unit_done_record("a"), make_unit_done_record("a")}).state_of("a") == UnitState::Done);
    assert(replay({make_unit_done_record("a")}).state_of("a") == UnitState::Done);  // DONE without START
    // Started again after being done: redo (the safe choice).
    assert(replay({make_unit_start_record("a"), make_unit_done_record("a"), make_unit_start_record("a")})
               .state_of("a") == UnitState::InProgress);
}

void test_units_are_independent_and_interleaved() {
    const State state = replay({make_unit_start_record("a"), make_unit_start_record("b"),
                                make_unit_done_record("b"), make_unit_done_record("a")});
    assert(state.state_of("a") == UnitState::Done);
    assert(state.state_of("b") == UnitState::Done);
}

void test_names_compared_exactly() {
    const State state = replay({make_unit_done_record("fg-1.bin")});
    assert(state.state_of("FG-1.BIN") == UnitState::NotStarted);  // byte-exact on purpose
    assert(state.state_of("fg-1.bin ") == UnitState::NotStarted);
    assert(state.state_of("") == UnitState::NotStarted);
}

void test_other_record_types_are_ignored() {
    const State state = replay({Record{"MANIFEST", {"fg-1.bin", "x", "y"}}, make_unit_done_record("fg-1.bin"),
                                Record{"SOMETHING_NEW", {}}});
    assert(state.state_of("fg-1.bin") == UnitState::Done);
    assert(state.count_in_state(UnitState::Done) == 1);
}

void test_malformed_unit_records_are_errors() {
    const std::vector<std::vector<Record>> bad_journals = {
        {Record{"UNIT_START", {}}},
        {Record{"UNIT_DONE", {}}},
        {Record{"UNIT_DONE", {""}}},
        {Record{"UNIT_START", {"a", "b"}}},
        {make_unit_start_record("ok"), Record{"UNIT_DONE", {"a", "b"}}},
    };
    for (const auto& records : bad_journals) {
        State state = replay({make_unit_done_record("untouched")});
        std::string error;
        assert(!State::from_journal(records, state, error));
        assert(!error.empty());
        assert(state.state_of("untouched") == UnitState::Done);  // `out` unchanged on failure
    }
    State state;
    std::string error;
    assert(!State::from_journal({make_unit_start_record("ok"), Record{"UNIT_DONE", {}}}, state, error));
    assert(error.find("record 2") != std::string::npos);  // tells which record is wrong
}

void test_unusual_names_survive_the_journal_file() {
    // File names can contain '|', '%', quotes, spaces, newlines (Linux), non-ASCII.
    const std::vector<std::string> names = {"a|b.bin", "100%.bin", "we\"ird name.bin", "line\nbreak.bin",
                                            u8"\u0997\u09C7\u09AE.bin", " lead.bin", "-"};
    test_util::TempDir dir("unit_state_names");
    Journal journal(dir.file("guardian.journal"));
    std::string error;
    for (const std::string& name : names) {
        assert(journal.append(make_unit_start_record(name), &error));
        assert(journal.append(make_unit_done_record(name), &error));
    }
    const LoadResult loaded = journal.load();
    assert(loaded.ok && loaded.records.size() == names.size() * 2);
    const State state = replay(loaded.records);
    for (const std::string& name : names) assert(state.state_of(name) == UnitState::Done);
}

// The crash scenario this whole project exists for: a torn last line.
void test_crash_during_unit_through_a_real_journal() {
    test_util::TempDir dir("unit_state_crash");
    const std::string path = dir.file("guardian.journal");
    {
        Journal journal(path);
        std::string error;
        assert(journal.append(make_unit_start_record("fg-1.bin"), &error));
        assert(journal.append(make_unit_done_record("fg-1.bin"), &error));
        assert(journal.append(make_unit_start_record("fg-2.bin"), &error));
    }
    // Power cut while UNIT_DONE for fg-2 was being written: half a line, no newline.
    const std::string whole_line = make_line(make_unit_done_record("fg-2.bin"));
    test_util::write_file(path, test_util::read_file(path) + whole_line.substr(0, whole_line.size() / 2));

    const LoadResult loaded = Journal(path).load();
    assert(loaded.ok && loaded.tail_dropped);
    const State state = replay(loaded.records);
    assert(state.state_of("fg-1.bin") == UnitState::Done);
    assert(state.state_of("fg-2.bin") == UnitState::InProgress);  // the torn DONE does NOT count

    // After the repair the next run can append and everything is consistent.
    Journal journal(path);
    std::string error;
    assert(journal.append(make_unit_done_record("fg-2.bin"), &error));
    const LoadResult after = Journal(path).load();
    assert(after.ok && !after.tail_dropped);
    assert(replay(after.records).state_of("fg-2.bin") == UnitState::Done);
}

void test_to_string() {
    assert(std::string(to_string(UnitState::NotStarted)) == "NotStarted");
    assert(std::string(to_string(UnitState::InProgress)) == "InProgress");
    assert(std::string(to_string(UnitState::Done)) == "Done");
}

}  // namespace

int main() {
    test_three_states();
    test_empty_journal_means_everything_not_started();
    test_latest_record_wins();
    test_units_are_independent_and_interleaved();
    test_names_compared_exactly();
    test_other_record_types_are_ignored();
    test_malformed_unit_records_are_errors();
    test_unusual_names_survive_the_journal_file();
    test_crash_during_unit_through_a_real_journal();
    test_to_string();
    return 0;
}
