// Task 4.2: building and comparing manifests.
#include "test_common.h"

#include <filesystem>
#include <string>
#include <utility>

#include "manifest.h"
#include "test_util.h"

namespace {

namespace fs = std::filesystem;

void make_file(const test_util::TempDir& dir, const std::string& relative, const std::string& content) {
    fs::create_directories(fs::u8path(dir.file(relative)).parent_path());
    test_util::write_file(dir.file(relative), content);
}

void test_safe_relative_paths() {
    assert(is_safe_relative_path("a"));
    assert(is_safe_relative_path("a/b/c.txt"));
    assert(is_safe_relative_path(".hidden"));
    assert(is_safe_relative_path("a b/c d.txt"));
    assert(is_safe_relative_path(u8"\u0997\u09C7\u09AE/\u00E9.dat"));
    assert(is_safe_relative_path("..a"));       // only the exact parts "." and ".." are special
    assert(is_safe_relative_path("a/b..c"));

    assert(!is_safe_relative_path(""));
    assert(!is_safe_relative_path("/abs"));
    assert(!is_safe_relative_path("a/"));
    assert(!is_safe_relative_path("a//b"));
    assert(!is_safe_relative_path("."));
    assert(!is_safe_relative_path(".."));
    assert(!is_safe_relative_path("../x"));
    assert(!is_safe_relative_path("a/../x"));
    assert(!is_safe_relative_path("a/./x"));
    assert(!is_safe_relative_path("a\\b"));
    assert(!is_safe_relative_path("C:x"));
    assert(!is_safe_relative_path("a:stream"));
    assert(!is_safe_relative_path(std::string("a\0b", 3)));
    assert(!is_safe_relative_path("a\nb"));
    assert(!is_safe_relative_path("a\x7F"));

    // Windows rules (the primary target): trailing dot/space, forbidden characters, device names.
    assert(!is_safe_relative_path("a./b"));
    assert(!is_safe_relative_path("a/b "));
    assert(!is_safe_relative_path("a/b."));
    assert(!is_safe_relative_path("what?.txt"));
    assert(!is_safe_relative_path("a*b"));
    assert(!is_safe_relative_path("a<b>"));
    assert(!is_safe_relative_path("a|b"));
    assert(!is_safe_relative_path("say\"hi\""));
    assert(!is_safe_relative_path("CON"));
    assert(!is_safe_relative_path("a/nul.txt"));
    assert(!is_safe_relative_path("Aux.tar.gz"));
    assert(!is_safe_relative_path("data/com1"));
    assert(!is_safe_relative_path("LPT9.log"));
    assert(is_safe_relative_path("console.txt"));  // only the exact device stems are reserved
    assert(is_safe_relative_path("com10"));
    assert(is_safe_relative_path("com0"));
    assert(is_safe_relative_path("lpt"));
    assert(is_safe_relative_path("nullable"));
    assert(is_safe_path_component(std::string(255, 'x')));
    assert(!is_safe_path_component(std::string(256, 'x')));
}

void test_build_manifest_basic() {
    test_util::TempDir dir("manifest_basic");
    make_file(dir, "z_last.txt", "123456789");          // CRC-32 check value
    make_file(dir, "a/b/deep.bin", "x");
    make_file(dir, "a/empty.dat", "");
    make_file(dir, "B_upper.txt", "hello");
    fs::create_directories(fs::u8path(dir.file("only_folder/inner")));  // empty leaf folder

    Manifest manifest;
    std::string error;
    assert(build_manifest(dir.path_utf8(), manifest, error));

    // Sorted by plain byte order: '/' (0x2F) < 'B' < 'a'... uppercase before lowercase.
    assert(manifest.files.size() == 4);
    assert(manifest.files[0].relative_path == "B_upper.txt");
    assert(manifest.files[1].relative_path == "a/b/deep.bin");
    assert(manifest.files[2].relative_path == "a/empty.dat");
    assert(manifest.files[3].relative_path == "z_last.txt");

    assert(manifest.files[3].size == 9 && manifest.files[3].crc32 == 0xCBF43926u);
    assert(manifest.files[2].size == 0 && manifest.files[2].crc32 == 0u);
    assert(manifest.files[1].size == 1);

    // Only the leaf folder is "empty"; its parent is implied by the child.
    assert(manifest.empty_directories.size() == 1);
    assert(manifest.empty_directories[0] == "only_folder/inner");
}

void test_build_manifest_empty_and_errors() {
    test_util::TempDir dir("manifest_errors");
    std::string error;

    Manifest manifest;
    assert(build_manifest(dir.path_utf8(), manifest, error));  // empty root is fine here
    assert(manifest.is_empty());

    // On failure the output is left alone.
    Manifest untouched;
    untouched.files.push_back(ManifestEntry{"keep", 1, 2});
    assert(!build_manifest(dir.file("missing"), untouched, error));
    assert(!error.empty());
    assert(untouched.files.size() == 1);

    assert(!build_manifest("", manifest, error));

    // A file given instead of a folder.
    make_file(dir, "plain.txt", "x");
    assert(!build_manifest(dir.file("plain.txt"), manifest, error));
}

void test_large_file_and_many_files() {
    test_util::TempDir dir("manifest_large");
    // Larger than the 1 MiB read chunk, so chunk handling is exercised.
    make_file(dir, "big.bin", std::string(3 * 1024 * 1024 + 17, 'q'));
    for (int index = 0; index < 200; ++index) make_file(dir, "many/f" + std::to_string(index), std::to_string(index));

    Manifest manifest;
    std::string error;
    assert(build_manifest(dir.path_utf8(), manifest, error));
    assert(manifest.files.size() == 201);
    for (const ManifestEntry& entry : manifest.files) {
        if (entry.relative_path == "big.bin") assert(entry.size == 3u * 1024 * 1024 + 17);
    }
}

#ifndef _WIN32  // creating symbolic links needs special rights on Windows
void test_links_are_rejected() {
    test_util::TempDir dir("manifest_links");
    test_util::TempDir outside("manifest_outside");
    make_file(outside, "secret.txt", "secret");
    std::string error;
    Manifest manifest;

    make_file(dir, "ok.txt", "fine");
    fs::create_symlink(fs::u8path(outside.file("secret.txt")), fs::u8path(dir.file("file_link")));
    assert(!build_manifest(dir.path_utf8(), manifest, error));
    assert(error.find("file_link") != std::string::npos);
    fs::remove(fs::u8path(dir.file("file_link")));

    fs::create_directory_symlink(fs::u8path(outside.path_utf8()), fs::u8path(dir.file("folder_link")));
    error.clear();
    assert(!build_manifest(dir.path_utf8(), manifest, error));
    assert(error.find("folder_link") != std::string::npos);
}

void test_unsafe_name_is_rejected() {
    test_util::TempDir dir("manifest_unsafe");
    std::string error;
    Manifest manifest;
    // Legal on Linux, forbidden for us: a backslash would be a separator on Windows.
    make_file(dir, "evil\\name.txt", "x");
    assert(!build_manifest(dir.path_utf8(), manifest, error));
    assert(error.find("unsafe") != std::string::npos);
}
#endif

Manifest sample_manifest() {
    Manifest manifest;
    manifest.files = {{"a.txt", 3, 0x11111111u}, {"b/c.txt", 5, 0x22222222u}, {"d.txt", 0, 0u}};
    manifest.empty_directories = {"e"};
    return manifest;
}

void test_compare_identical() {
    std::string report = "stale";
    assert(compare_manifests(sample_manifest(), sample_manifest(), report));
    assert(report.empty());
    assert(compare_manifests(Manifest(), Manifest(), report));
}

void test_compare_differences() {
    std::string report;

    Manifest missing = sample_manifest();
    missing.files.erase(missing.files.begin() + 1);
    assert(!compare_manifests(sample_manifest(), missing, report));
    assert(report.find("missing file: b/c.txt") != std::string::npos);

    Manifest extra = sample_manifest();
    extra.files.push_back(ManifestEntry{"zzz.txt", 1, 1});
    assert(!compare_manifests(sample_manifest(), extra, report));
    assert(report.find("unexpected file: zzz.txt") != std::string::npos);

    Manifest wrong_size = sample_manifest();
    wrong_size.files[0].size = 4;
    assert(!compare_manifests(sample_manifest(), wrong_size, report));
    assert(report.find("size differs: a.txt") != std::string::npos);

    Manifest wrong_crc = sample_manifest();
    wrong_crc.files[1].crc32 = 0x22222223u;  // one bit off
    assert(!compare_manifests(sample_manifest(), wrong_crc, report));
    assert(report.find("checksum differs: b/c.txt") != std::string::npos);
    assert(report.find("22222222") != std::string::npos && report.find("22222223") != std::string::npos);

    Manifest no_folder = sample_manifest();
    no_folder.empty_directories.clear();
    assert(!compare_manifests(sample_manifest(), no_folder, report));
    assert(report.find("missing empty folder: e") != std::string::npos);
    assert(!compare_manifests(no_folder, sample_manifest(), report));
    assert(report.find("unexpected empty folder: e") != std::string::npos);

    // Compare ignores the order the caller built the lists in.
    Manifest shuffled = sample_manifest();
    std::swap(shuffled.files[0], shuffled.files[2]);
    assert(compare_manifests(sample_manifest(), shuffled, report));
}

void test_compare_report_is_capped() {
    Manifest expected;
    for (int index = 0; index < 25; ++index) {
        expected.files.push_back(ManifestEntry{"f" + std::string(index < 10 ? "0" : "") + std::to_string(index), 1, 1});
    }
    std::string report;
    assert(!compare_manifests(expected, Manifest(), report));
    assert(test_util::count_char(report, '\n') == 11);  // 10 listed + the summary line
    assert(report.find("and 15 more differences") != std::string::npos);
}

}  // namespace

int main() {
    test_safe_relative_paths();
    test_build_manifest_basic();
    test_build_manifest_empty_and_errors();
    test_large_file_and_many_files();
#ifndef _WIN32
    test_links_are_rejected();
    test_unsafe_name_is_rejected();
#endif
    test_compare_identical();
    test_compare_differences();
    test_compare_report_is_capped();
    return 0;
}
