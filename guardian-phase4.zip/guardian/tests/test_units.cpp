// Task 2.1: find_units - discovery, natural order, pattern matching, errors.
#include "test_common.h"

#include <algorithm>
#include <string>
#include <vector>

#include "ini_file.h"
#include "test_util.h"
#include "units.h"

namespace {

namespace fs = std::filesystem;

std::vector<std::string> names_of(const std::vector<Unit>& units) {
    std::vector<std::string> names;
    for (const Unit& unit : units) names.push_back(unit.name);
    return names;
}

void touch(const test_util::TempDir& dir, const std::string& name, const std::string& content = "x") {
    test_util::write_file(dir.file(name), content);
}

std::vector<std::string> scan(const test_util::TempDir& dir, const std::string& pattern = kDefaultUnitPattern) {
    std::vector<Unit> units;
    std::string error;
    const bool ok = find_units(dir.path_utf8(), pattern, units, error);
    assert(ok && error.empty());
    return names_of(units);
}

// The task's "Done when" check.
void test_natural_order_fg_files() {
    test_util::TempDir dir("units_order");
    // Created in a scrambled order on purpose.
    touch(dir, "fg-10.bin");
    touch(dir, "fg-1.bin");
    touch(dir, "fg-2.bin");
    assert((scan(dir) == std::vector<std::string>{"fg-1.bin", "fg-2.bin", "fg-10.bin"}));
}

void test_name_path_and_size() {
    test_util::TempDir dir("units_fields");
    touch(dir, "fg-1.bin", std::string(1234, 'a'));
    touch(dir, "fg-2.bin", "");  // an empty file is still reported (the extractor will complain)

    std::vector<Unit> units;
    std::string error;
    assert(find_units(dir.path_utf8(), "*.bin", units, error));
    assert(units.size() == 2);
    assert(units[0].name == "fg-1.bin" && units[0].size == 1234);
    assert(units[0].path == dir.file("fg-1.bin"));
    assert(units[1].name == "fg-2.bin" && units[1].size == 0);
}

void test_only_matching_regular_files() {
    test_util::TempDir dir("units_filter");
    touch(dir, "fg-1.bin");
    touch(dir, "fg-1.bin.tmp");   // partial download: must NOT match *.bin
    touch(dir, "readme.txt");
    touch(dir, "setup.exe");
    fs::create_directories(dir.path() / "folder.bin");   // a FOLDER named like a unit
    fs::create_directories(dir.path() / ".staging" / "fg-1");
    touch(dir, "folder.bin/inner.bin");                  // sub-folders are not searched
    assert((scan(dir) == std::vector<std::string>{"fg-1.bin"}));
}

void test_custom_pattern_and_case_insensitive() {
    test_util::TempDir dir("units_pattern");
    touch(dir, "data-1.arc");
    touch(dir, "DATA-2.ARC");
    touch(dir, "data-3.bin");
    assert((scan(dir, "*.arc") == std::vector<std::string>{"data-1.arc", "DATA-2.ARC"}));
    assert((scan(dir, "data-?.bin") == std::vector<std::string>{"data-3.bin"}));
    assert(scan(dir, "nothing*").empty());  // no match is not an error
}

void test_empty_folder_gives_empty_list() {
    test_util::TempDir dir("units_empty");
    assert(scan(dir).empty());
}

void test_non_ascii_names_and_folder() {
    test_util::TempDir dir(u8"units_\u0997\u09C7\u09AE");
    touch(dir, u8"\u00E9-2.bin");
    touch(dir, u8"\u00E9-10.bin");
    assert((scan(dir) == std::vector<std::string>{u8"\u00E9-2.bin", u8"\u00E9-10.bin"}));
}

void test_pattern_matching_rules() {
    assert(matches_unit_pattern("*.bin", "a.bin"));
    assert(matches_unit_pattern("*.bin", ".bin"));       // star matches nothing
    assert(matches_unit_pattern("*.BIN", "a.bin"));      // case-insensitive
    assert(!matches_unit_pattern("*.bin", "a.bin2"));
    assert(!matches_unit_pattern("*.bin", "bin"));
    assert(matches_unit_pattern("fg-?.bin", "fg-1.bin"));
    assert(!matches_unit_pattern("fg-?.bin", "fg-10.bin"));
    assert(!matches_unit_pattern("fg-?.bin", "fg-.bin"));  // '?' needs exactly one character
    assert(matches_unit_pattern("a*b*c", "aXXbYYc"));
    assert(matches_unit_pattern("a*b*c", "abc"));
    assert(!matches_unit_pattern("a*b*c", "aXXbYY"));
    assert(matches_unit_pattern("**.bin", "x.bin"));
    assert(matches_unit_pattern("*", "anything"));
    assert(matches_unit_pattern("*", ""));
    assert(matches_unit_pattern("", ""));
    assert(!matches_unit_pattern("", "x"));
    assert(matches_unit_pattern("[a].bin", "[a].bin"));  // brackets are literal
    assert(!matches_unit_pattern("[a].bin", "a.bin"));
    assert(matches_unit_pattern("a*b", "ab") && matches_unit_pattern("a*b", "a-b-b"));

    // Adversarial pattern: must finish instantly (no exponential backtracking).
    const std::string nasty_pattern = std::string(200, '*') + "x";
    assert(!matches_unit_pattern(nasty_pattern, std::string(5000, 'a')));
    const std::string many_stars = "a*a*a*a*a*a*a*a*a*a*b";
    assert(!matches_unit_pattern(many_stars, std::string(5000, 'a')));
}

void test_natural_order_rules() {
    // Numbers compare by value.
    assert(natural_name_less("fg-2", "fg-10"));
    assert(!natural_name_less("fg-10", "fg-2"));
    assert(natural_name_less("fg-9.bin", "fg-10.bin"));
    assert(natural_name_less("fg-99.bin", "fg-100.bin"));
    assert(natural_name_less("fg-01.bin", "fg-2.bin"));   // leading zeros do not matter...
    assert(natural_name_less("fg-1.bin", "fg-02.bin"));
    // ...but names equal in value are still strictly ordered (total order).
    assert(natural_name_less("fg-1.bin", "fg-01.bin") != natural_name_less("fg-01.bin", "fg-1.bin"));
    assert(!natural_name_less("fg-1.bin", "fg-1.bin"));    // irreflexive
    // Case: letters ignore case first, bytes break the tie.
    assert(natural_name_less("a-2", "B-1"));
    assert(natural_name_less("A.bin", "a.bin") != natural_name_less("a.bin", "A.bin"));
    // Prefix sorts first, digits sort before letters.
    assert(natural_name_less("fg", "fg-1"));
    assert(natural_name_less("fg-1", "fg-a"));
    assert(natural_name_less("", "a"));
    // Huge digit runs cannot overflow.
    const std::string huge_small = "x" + std::string(60, '9');
    const std::string huge_big = "x1" + std::string(60, '0');
    assert(natural_name_less(huge_small, huge_big));
    assert(!natural_name_less(huge_big, huge_small));
    // Multiple numbers: compare left to right.
    assert(natural_name_less("a1b2", "a1b10"));
    assert(natural_name_less("a1b20", "a2b1"));
}

void test_sort_is_a_consistent_total_order() {
    // Shuffle-independent: any input order gives the same output.
    std::vector<std::string> names = {"fg-10.bin", "fg-1.bin", "FG-2.bin", "fg-02.bin", "fg-2.bin",
                                      "fg-001.bin", "fg-a.bin", "fg.bin", "fg-100.bin", "fg-9.bin"};
    std::vector<std::string> sorted = names;
    std::sort(sorted.begin(), sorted.end(), natural_name_less);
    for (int round = 0; round < 50; ++round) {
        std::vector<std::string> permutation = names;
        std::next_permutation(permutation.begin(), permutation.end());
        std::rotate(permutation.begin(), permutation.begin() + (round % permutation.size()), permutation.end());
        std::sort(permutation.begin(), permutation.end(), natural_name_less);
        assert(permutation == sorted);
    }
    // Transitivity spot check over all triples.
    for (const auto& a : names)
        for (const auto& b : names)
            for (const auto& c : names)
                if (natural_name_less(a, b) && natural_name_less(b, c)) assert(natural_name_less(a, c));
}

void test_errors() {
    test_util::TempDir dir("units_errors");
    std::vector<Unit> units = {Unit{"keep", "keep", 1}};
    std::string error;

    assert(!find_units(dir.file("missing"), "*.bin", units, error));
    assert(error.find("does not exist") != std::string::npos);

    touch(dir, "afile.txt");
    error.clear();
    assert(!find_units(dir.file("afile.txt"), "*.bin", units, error));
    assert(error.find("not a folder") != std::string::npos);

    error.clear();
    assert(!find_units("", "*.bin", units, error) && !error.empty());

    // Bad patterns.
    for (const std::string& bad : {std::string(), std::string("sub/*.bin"), std::string("..\\*.bin"),
                                  std::string("a\0b", 3), std::string(kMaxUnitPatternChars + 1, 'a')}) {
        error.clear();
        assert(!find_units(dir.path_utf8(), bad, units, error) && !error.empty());
    }

    // `units` is untouched after every failure.
    assert(units.size() == 1 && units[0].name == "keep");
}

void test_pattern_from_ini() {
    IniFile ini;
    std::string error;
    assert(parse_ini_text("extractor_cmd = x {unit} {out}\n", ini, error));
    assert(unit_pattern_from_ini(ini) == "*.bin");  // default
    assert(parse_ini_text("unit_pattern = *.arc\n", ini, error));
    assert(unit_pattern_from_ini(ini) == "*.arc");
    assert(parse_ini_text("UNIT_PATTERN = \"fg-*.bin\"\n", ini, error));
    assert(unit_pattern_from_ini(ini) == "fg-*.bin");  // case-insensitive key, quotes stripped
}

}  // namespace

int main() {
    test_natural_order_fg_files();
    test_name_path_and_size();
    test_only_matching_regular_files();
    test_custom_pattern_and_case_insensitive();
    test_empty_folder_gives_empty_list();
    test_non_ascii_names_and_folder();
    test_pattern_matching_rules();
    test_natural_order_rules();
    test_sort_is_a_consistent_total_order();
    test_errors();
    test_pattern_from_ini();
    return 0;
}
