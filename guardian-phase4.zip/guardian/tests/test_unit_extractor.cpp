// Tasks 4.1 - 4.3: safe extraction of one unit (staging, verify, atomic move).
// Usage: test_unit_extractor [path-to-fake_extractor]
#include "test_common.h"

#include <algorithm>
#include <filesystem>
#include <map>
#include <string>
#include <vector>

#include "command_line.h"
#include "command_template.h"
#include "fake_unit_manifest.h"
#include "journal.h"
#include "manifest.h"
#include "process.h"
#include "test_util.h"
#include "unit_extractor.h"
#include "unit_state.h"
#include "utf8_arguments.h"

namespace {

namespace fs = std::filesystem;

std::string g_extractor;  // path of the fake_extractor executable

// Template: the fake extractor, no delay (fast tests).
CommandTemplate fake_extractor_template(const std::string& extra_options = "--delay-ms 0") {
    CommandTemplate command_template;
    std::string error;
    const bool parsed = CommandTemplate::parse(quote_argument(g_extractor) + " {unit} {out} " + extra_options,
                                               command_template, error);
    assert(parsed);
    return command_template;
}

// Template for a program that succeeds but writes nothing.
CommandTemplate do_nothing_template() {
    CommandTemplate command_template;
    std::string error;
#ifdef _WIN32
    const bool parsed = CommandTemplate::parse("cmd /c exit 0 {unit} {out}", command_template, error);
#else
    const bool parsed = CommandTemplate::parse("/bin/sh -c \"exit 0\" ignored {unit} {out}", command_template, error);
#endif
    assert(parsed);
    return command_template;
}

Unit make_unit(const test_util::TempDir& dir, const std::string& name) {
    return Unit{name, dir.file("archives/" + name), 0};
}

// Every file under `game_folder` EXCEPT the ".staging" folder, as a manifest.
Manifest game_files_without_staging(const std::string& game_folder) {
    Manifest manifest;
    std::string error;
    // Scan a copy of the listing: build_manifest on the whole folder would also see .staging.
    const fs::path root = fs::u8path(game_folder);
    for (const fs::directory_entry& entry : fs::directory_iterator(root)) {
        if (entry.path().filename() == kStagingFolderName) continue;
        // Only top-level folders hold files in these tests, so scan each one on its own.
        Manifest part;
        assert(entry.is_directory());
        assert(build_manifest(entry.path().u8string(), part, error));
        for (ManifestEntry file : part.files) {
            file.relative_path = entry.path().filename().u8string() + "/" + file.relative_path;
            manifest.files.push_back(file);
        }
    }
    std::sort(manifest.files.begin(), manifest.files.end(),
              [](const ManifestEntry& left, const ManifestEntry& right) { return left.relative_path < right.relative_path; });
    return manifest;
}

UnitState journal_state_of(const Journal& journal, const std::string& unit_name) {
    const LoadResult loaded = journal.load();
    assert(loaded.ok);
    State state;
    std::string error;
    assert(State::from_journal(loaded.records, state, error));
    return state.state_of(unit_name);
}

std::size_t journal_record_count(const Journal& journal) {
    const LoadResult loaded = journal.load();
    assert(loaded.ok);
    return loaded.records.size();
}

// ---------------------------------------------------------------------------

void test_unit_name_rules() {
    assert(is_safe_unit_name("fg-1.bin"));
    assert(is_safe_unit_name("fg 1 (copy).bin"));
    assert(is_safe_unit_name(u8"\u0997\u09C7\u09AE.bin"));
    assert(is_safe_unit_name(".hidden"));

    assert(!is_safe_unit_name(""));
    assert(!is_safe_unit_name("."));
    assert(!is_safe_unit_name(".."));
    assert(!is_safe_unit_name("a/b"));
    assert(!is_safe_unit_name("a\\b"));
    assert(!is_safe_unit_name("C:evil"));
    assert(!is_safe_unit_name("a*b"));
    assert(!is_safe_unit_name("a?b"));
    assert(!is_safe_unit_name("a|b"));
    assert(!is_safe_unit_name("trailing."));
    assert(!is_safe_unit_name("trailing "));
    assert(!is_safe_unit_name(std::string("a\0b", 3)));
    assert(!is_safe_unit_name("tab\there"));
    assert(!is_safe_unit_name("CON"));
    assert(!is_safe_unit_name("nul.bin"));
    assert(!is_safe_unit_name(std::string(256, 'x')));
    assert(is_safe_unit_name(std::string(255, 'x')));
}

void test_staging_path() {
    std::string staging;
    std::string error;
    assert(staging_folder_for_unit("games/my game", "fg-1.bin", staging, error));
    const fs::path expected = fs::absolute(fs::u8path("games/my game")) / ".staging" / "fg-1.bin";
    assert(fs::u8path(staging) == expected);

    assert(!staging_folder_for_unit("games", "../escape", staging, error));
    assert(!staging_folder_for_unit("", "fg-1.bin", staging, error));
}

// Task 4.1: staging gets the files, the real folder gets none.
void test_prepare_staging_deletes_old_content() {
    test_util::TempDir dir("ext_prepare");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game + "/.staging/fg-1.bin/old/deep"));
    test_util::write_file(game + "/.staging/fg-1.bin/old/deep/stale.txt", "stale");
    fs::create_directories(fs::u8path(game + "/.staging/fg-2.bin"));
    test_util::write_file(game + "/.staging/fg-2.bin/other.txt", "other unit");

    std::string staging, error;
    assert(prepare_staging_folder(game, "fg-1.bin", staging, error));
    assert(fs::is_directory(fs::u8path(staging)));
    assert(fs::is_empty(fs::u8path(staging)));                                   // old content gone
    assert(fs::exists(fs::u8path(game + "/.staging/fg-2.bin/other.txt")));       // other units untouched

    // Missing game folder / unsafe name.
    assert(!prepare_staging_folder(dir.file("nope"), "fg-1.bin", staging, error));
    assert(!fs::exists(fs::u8path(dir.file("nope"))));                           // not created behind our back
    assert(!prepare_staging_folder(game, "../x", staging, error));

    // ".staging" is a plain file: refused.
    test_util::TempDir other("ext_prepare_file");
    test_util::write_file(other.file(".staging"), "i am a file");
    assert(!prepare_staging_folder(other.path_utf8(), "fg-1.bin", staging, error));
    assert(test_util::read_file(other.file(".staging")) == "i am a file");
}

#ifndef _WIN32
void test_prepare_staging_refuses_links() {
    test_util::TempDir dir("ext_prepare_link");
    test_util::TempDir outside("ext_prepare_outside");
    test_util::write_file(outside.file("precious.txt"), "precious");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game));
    std::string staging, error;

    // ".staging" itself is a link to a folder elsewhere.
    fs::create_directory_symlink(fs::u8path(outside.path_utf8()), fs::u8path(game + "/.staging"));
    assert(!prepare_staging_folder(game, "fg-1.bin", staging, error));
    assert(test_util::read_file(outside.file("precious.txt")) == "precious");
    fs::remove(fs::u8path(game + "/.staging"));

    // The unit's staging folder is a link.
    fs::create_directories(fs::u8path(game + "/.staging"));
    fs::create_directory_symlink(fs::u8path(outside.path_utf8()), fs::u8path(game + "/.staging/fg-1.bin"));
    assert(!prepare_staging_folder(game, "fg-1.bin", staging, error));
    assert(test_util::read_file(outside.file("precious.txt")) == "precious");
}
#endif

// Runs the fake extractor directly into `out_folder` (like step 3 does).
void run_fake_extractor_into(const std::string& unit, const std::string& out_folder) {
    const std::string command_line =
        quote_argument(g_extractor) + " " + quote_argument(unit) + " " + quote_argument(out_folder) + " --delay-ms 0";
    assert(run_process(command_line) == 0);
}

// Task 4.2: a deliberately corrupted file makes verification fail.
void test_verify_detects_corruption() {
    test_util::TempDir dir("ext_verify");
    const std::string staging = dir.file("staging");
    run_fake_extractor_into("fg-1.bin", staging);
    const Manifest expected = make_fake_unit_manifest("fg-1.bin");
    Manifest actual;
    std::string error;

    assert(verify_staging_folder(staging, &expected, actual, error));
    assert(actual == expected);

    // One flipped byte, same size: only the CRC can see it.
    const std::string victim = staging + "/fg-1/data/medium.dat";
    std::string content = test_util::read_file(victim);
    content[1234] = static_cast<char>(content[1234] ^ 0x01);
    test_util::write_file(victim, content);
    assert(!verify_staging_folder(staging, &expected, actual, error));
    assert(error.find("checksum differs: fg-1/data/medium.dat") != std::string::npos);

    // Cut-off file (what a power cut leaves behind): size differs.
    test_util::write_file(victim, content.substr(0, content.size() / 2));
    assert(!verify_staging_folder(staging, &expected, actual, error));
    assert(error.find("size differs: fg-1/data/medium.dat") != std::string::npos);

    // Restore, then remove one file and add a stranger.
    content[1234] = static_cast<char>(content[1234] ^ 0x01);
    test_util::write_file(victim, content);
    assert(verify_staging_folder(staging, &expected, actual, error));
    fs::remove(fs::u8path(staging + "/fg-1/empty.dat"));
    assert(!verify_staging_folder(staging, &expected, actual, error));
    assert(error.find("missing file: fg-1/empty.dat") != std::string::npos);
    test_util::write_file(staging + "/fg-1/empty.dat", "");
    test_util::write_file(staging + "/fg-1/extra.txt", "unexpected");
    assert(!verify_staging_folder(staging, &expected, actual, error));
    assert(error.find("unexpected file: fg-1/extra.txt") != std::string::npos);
}

void test_verify_without_expected_manifest() {
    test_util::TempDir dir("ext_verify_none");
    Manifest actual;
    std::string error;

    fs::create_directories(fs::u8path(dir.file("empty")));
    assert(!verify_staging_folder(dir.file("empty"), nullptr, actual, error));  // nothing produced
    assert(error.find("no files") != std::string::npos);

    fs::create_directories(fs::u8path(dir.file("one")));
    test_util::write_file(dir.file("one/file.txt"), "x");
    assert(verify_staging_folder(dir.file("one"), nullptr, actual, error));
    assert(actual.files.size() == 1);

    assert(!verify_staging_folder(dir.file("does not exist"), nullptr, actual, error));
}

// Task 4.3: files and empty folders arrive, old files are replaced, bad input moves nothing.
void test_commit_moves_everything() {
    test_util::TempDir dir("ext_commit");
    const std::string staging = dir.file("game/.staging/fg-1.bin");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(staging + "/data/sub"));
    fs::create_directories(fs::u8path(staging + "/saves"));  // empty folder that must survive
    test_util::write_file(staging + "/data/sub/a.dat", "new a");
    test_util::write_file(staging + "/b.dat", "new b");

    // A damaged copy of b.dat from an interrupted earlier run is already in place.
    test_util::write_file(game + "/b.dat", "half-writ");

    Manifest manifest;
    std::string error;
    assert(build_manifest(staging, manifest, error));
    assert(commit_staging_folder(staging, game, manifest, error));

    assert(test_util::read_file(game + "/data/sub/a.dat") == "new a");
    assert(test_util::read_file(game + "/b.dat") == "new b");
    assert(fs::is_directory(fs::u8path(game + "/saves")));
    assert(!fs::exists(fs::u8path(staging + "/b.dat")));  // moved, not copied
}

void test_commit_rejects_bad_input_without_moving() {
    test_util::TempDir dir("ext_commit_bad");
    const std::string staging = dir.file("game/.staging/u");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(staging));
    test_util::write_file(staging + "/good.txt", "good");
    std::string error;

    Manifest hostile;
    hostile.files.push_back(ManifestEntry{"good.txt", 4, 0});
    hostile.files.push_back(ManifestEntry{"../../escaped.txt", 1, 0});
    assert(!commit_staging_folder(staging, game, hostile, error));
    assert(!fs::exists(fs::u8path(game + "/good.txt")));  // validated up front: nothing was moved
    assert(!fs::exists(fs::u8path(dir.file("escaped.txt"))));

    Manifest hostile_folder;
    hostile_folder.empty_directories.push_back("a/../../b");
    assert(!commit_staging_folder(staging, game, hostile_folder, error));

    // A FILE where a folder is needed, and a FOLDER where a file is needed: clear failure.
    test_util::write_file(game + "/blocker", "i am a file");
    fs::create_directories(fs::u8path(staging + "/blocker"));
    test_util::write_file(staging + "/blocker/inner.txt", "x");
    Manifest clash;
    assert(build_manifest(staging, clash, error));
    assert(!commit_staging_folder(staging, game, clash, error));
    assert(!error.empty());
    assert(test_util::read_file(game + "/blocker") == "i am a file");  // user data untouched
    fs::remove_all(fs::u8path(staging + "/blocker"));

    // The reverse: a real FOLDER sits where a file must go. It is not deleted.
    fs::create_directories(fs::u8path(game + "/occupied/keep"));
    test_util::write_file(game + "/occupied/keep/user.txt", "user data");
    test_util::write_file(staging + "/occupied", "file wants this name");
    Manifest reverse;
    assert(build_manifest(staging, reverse, error));
    assert(!commit_staging_folder(staging, game, reverse, error));
    assert(test_util::read_file(game + "/occupied/keep/user.txt") == "user data");

    assert(!commit_staging_folder("", game, Manifest(), error));
    assert(!commit_staging_folder(staging, "", Manifest(), error));
}

// ---------------------------------------------------------------------------
// extract_unit: the whole pipeline
// ---------------------------------------------------------------------------

void test_extract_unit_success() {
    test_util::TempDir dir("ext_ok");
    const std::string game = dir.file(u8"my game \u00E9");  // space + non-ASCII: quoting must hold
    fs::create_directories(fs::u8path(game));
    Journal journal(dir.file("journal.log"));
    const CommandTemplate command_template = fake_extractor_template();
    const Manifest expected = make_fake_unit_manifest("fg-1.bin");

    const UnitExtractionContext context{journal, command_template, game, &expected};
    const UnitExtractionResult result = extract_unit(make_unit(dir, "fg-1.bin"), context);

    assert(result.ok);
    assert(result.failed_stage == ExtractionStage::Completed);
    assert(result.warning.empty());
    assert(result.extractor_started && result.extractor_exit_code == 0);
    assert(result.files_extracted == expected.files.size());
    std::uint64_t expected_bytes = 0;
    for (const ManifestEntry& file : expected.files) expected_bytes += file.size;
    assert(result.bytes_extracted == expected_bytes);

    // Real folder holds exactly the expected files; staging folder is gone.
    assert(game_files_without_staging(game) == expected);
    assert(!fs::exists(fs::u8path(game + "/.staging/fg-1.bin")));

    // Journal: START then DONE, in that order.
    const LoadResult loaded = journal.load();
    assert(loaded.ok && loaded.records.size() == 2);
    assert(loaded.records[0] == make_unit_start_record("fg-1.bin"));
    assert(loaded.records[1] == make_unit_done_record("fg-1.bin"));
    assert(journal_state_of(journal, "fg-1.bin") == UnitState::Done);
}

void test_extract_unit_without_expected_manifest() {
    test_util::TempDir dir("ext_ok_noexpected");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game));
    Journal journal(dir.file("journal.log"));
    const CommandTemplate command_template = fake_extractor_template();

    const UnitExtractionContext context{journal, command_template, game, nullptr};
    assert(extract_unit(make_unit(dir, "fg-2.bin"), context).ok);
    assert(game_files_without_staging(game) == make_fake_unit_manifest("fg-2.bin"));
}

void test_extract_two_units_and_repeat() {
    test_util::TempDir dir("ext_two");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game));
    Journal journal(dir.file("journal.log"));
    const CommandTemplate command_template = fake_extractor_template();
    const Manifest expected_one = make_fake_unit_manifest("fg-1.bin");
    const Manifest expected_two = make_fake_unit_manifest("fg-2.bin");

    assert(extract_unit(make_unit(dir, "fg-1.bin"), {journal, command_template, game, &expected_one}).ok);
    assert(extract_unit(make_unit(dir, "fg-2.bin"), {journal, command_template, game, &expected_two}).ok);

    Manifest both = expected_one;
    both.files.insert(both.files.end(), expected_two.files.begin(), expected_two.files.end());
    std::sort(both.files.begin(), both.files.end(),
              [](const ManifestEntry& left, const ManifestEntry& right) { return left.relative_path < right.relative_path; });
    assert(game_files_without_staging(game) == both);

    // Doing a unit again (what resume does after a crash) gives the same result.
    assert(extract_unit(make_unit(dir, "fg-1.bin"), {journal, command_template, game, &expected_one}).ok);
    assert(game_files_without_staging(game) == both);
    assert(journal_record_count(journal) == 6);  // START/DONE x 3 runs
}

// Simulates the state after a power cut in the middle of step 5 / before step 6.
void test_extract_unit_recovers_from_interrupted_attempt() {
    test_util::TempDir dir("ext_recover");
    const std::string game = dir.file("game");
    Journal journal(dir.file("journal.log"));
    const CommandTemplate command_template = fake_extractor_template();
    const Manifest expected = make_fake_unit_manifest("fg-1.bin");

    // Leftovers: START without DONE, a stale staging file, and a damaged
    // (cut-off) copy of one real file.
    std::string error;
    assert(journal.append(make_unit_start_record("fg-1.bin"), &error));
    fs::create_directories(fs::u8path(game + "/.staging/fg-1.bin"));
    test_util::write_file(game + "/.staging/fg-1.bin/stale_from_crash.tmp", "garbage");
    fs::create_directories(fs::u8path(game + "/fg-1/data"));
    test_util::write_file(game + "/fg-1/data/medium.dat", "cut off");
    assert(journal_state_of(journal, "fg-1.bin") == UnitState::InProgress);

    const UnitExtractionResult result = extract_unit(make_unit(dir, "fg-1.bin"), {journal, command_template, game, &expected});
    assert(result.ok);
    assert(game_files_without_staging(game) == expected);  // damaged file replaced, stale file not promoted
    assert(!fs::exists(fs::u8path(game + "/.staging/fg-1.bin")));
    assert(journal_state_of(journal, "fg-1.bin") == UnitState::Done);
}

// Task 4.1: after a failed run the files are in staging and NONE in the real folder.
void test_verify_failure_keeps_real_folder_clean() {
    test_util::TempDir dir("ext_verify_fail");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game));
    Journal journal(dir.file("journal.log"));
    const CommandTemplate command_template = fake_extractor_template();
    const Manifest wrong_expectation = make_fake_unit_manifest("some-other-unit.bin");

    const UnitExtractionResult result =
        extract_unit(make_unit(dir, "fg-1.bin"), {journal, command_template, game, &wrong_expectation});

    assert(!result.ok);
    assert(result.failed_stage == ExtractionStage::VerifyStaging);
    assert(result.extractor_started && result.extractor_exit_code == 0);
    assert(!result.error.empty());

    // Real folder: only ".staging". Staging: the extracted files.
    std::size_t top_level_entries = 0;
    for (const fs::directory_entry& entry : fs::directory_iterator(fs::u8path(game))) {
        (void)entry;
        ++top_level_entries;
    }
    assert(top_level_entries == 1);
    Manifest staged;
    std::string error;
    assert(build_manifest(game + "/.staging/fg-1.bin", staged, error));
    assert(staged == make_fake_unit_manifest("fg-1.bin"));

    // Journal: START only, so the unit is InProgress and will be redone.
    assert(journal_record_count(journal) == 1);
    assert(journal_state_of(journal, "fg-1.bin") == UnitState::InProgress);
}

void test_extractor_failures() {
    test_util::TempDir dir("ext_fail");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game));
    Journal journal(dir.file("journal.log"));

    // Exit code != 0 (the fake extractor rejects the unknown option with code 2).
    const CommandTemplate bad_option = fake_extractor_template("--bogus");
    UnitExtractionResult result = extract_unit(make_unit(dir, "fg-1.bin"), {journal, bad_option, game, nullptr});
    assert(!result.ok && result.failed_stage == ExtractionStage::RunExtractor);
    assert(result.extractor_started && result.extractor_exit_code == 2);
    assert(game_files_without_staging(game).files.empty());
    assert(journal_state_of(journal, "fg-1.bin") == UnitState::InProgress);

    // Program that does not exist.
    CommandTemplate missing_program;
    std::string error;
    assert(CommandTemplate::parse(quote_argument(dir.file("no_such_program")) + " {unit} {out}", missing_program, error));
    result = extract_unit(make_unit(dir, "fg-2.bin"), {journal, missing_program, game, nullptr});
    assert(!result.ok && result.failed_stage == ExtractionStage::RunExtractor);
    assert(!result.extractor_started);

    // Exit code 0 but nothing written.
    const CommandTemplate nothing = do_nothing_template();
    result = extract_unit(make_unit(dir, "fg-3.bin"), {journal, nothing, game, nullptr});
    assert(!result.ok && result.failed_stage == ExtractionStage::VerifyStaging);
    assert(result.error.find("no files") != std::string::npos);
    assert(journal_state_of(journal, "fg-3.bin") == UnitState::InProgress);
}

void test_failures_before_anything_is_written() {
    test_util::TempDir dir("ext_validate");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game));
    Journal journal(dir.file("journal.log"));
    const CommandTemplate command_template = fake_extractor_template();

    // Unsafe unit names never reach the file system.
    for (const char* bad_name : {"..", "a/b", "a\\b", "", "C:x"}) {
        const UnitExtractionResult result = extract_unit(Unit{bad_name, "x", 0}, {journal, command_template, game, nullptr});
        assert(!result.ok && result.failed_stage == ExtractionStage::ValidateInput);
    }

    // Game folder missing.
    UnitExtractionResult result =
        extract_unit(make_unit(dir, "fg-1.bin"), {journal, command_template, dir.file("no game"), nullptr});
    assert(!result.ok && result.failed_stage == ExtractionStage::ValidateInput);
    assert(!fs::exists(fs::u8path(dir.file("no game"))));

    // Empty unit path: the command cannot be built.
    result = extract_unit(Unit{"fg-1.bin", "", 0}, {journal, command_template, game, nullptr});
    assert(!result.ok && result.failed_stage == ExtractionStage::BuildCommand);

    // None of the above wrote a journal line or created ".staging".
    assert(!fs::exists(fs::u8path(dir.file("journal.log"))));
    assert(!fs::exists(fs::u8path(game + "/.staging")));
}

void test_unwritable_journal_stops_before_running() {
    test_util::TempDir dir("ext_journal_fail");
    const std::string game = dir.file("game");
    fs::create_directories(fs::u8path(game));
    Journal journal(dir.file("missing folder/journal.log"));  // parent folder does not exist
    const CommandTemplate command_template = fake_extractor_template();

    const UnitExtractionResult result = extract_unit(make_unit(dir, "fg-1.bin"), {journal, command_template, game, nullptr});
    assert(!result.ok && result.failed_stage == ExtractionStage::WriteStartRecord);
    assert(!result.extractor_started);
    assert(!fs::exists(fs::u8path(game + "/.staging")));  // the extractor never ran
}

void test_stage_names() {
    assert(std::string(to_string(ExtractionStage::Completed)) == "Completed");
    assert(std::string(to_string(ExtractionStage::RunExtractor)) == "RunExtractor");
    assert(std::string(to_string(ExtractionStage::WriteDoneRecord)) == "WriteDoneRecord");
}

}  // namespace

int main(int argc, char** argv) {
    const std::vector<std::string> args = utf8_command_line_arguments(argc, argv);
    assert(!args.empty());
    if (args.size() >= 2) {
        g_extractor = args[1];
    } else {
        fs::path candidate = fs::absolute(fs::u8path(args[0])).parent_path() / "fake_extractor";
#ifdef _WIN32
        candidate += ".exe";
#endif
        g_extractor = candidate.u8string();
    }
    assert(fs::exists(fs::u8path(g_extractor)) && "fake_extractor not found next to the test");

    test_unit_name_rules();
    test_staging_path();
    test_prepare_staging_deletes_old_content();
#ifndef _WIN32
    test_prepare_staging_refuses_links();
#endif
    test_verify_detects_corruption();
    test_verify_without_expected_manifest();
    test_commit_moves_everything();
    test_commit_rejects_bad_input_without_moving();
    test_extract_unit_success();
    test_extract_unit_without_expected_manifest();
    test_extract_two_units_and_repeat();
    test_extract_unit_recovers_from_interrupted_attempt();
    test_verify_failure_keeps_real_folder_clean();
    test_extractor_failures();
    test_failures_before_anything_is_written();
    test_unwritable_journal_stops_before_running();
    test_stage_names();
    return 0;
}
