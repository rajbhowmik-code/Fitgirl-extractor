// Task 4.3 building blocks: durable flush, replace-move and safe folder delete.
#include "test_common.h"

#include <filesystem>
#include <string>
#include <system_error>

#include "file_ops.h"
#include "test_util.h"

namespace {

namespace fs = std::filesystem;

bool exists(const std::string& path) { return fs::exists(fs::symlink_status(fs::u8path(path))); }

void test_flush_file() {
    test_util::TempDir dir("ops_flush");
    std::string error;

    test_util::write_file(dir.file("data.bin"), "hello");
    assert(flush_file_to_disk(dir.file("data.bin"), error));

    test_util::write_file(dir.file("empty.bin"), "");
    assert(flush_file_to_disk(dir.file("empty.bin"), error));

    // A missing file is an error with a message.
    error.clear();
    assert(!flush_file_to_disk(dir.file("missing.bin"), error));
    assert(!error.empty());

    // Folders can be flushed too (a no-op on Windows).
    assert(flush_directory_to_disk(dir.path_utf8(), error));
}

void test_move_creates_and_replaces() {
    test_util::TempDir dir(u8"ops_move \u00E9");  // space + non-ASCII on purpose
    std::string error;

    test_util::write_file(dir.file("from.txt"), "new content");
    assert(move_file_replacing(dir.file("from.txt"), dir.file("to.txt"), error));
    assert(!exists(dir.file("from.txt")));
    assert(test_util::read_file(dir.file("to.txt")) == "new content");

    // An existing destination is replaced as a whole.
    test_util::write_file(dir.file("old.txt"), "old and much longer content");
    test_util::write_file(dir.file("newer.txt"), "short");
    assert(move_file_replacing(dir.file("newer.txt"), dir.file("old.txt"), error));
    assert(test_util::read_file(dir.file("old.txt")) == "short");
    assert(!exists(dir.file("newer.txt")));
}

// A read-only destination (left by an earlier run) must not block the replace.
void test_move_replaces_read_only_destination() {
    test_util::TempDir dir("ops_move_readonly");
    std::string error;

    test_util::write_file(dir.file("target.txt"), "old");
    fs::permissions(fs::u8path(dir.file("target.txt")),
                    fs::perms::owner_read | fs::perms::group_read | fs::perms::others_read, fs::perm_options::replace);
    test_util::write_file(dir.file("source.txt"), "fresh");
    assert(move_file_replacing(dir.file("source.txt"), dir.file("target.txt"), error));
    assert(test_util::read_file(dir.file("target.txt")) == "fresh");
}

// A read-only file inside a tree must not block deleting the tree (Windows: read-only attribute).
void test_remove_tree_with_read_only_file() {
    test_util::TempDir dir("ops_remove_ro_file");
    std::string error;

    fs::create_directories(fs::u8path(dir.file("tree/sub")));
    test_util::write_file(dir.file("tree/sub/locked.txt"), "x");
    fs::permissions(fs::u8path(dir.file("tree/sub/locked.txt")), fs::perms::owner_read, fs::perm_options::replace);
    assert(remove_folder_tree(dir.file("tree"), error));
    assert(!exists(dir.file("tree")));
}

void test_move_failures_change_nothing() {
    test_util::TempDir dir("ops_move_fail");
    std::string error;

    // Missing source.
    assert(!move_file_replacing(dir.file("nope.txt"), dir.file("target.txt"), error));
    assert(!error.empty());
    assert(!exists(dir.file("target.txt")));

    // Destination is a folder: must fail and keep the source.
    test_util::write_file(dir.file("source.txt"), "keep me");
    fs::create_directories(fs::u8path(dir.file("folder")));
    error.clear();
    assert(!move_file_replacing(dir.file("source.txt"), dir.file("folder"), error));
    assert(!error.empty());
    assert(test_util::read_file(dir.file("source.txt")) == "keep me");
    assert(fs::is_directory(fs::u8path(dir.file("folder"))));

    // Parent folder of the destination missing.
    assert(!move_file_replacing(dir.file("source.txt"), dir.file("no/such/parent/x.txt"), error));
    assert(test_util::read_file(dir.file("source.txt")) == "keep me");
}

void test_remove_folder_tree() {
    test_util::TempDir dir("ops_remove");
    std::string error;

    // Missing folder: success.
    assert(remove_folder_tree(dir.file("not here"), error));

    // Nested tree with files and an empty folder.
    fs::create_directories(fs::u8path(dir.file("tree/a/b")));
    fs::create_directories(fs::u8path(dir.file("tree/empty")));
    test_util::write_file(dir.file("tree/a/b/file.txt"), "x");
    test_util::write_file(dir.file("tree/top.txt"), "y");
    assert(remove_folder_tree(dir.file("tree"), error));
    assert(!exists(dir.file("tree")));

    // Empty name is refused.
    assert(!remove_folder_tree("", error));

    // A plain file is not a folder: refused, and still there.
    test_util::write_file(dir.file("plain.txt"), "z");
    error.clear();
    assert(!remove_folder_tree(dir.file("plain.txt"), error));
    assert(!error.empty());
    assert(exists(dir.file("plain.txt")));
}

#ifndef _WIN32  // creating symbolic links needs special rights on Windows
void test_remove_refuses_links() {
    test_util::TempDir dir("ops_remove_link");
    std::string error;

    // A link as the folder itself: refused; the target survives.
    fs::create_directories(fs::u8path(dir.file("precious")));
    test_util::write_file(dir.file("precious/keep.txt"), "important");
    fs::create_directory_symlink(fs::u8path(dir.file("precious")), fs::u8path(dir.file("link")));
    assert(!remove_folder_tree(dir.file("link"), error));
    assert(test_util::read_file(dir.file("precious/keep.txt")) == "important");

    // A link INSIDE the tree: the link is removed, its target is not followed.
    fs::create_directories(fs::u8path(dir.file("tree")));
    fs::create_directory_symlink(fs::u8path(dir.file("precious")), fs::u8path(dir.file("tree/inside_link")));
    assert(remove_folder_tree(dir.file("tree"), error));
    assert(!exists(dir.file("tree")));
    assert(test_util::read_file(dir.file("precious/keep.txt")) == "important");
}

void test_remove_handles_read_only_content() {
    test_util::TempDir dir("ops_remove_readonly");
    std::string error;

    fs::create_directories(fs::u8path(dir.file("tree/locked")));
    test_util::write_file(dir.file("tree/locked/file.txt"), "x");
    // A read-only folder blocks deleting its entries on POSIX.
    fs::permissions(fs::u8path(dir.file("tree/locked")), fs::perms::owner_read | fs::perms::owner_exec,
                    fs::perm_options::replace);
    assert(remove_folder_tree(dir.file("tree"), error));
    assert(!exists(dir.file("tree")));
}
#endif

}  // namespace

int main() {
    test_flush_file();
    test_move_creates_and_replaces();
    test_move_replaces_read_only_destination();
    test_remove_tree_with_read_only_file();
    test_move_failures_change_nothing();
    test_remove_folder_tree();
#ifndef _WIN32
    test_remove_refuses_links();
    test_remove_handles_read_only_content();
#endif
    return 0;
}
