#include "fake_unit_manifest.h"

#include <algorithm>

#include "crc32.h"
#include "fake_unit_content.h"

Manifest make_fake_unit_manifest(const std::string& unit) {
    Manifest manifest;
    for (const FakeFile& file : make_fake_unit_files(unit)) {
        ManifestEntry entry;
        entry.relative_path = file.relative_path;
        entry.size = file.content.size();
        entry.crc32 = crc32_update(0, file.content.data(), file.content.size());
        manifest.files.push_back(entry);
    }
    std::sort(manifest.files.begin(), manifest.files.end(),
              [](const ManifestEntry& left, const ManifestEntry& right) { return left.relative_path < right.relative_path; });
    return manifest;
}
