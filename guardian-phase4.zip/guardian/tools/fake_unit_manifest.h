// The manifest a correct run of fake_extractor must produce for a unit
// (task 4.2 tests: "compare against its known expected manifest").
//
// It is computed from make_fake_unit_files() in memory, without running
// anything, so it is independent of the files the extractor really wrote.
#pragma once

#include <string>

#include "manifest.h"

// Expected manifest for `unit` (a name or a path; only the part after the last
// '/' or '\' counts, like make_fake_unit_files). Files are sorted by path; the
// fake extractor creates no empty folders, so empty_directories is empty.
Manifest make_fake_unit_manifest(const std::string& unit);
